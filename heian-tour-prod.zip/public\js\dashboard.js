let chartClienteFinanceiro = null;
window.notionContas = [];
window.appConfig = {};
let currentPagamentoGuia = null;

const KANBAN_STATUSES = [
  { name: 'Início/call de dúvidas', color: '#787878', bgColor: 'rgba(120, 120, 120, 0.08)', borderColor: '#cbd5e1' },
  { name: 'Em Negociação', color: '#64748b', bgColor: 'rgba(100, 116, 139, 0.08)', borderColor: '#cbd5e1' },
  { name: 'Negociação Aprovada', color: '#0284c7', bgColor: 'rgba(2, 132, 199, 0.08)', borderColor: '#bae6fd' },
  { name: 'Roteiro Rascunho', color: '#db2777', bgColor: 'rgba(219, 39, 119, 0.08)', borderColor: '#fbcfe8' },
  { name: 'Compras', color: '#0891b2', bgColor: 'rgba(8, 145, 178, 0.08)', borderColor: '#a5f3fc' },
  { name: 'Roteiro versão final', color: '#ea580c', bgColor: 'rgba(234, 88, 12, 0.08)', borderColor: '#ffedd5' },
  { name: 'Em Viagem', color: '#7c3aed', bgColor: 'rgba(124, 58, 237, 0.08)', borderColor: '#e9d5ff' },
  { name: 'Cancelado', color: '#dc2626', bgColor: 'rgba(220, 38, 38, 0.08)', borderColor: '#fee2e2' },
  { name: 'Finalizados', color: '#16a34a', bgColor: 'rgba(22, 163, 74, 0.08)', borderColor: '#dcfce7' },
  { name: 'Atendimento Pós', color: '#b45309', bgColor: 'rgba(180, 83, 9, 0.08)', borderColor: '#fef3c7' },
  // Etapas que existem no Notion mas ficam OCULTAS por padrão (podem ser resgatadas em "⚙ Etapas")
  { name: 'Lead', color: '#ca8a04', bgColor: 'rgba(202, 138, 4, 0.08)', borderColor: '#fef08a' },
  { name: 'Novo', color: '#2563eb', bgColor: 'rgba(37, 99, 235, 0.08)', borderColor: '#bfdbfe' },
  { name: 'Em andamento', color: '#0d9488', bgColor: 'rgba(13, 148, 136, 0.08)', borderColor: '#99f6e4' },
  { name: 'Pendente', color: '#d97706', bgColor: 'rgba(217, 119, 6, 0.08)', borderColor: '#fed7aa' }
];

// Revalida a lista de clientes em segundo plano e re-renderiza Kanban/Provisões se algo mudou
// (faz a edição aparecer sem precisar de F5, sem deixar a tela travada esperando o Notion).
async function refrescarClientesEmBackground() {
  if (window.__dashClientesInflight) return;
  window.__dashClientesInflight = true;
  try {
    const res = await fetch('/api/notion/clientes?t=' + Date.now(), { cache: 'no-store' });
    if (res.ok) {
      const novos = await res.json();
      const mudou = JSON.stringify(novos) !== JSON.stringify(window.notionClients);
      window.notionClients = novos;
      if (mudou) {
        if (typeof renderKanban === 'function') renderKanban();
        if (typeof window.renderPainelProvisoes === 'function') window.renderPainelProvisoes();
      }
    }
  } catch (e) {
    console.error('Erro ao revalidar clientes em segundo plano:', e);
  } finally {
    window.__dashClientesInflight = false;
  }
}

async function renderDashboard() {
  const titleEl = document.getElementById('dashboardPageTitle');
  const select = document.getElementById('dashClienteSelect');
  const selectVal = select ? select.value : '';
  if (titleEl && !selectVal) {
    titleEl.textContent = 'Painel Geral & Operacional';
  }

  // Inicializa dados de contas e taxas se necessário
  if (!window.notionContas || window.notionContas.length === 0) {
    await inicializarDashboardFinanceiro();
  }

  // Busca a ordenação personalizada do Kanban do Supabase
  if (window.kanbanOrdem === undefined) {
    try {
      const ordRes = await fetch('/api/config/kanban_ordem');
      if (ordRes.ok) {
        window.kanbanOrdem = await ordRes.json();
      } else {
        window.kanbanOrdem = {};
      }
    } catch(e) {
      console.error('Erro ao carregar ordenação do Kanban:', e);
      window.kanbanOrdem = {};
    }
  }

  // Busca a ordem personalizada das COLUNAS (etapas) do Kanban
  if (window.kanbanColunasOrdem === undefined) {
    try {
      const colRes = await fetch('/api/config/kanban_colunas_ordem');
      if (colRes.ok) {
        const j = await colRes.json();
        window.kanbanColunasOrdem = Array.isArray(j) ? j : (j && Array.isArray(j.ordem) ? j.ordem : []);
      } else {
        window.kanbanColunasOrdem = [];
      }
    } catch(e) {
      console.error('Erro ao carregar ordem das colunas do Kanban:', e);
      window.kanbanColunasOrdem = [];
    }
  }

  // Popula o select de clientes para o Dashboard
  let clientes = window.notionClients || [];

  if (clientes.length === 0) {
    // Sem cache: busca agora (primeira carga).
    try {
      const res = await fetch('/api/notion/clientes?t=' + Date.now(), { cache: 'no-store' });
      if (res.ok) {
        clientes = await res.json();
        window.notionClients = clientes;
      }
    } catch (e) {
      console.error('Erro ao buscar clientes no dashboard:', e);
    }
  } else {
    // Já tem cache: renderiza rápido com o que tem e revalida em segundo plano (sem F5).
    refrescarClientesEmBackground();
  }

  if (select && (select.options.length <= 1 || select.dataset.loadedCount != clientes.length)) {
    select.dataset.loadedCount = clientes.length;
    const currentVal = select.value;
    select.innerHTML = '<option value="">Geral (Todos os orçamentos locais)</option>';
    clientes.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome || 'Sem nome';
      select.appendChild(opt);
    });
    select.value = currentVal;
    if (select.value !== currentVal) select.value = "";
  }

  // Carrega e renderiza a agenda operacional (Ordens de Serviço do dia e da semana)
  await carregarAgendaOperacional();

  // Renderiza o Kanban
  renderKanban();

  // Carrega os saldos das contas
  await carregarSaldosContas();
}

async function salvarOrdemKanbanDOM() {
  const ordem = {};
  const colunas = document.querySelectorAll('.kanban-column');
  colunas.forEach(col => {
    const cardsContainer = col.querySelector('.kanban-cards-container');
    if (!cardsContainer) return;
    const status = cardsContainer.dataset.status;
    const cards = col.querySelectorAll('.kanban-card');
    const ids = Array.from(cards).map(card => card.dataset.id).filter(Boolean);
    ordem[status] = ids;
  });

  window.kanbanOrdem = ordem;

  try {
    await fetch('/api/config/kanban_ordem', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ordem)
    });
  } catch(e) {
    console.error('Erro ao salvar ordenação do Kanban no Supabase:', e);
  }
}

// ---- Ordem personalizada das COLUNAS (etapas) ----
// Lista-base das etapas: prefere as opções vindas do Notion (window.kanbanStatusesFromNotion),
// senão o array embutido KANBAN_STATUSES. Mantém a cor tunada quando o nome é conhecido e inclui
// qualquer status presente em clientes (pra nunca perder card de uma etapa desconhecida).
function statusBaseList() {
  const known = {};
  KANBAN_STATUSES.forEach(s => { known[s.name] = s; });
  const list = [];
  const seen = new Set();
  const add = (name, color) => {
    if (!name || seen.has(name)) return;
    seen.add(name);
    if (known[name]) list.push(known[name]);
    else list.push({ name, color: color || '#64748b', bgColor: 'rgba(100,116,139,0.08)', borderColor: '#cbd5e1' });
  };
  const fromNotion = Array.isArray(window.kanbanStatusesFromNotion) ? window.kanbanStatusesFromNotion : null;
  if (fromNotion && fromNotion.length) fromNotion.forEach(o => add(o.name, o.color));
  else KANBAN_STATUSES.forEach(s => add(s.name, s.color));
  (window.notionClients || []).forEach(c => { if (c && c.status) add(c.status); });
  return list;
}

// Busca (uma vez por sessão) as opções de status do Notion e re-renderiza o quadro.
function carregarStatusOpcoesNotion() {
  if (window.__statusOpcoesTried || window.__statusOpcoesInflight) return;
  window.__statusOpcoesInflight = true;
  fetch('/api/notion/status-opcoes')
    .then(r => r.ok ? r.json() : [])
    .then(arr => { if (Array.isArray(arr) && arr.length) { window.kanbanStatusesFromNotion = arr; if (typeof renderKanban === 'function') renderKanban(); } })
    .catch(e => console.error('status-opcoes:', e))
    .finally(() => { window.__statusOpcoesInflight = false; window.__statusOpcoesTried = true; });
}

function getOrderedStatuses() {
  const saved = Array.isArray(window.kanbanColunasOrdem) ? window.kanbanColunasOrdem : [];
  const base = statusBaseList();
  const byName = {};
  base.forEach(s => { byName[s.name] = s; });
  const out = [];
  const used = new Set();
  // 1) respeita a ordem salva (só nomes que ainda existem)
  saved.forEach(name => { if (byName[name] && !used.has(name)) { out.push(byName[name]); used.add(name); } });
  // 2) acrescenta etapas novas que ainda não estavam na ordem salva (ex.: nova coluna do Notion)
  base.forEach(s => { if (!used.has(s.name)) { out.push(s); used.add(s.name); } });
  return out;
}

async function salvarOrdemColunasKanban() {
  const board = document.getElementById('kanbanBoard');
  if (!board) return;
  const ordem = Array.from(board.querySelectorAll('.kanban-column'))
    .map(col => col.dataset.status)
    .filter(Boolean);
  // Preserva etapas ocultas (fora do DOM) na ordem atual, para não perdê-las ao salvar
  getOrderedStatuses().forEach(s => { if (!ordem.includes(s.name)) ordem.push(s.name); });
  window.kanbanColunasOrdem = ordem;
  try {
    await fetch('/api/config/kanban_colunas_ordem', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ordem)
    });
  } catch(e) {
    console.error('Erro ao salvar ordem das colunas do Kanban:', e);
  }
}

// ---- Ordenação dos CARDS por Data da viagem ----
function getKanbanSort() {
  try { return JSON.parse(localStorage.getItem('kanbanCardSort') || '{}') || {}; }
  catch(e) { return {}; }
}
function setKanbanSort(map) {
  try { localStorage.setItem('kanbanCardSort', JSON.stringify(map || {})); } catch(e) {}
}
function cycleKanbanSort(status) {
  const map = getKanbanSort();
  const atual = map[status] || 'manual';
  const prox = atual === 'manual' ? 'asc' : (atual === 'asc' ? 'desc' : 'manual');
  if (prox === 'manual') delete map[status]; else map[status] = prox;
  setKanbanSort(map);
  renderKanban();
}
function tsDataViagem(c) {
  const d = c && c.dataInicio ? c.dataInicio : '';
  if (!d) return null;
  const t = new Date(d).getTime();
  return isNaN(t) ? null : t;
}

// ---- Etapas ocultas (mostrar/ocultar colunas) ----
// Por padrão deixa ocultas as etapas órfãs do Notion para manter o quadro igual ao de hoje.
function getHiddenStatuses() {
  try {
    const raw = localStorage.getItem('kanbanHiddenCols');
    if (raw === null) {
      const seed = ['Lead', 'Novo', 'Em andamento', 'Pendente'];
      localStorage.setItem('kanbanHiddenCols', JSON.stringify(seed));
      return seed.slice();
    }
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch(e) { return []; }
}
function setHiddenStatuses(arr) {
  try { localStorage.setItem('kanbanHiddenCols', JSON.stringify(arr || [])); } catch(e) {}
}
function toggleColHidden(status) {
  const arr = getHiddenStatuses();
  const i = arr.indexOf(status);
  if (i >= 0) arr.splice(i, 1); else arr.push(status);
  setHiddenStatuses(arr);
  renderKanban();
}

function renderKanbanToolbar(orderedStatuses, hiddenSet) {
  const board = document.getElementById('kanbanBoard');
  if (!board || !board.parentNode) return;
  let bar = document.getElementById('kanbanToolbar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'kanbanToolbar';
    bar.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 12px 2px;';
    board.parentNode.insertBefore(bar, board);
  }
  const clientes = window.notionClients || [];
  const countOf = (name) => clientes.filter(c => (c.status || 'Início/call de dúvidas').toLowerCase() === name.toLowerCase()).length;
  const hiddenList = orderedStatuses.filter(s => hiddenSet.has(s.name));

  bar.innerHTML = '';

  const wrap = document.createElement('div');
  wrap.style.position = 'relative';

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = '⚙ Etapas' + (hiddenList.length ? ' · ' + hiddenList.length + ' oculta' + (hiddenList.length > 1 ? 's' : '') : '');
  btn.style.cssText = 'cursor:pointer;border:1px solid var(--border,#e5e0d8);background:#fff;color:var(--ink-mid,#555);border-radius:8px;font-size:12px;font-weight:600;padding:6px 12px;';

  const panel = document.createElement('div');
  panel.id = 'kanbanColPanel';
  panel.style.cssText = 'position:absolute;z-index:60;margin-top:6px;background:#fff;border:1px solid var(--border,#e5e0d8);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,0.12);padding:8px;min-width:250px;max-height:340px;overflow:auto;display:' + (window.__kanbanPanelOpen ? 'block' : 'none') + ';';

  const hint = document.createElement('div');
  hint.textContent = 'Marque para mostrar a etapa, desmarque para ocultar.';
  hint.style.cssText = 'font-size:11px;color:var(--ink-lt,#999);padding:2px 8px 8px;';
  panel.appendChild(hint);

  orderedStatuses.forEach(s => {
    const row = document.createElement('label');
    row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:6px;cursor:pointer;font-size:12px;';
    row.onmouseenter = () => row.style.background = 'rgba(0,0,0,0.04)';
    row.onmouseleave = () => row.style.background = 'transparent';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !hiddenSet.has(s.name);
    cb.style.cursor = 'pointer';
    cb.addEventListener('change', (e) => { e.stopPropagation(); window.__kanbanPanelOpen = true; toggleColHidden(s.name); });
    const dot = document.createElement('span');
    dot.style.cssText = 'width:9px;height:9px;border-radius:50%;flex-shrink:0;background:' + s.color + ';';
    const nm = document.createElement('span');
    nm.textContent = s.name;
    nm.style.flex = '1';
    const ct = document.createElement('span');
    ct.textContent = countOf(s.name);
    ct.style.cssText = 'color:var(--ink-lt,#999);font-size:11px;';
    row.appendChild(cb); row.appendChild(dot); row.appendChild(nm); row.appendChild(ct);
    panel.appendChild(row);
  });

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    window.__kanbanPanelOpen = !window.__kanbanPanelOpen;
    panel.style.display = window.__kanbanPanelOpen ? 'block' : 'none';
  });
  panel.addEventListener('click', (e) => e.stopPropagation());

  wrap.appendChild(btn);
  wrap.appendChild(panel);
  bar.appendChild(wrap);

  // Chips de restauração rápida das etapas ocultas
  hiddenList.forEach(s => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.textContent = '↩ ' + s.name + (countOf(s.name) ? ' (' + countOf(s.name) + ')' : '');
    chip.title = 'Restaurar a etapa ' + s.name;
    chip.style.cssText = 'cursor:pointer;border:1px dashed ' + s.color + ';background:transparent;color:' + s.color + ';border-radius:999px;font-size:11px;font-weight:600;padding:4px 10px;opacity:0.9;';
    chip.addEventListener('click', () => toggleColHidden(s.name));
    bar.appendChild(chip);
  });

  // Fecha o painel ao clicar fora (registrado uma única vez)
  if (!window.__kanbanPanelDocWired) {
    window.__kanbanPanelDocWired = true;
    document.addEventListener('click', () => {
      window.__kanbanPanelOpen = false;
      const p = document.getElementById('kanbanColPanel');
      if (p) p.style.display = 'none';
    });
  }
}

// ---- Auto-scroll nas bordas durante o arraste (cards e colunas) ----
// Faz o quadro rolar sozinho ao chegar perto da borda, sem precisar soltar.
function wireKanbanAutoScroll(board) {
  if (!board || board.dataset.autoScrollWired) return;
  board.dataset.autoScrollWired = '1';

  const ZONE = 75;   // distância da borda (px) que ativa o scroll
  const MAXV = 24;   // velocidade máxima por frame
  let hEl = null, vEl = null, vx = 0, vy = 0, raf = 0, active = false;

  function speed(dist) {
    const f = Math.min(1, Math.max(0, (ZONE - dist) / ZONE));
    return Math.ceil(f * MAXV);
  }
  function loop() {
    if (!active || (!vx && !vy)) { raf = 0; return; }
    if (hEl && vx) hEl.scrollLeft += vx;
    if (vEl && vy) vEl.scrollTop += vy;
    raf = requestAnimationFrame(loop);
  }
  function ensureLoop() { if (!raf) raf = requestAnimationFrame(loop); }
  function stop() { active = false; hEl = vEl = null; vx = vy = 0; if (raf) { cancelAnimationFrame(raf); raf = 0; } }

  document.addEventListener('dragover', function (e) {
    const dragging = window.__kanbanDragCol || document.querySelector('.kanban-card.dragging');
    if (!dragging) return;
    active = true;

    // Horizontal: rola o próprio quadro
    vx = 0; hEl = null;
    const br = board.getBoundingClientRect();
    if (e.clientX < br.left + ZONE && board.scrollLeft > 0) {
      hEl = board; vx = -speed(e.clientX - br.left);
    } else if (e.clientX > br.right - ZONE && board.scrollLeft + board.clientWidth < board.scrollWidth - 1) {
      hEl = board; vx = speed(br.right - e.clientX);
    }

    // Vertical: rola a coluna sob o ponteiro (apenas em arraste de card)
    vy = 0; vEl = null;
    if (!window.__kanbanDragCol && typeof document.elementFromPoint === 'function') {
      try {
        const under = document.elementFromPoint(e.clientX, e.clientY);
        const cont = under && under.closest ? under.closest('.kanban-cards-container') : null;
        if (cont) {
          const cr = cont.getBoundingClientRect();
          if (e.clientY < cr.top + ZONE && cont.scrollTop > 0) {
            vEl = cont; vy = -speed(e.clientY - cr.top);
          } else if (e.clientY > cr.bottom - ZONE && cont.scrollTop + cont.clientHeight < cont.scrollHeight - 1) {
            vEl = cont; vy = speed(cr.bottom - e.clientY);
          }
        }
      } catch (err) { /* elementFromPoint indisponível: mantém só o scroll horizontal */ }
    }

    if (vx || vy) ensureLoop();
  }, true);

  ['dragend', 'drop'].forEach(function (ev) { document.addEventListener(ev, stop, true); });
}

function renderKanban() {
  const board = document.getElementById('kanbanBoard');
  if (!board) return;
  carregarStatusOpcoesNotion(); // colunas dinâmicas do Notion (1x por sessão)

  const clientes = window.notionClients || [];
  board.innerHTML = '';

  // Wiring (uma vez) do drag-reorder das COLUNAS no nível do board
  if (!board.dataset.colDndWired) {
    board.dataset.colDndWired = '1';
    board.addEventListener('dragover', (e) => {
      if (!window.__kanbanDragCol) return; // só age durante drag de coluna
      e.preventDefault();
      const dragging = board.querySelector('.kanban-col-dragging');
      if (!dragging) return;
      const cols = Array.from(board.querySelectorAll('.kanban-column:not(.kanban-col-dragging)'));
      let alvo = null;
      for (const col of cols) {
        const r = col.getBoundingClientRect();
        if (e.clientX < r.left + r.width / 2) { alvo = col; break; }
      }
      if (alvo) board.insertBefore(dragging, alvo);
      else board.appendChild(dragging);
    });
    board.addEventListener('drop', (e) => {
      if (window.__kanbanDragCol) e.preventDefault();
    });
  }
  wireKanbanAutoScroll(board);

  const sortMap = getKanbanSort();
  const orderedStatuses = getOrderedStatuses();
  const hiddenSet = new Set(getHiddenStatuses());
  renderKanbanToolbar(orderedStatuses, hiddenSet);

  orderedStatuses.forEach(statusConfig => {
    const colStatus = statusConfig.name;
    if (hiddenSet.has(colStatus)) return; // coluna oculta: não renderiza
    const colClients = clientes.filter(c => (c.status || 'Início/call de dúvidas').toLowerCase() === colStatus.toLowerCase());

    const sortMode = sortMap[colStatus] || 'manual';
    if (sortMode === 'asc' || sortMode === 'desc') {
      // Ordena por Data da viagem; cards sem data vão sempre para o fim
      colClients.sort((a, b) => {
        const ta = tsDataViagem(a), tb = tsDataViagem(b);
        if (ta === null && tb === null) return 0;
        if (ta === null) return 1;
        if (tb === null) return -1;
        return sortMode === 'asc' ? ta - tb : tb - ta;
      });
    } else {
      // Ordenação manual (arrastar) persistida no Supabase
      const ordemIds = window.kanbanOrdem && window.kanbanOrdem[colStatus] ? window.kanbanOrdem[colStatus] : [];
      if (ordemIds.length > 0) {
        colClients.sort((a, b) => {
          const idxA = ordemIds.indexOf(a.id);
          const idxB = ordemIds.indexOf(b.id);
          if (idxA !== -1 && idxB !== -1) return idxA - idxB;
          if (idxA !== -1) return -1;
          if (idxB !== -1) return 1;
          return 0;
        });
      }
    }

    const column = document.createElement('div');
    column.className = 'kanban-column';
    column.dataset.status = colStatus;
    column.style.borderColor = statusConfig.borderColor;
    
    // Header (arrastável para reordenar colunas)
    const header = document.createElement('div');
    header.className = 'kanban-column-header';
    header.style.backgroundColor = statusConfig.bgColor;
    header.style.borderTop = `3px solid ${statusConfig.color}`;
    header.draggable = true;
    header.style.cursor = 'grab';
    header.title = 'Arraste para reordenar a etapa';

    const titleWrap = document.createElement('span');
    titleWrap.style.display = 'flex';
    titleWrap.style.alignItems = 'center';
    titleWrap.style.gap = '5px';
    titleWrap.style.minWidth = '0';

    const handleSpan = document.createElement('span');
    handleSpan.textContent = '⠿';
    handleSpan.style.color = statusConfig.color;
    handleSpan.style.opacity = '0.5';
    handleSpan.style.fontSize = '12px';
    handleSpan.style.flexShrink = '0';

    const titleSpan = document.createElement('span');
    titleSpan.textContent = colStatus;
    titleSpan.style.color = statusConfig.color;
    titleSpan.style.overflow = 'hidden';
    titleSpan.style.textOverflow = 'ellipsis';
    titleSpan.style.whiteSpace = 'nowrap';

    titleWrap.appendChild(handleSpan);
    titleWrap.appendChild(titleSpan);

    const rightWrap = document.createElement('span');
    rightWrap.style.display = 'flex';
    rightWrap.style.alignItems = 'center';
    rightWrap.style.gap = '6px';
    rightWrap.style.flexShrink = '0';

    // Botão de ordenação por Data da viagem (manual -> asc -> desc)
    const sortBtn = document.createElement('button');
    sortBtn.type = 'button';
    sortBtn.draggable = false;
    sortBtn.textContent = sortMode === 'asc' ? '📅 ↑' : (sortMode === 'desc' ? '📅 ↓' : '📅');
    sortBtn.title = sortMode === 'asc'
      ? 'Ordenado por data (mais próxima primeiro). Clique para inverter.'
      : (sortMode === 'desc'
        ? 'Ordenado por data (mais distante primeiro). Clique para voltar ao manual.'
        : 'Ordenar por Data da viagem');
    sortBtn.style.cssText = 'cursor:pointer;border:1px solid ' + statusConfig.borderColor +
      ';background:' + (sortMode === 'manual' ? 'transparent' : '#fff') +
      ';color:' + statusConfig.color + ';border-radius:6px;font-size:10px;line-height:1;padding:3px 5px;font-weight:700;opacity:' +
      (sortMode === 'manual' ? '0.55' : '1') + ';';
    sortBtn.addEventListener('mousedown', e => e.stopPropagation());
    sortBtn.addEventListener('dragstart', e => { e.preventDefault(); e.stopPropagation(); });
    sortBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      cycleKanbanSort(colStatus);
    });

    const countSpan = document.createElement('span');
    countSpan.className = 'kanban-column-count';
    countSpan.textContent = colClients.length;

    // Botão de ocultar esta etapa
    const hideBtn = document.createElement('button');
    hideBtn.type = 'button';
    hideBtn.draggable = false;
    hideBtn.textContent = '✕';
    hideBtn.title = 'Ocultar esta etapa (restaure em "⚙ Etapas")';
    hideBtn.style.cssText = 'cursor:pointer;border:none;background:transparent;color:' + statusConfig.color +
      ';opacity:0.45;font-size:12px;line-height:1;padding:2px 3px;font-weight:700;';
    hideBtn.addEventListener('mouseenter', () => hideBtn.style.opacity = '0.9');
    hideBtn.addEventListener('mouseleave', () => hideBtn.style.opacity = '0.45');
    hideBtn.addEventListener('mousedown', e => e.stopPropagation());
    hideBtn.addEventListener('dragstart', e => { e.preventDefault(); e.stopPropagation(); });
    hideBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleColHidden(colStatus);
    });

    rightWrap.appendChild(sortBtn);
    rightWrap.appendChild(countSpan);
    rightWrap.appendChild(hideBtn);

    header.appendChild(titleWrap);
    header.appendChild(rightWrap);

    // Drag das colunas (reordenar etapas)
    header.addEventListener('dragstart', (e) => {
      window.__kanbanDragCol = colStatus;
      column.classList.add('kanban-col-dragging');
      header.style.cursor = 'grabbing';
      try {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('application/x-kanban-col', colStatus);
      } catch(err) {}
    });
    header.addEventListener('dragend', async () => {
      header.style.cursor = 'grab';
      column.classList.remove('kanban-col-dragging');
      if (window.__kanbanDragCol) {
        window.__kanbanDragCol = null;
        await salvarOrdemColunasKanban();
      }
    });

    column.appendChild(header);

    // Cards Container
    const cardsContainer = document.createElement('div');
    cardsContainer.className = 'kanban-cards-container';
    cardsContainer.dataset.status = colStatus;

    // Listeners do Drag and Drop
    cardsContainer.addEventListener('dragover', (e) => {
      if (window.__kanbanDragCol) return; // ignora durante reordenação de colunas
      e.preventDefault();
      cardsContainer.classList.add('drag-over');
    });

    cardsContainer.addEventListener('dragleave', () => {
      cardsContainer.classList.remove('drag-over');
    });

    cardsContainer.addEventListener('drop', async (e) => {
      e.preventDefault();
      cardsContainer.classList.remove('drag-over');
      const clientStr = e.dataTransfer.getData('text/plain');
      if (!clientStr) return;
      
      const { id, fromStatus } = JSON.parse(clientStr);
      if (fromStatus.toLowerCase() !== colStatus.toLowerCase()) {
        await atualizarStatusClienteKanban(id, colStatus);
      } else {
        await salvarOrdemKanbanDOM();
      }
    });

    // Renderiza os cards de cliente
    if (colClients.length === 0) {
      const emptyMsg = document.createElement('div');
      emptyMsg.style.color = 'var(--ink-lt)';
      emptyMsg.style.fontSize = '11px';
      emptyMsg.style.fontStyle = 'italic';
      emptyMsg.style.textAlign = 'center';
      emptyMsg.style.padding = '20px 0';
      emptyMsg.textContent = 'Sem clientes';
      cardsContainer.appendChild(emptyMsg);
    } else {
      colClients.forEach(c => {
        const card = document.createElement('div');
        card.className = 'kanban-card';
        card.draggable = true;
        card.dataset.id = c.id;
        card.dataset.status = c.status || 'Início/call de dúvidas';

        let isDraggingAction = false;

        // Ao arrastar (Desktop)
        card.addEventListener('dragstart', (e) => {
          isDraggingAction = true;
          card.classList.add('dragging');
          e.dataTransfer.effectAllowed = 'move';
          e.dataTransfer.setData('text/plain', JSON.stringify({ id: c.id, fromStatus: c.status || 'Início/call de dúvidas' }));
        });

        card.addEventListener('dragend', () => {
          card.classList.remove('dragging');
          setTimeout(() => { isDraggingAction = false; }, 100);
        });

        // Reordenação dinâmica interativa no Desktop
        card.addEventListener('dragover', (e) => {
          e.preventDefault();
          const draggingCard = document.querySelector('.kanban-card.dragging');
          if (draggingCard && draggingCard !== card) {
            const bounding = card.getBoundingClientRect();
            const offset = e.clientY - bounding.top - bounding.height / 2;
            if (offset < 0) {
              card.parentNode.insertBefore(draggingCard, card);
            } else {
              card.parentNode.insertBefore(draggingCard, card.nextSibling);
            }
          }
        });

        // Eventos de Toque (Mobile / Tablet Drag & Drop)
        let startX, startY;
        let ghostEl = null;
        let activeContainer = null;

        card.addEventListener('touchstart', (e) => {
          if (window.innerWidth <= 768) return; // celular: usar o botão "Mover etapa"
          isDraggingAction = false;
          const touch = e.touches[0];
          startX = touch.clientX;
          startY = touch.clientY;
          card.dataset.id = c.id;
          card.dataset.fromStatus = c.status || 'Início/call de dúvidas';
        }, { passive: true });

        card.addEventListener('touchmove', (e) => {
          if (window.innerWidth <= 768) return; // celular: rolar a tela não move cards
          const touch = e.touches[0];
          const diffX = touch.clientX - startX;
          const diffY = touch.clientY - startY;

          // Considera arrasto se mover mais de 10px
          if (Math.abs(diffX) > 10 || Math.abs(diffY) > 10) {
            isDraggingAction = true;
          }

          if (!isDraggingAction) return;

          // Previne scroll de tela ao arrastar o card
          if (e.cancelable) e.preventDefault();

          if (!ghostEl) {
            ghostEl = card.cloneNode(true);
            ghostEl.style.position = 'fixed';
            ghostEl.style.width = card.offsetWidth + 'px';
            ghostEl.style.height = card.offsetHeight + 'px';
            ghostEl.style.opacity = '0.85';
            ghostEl.style.pointerEvents = 'none';
            ghostEl.style.zIndex = '9999';
            ghostEl.style.transform = 'scale(1.03)';
            ghostEl.style.boxShadow = '0 10px 25px rgba(0,0,0,0.18)';
            document.body.appendChild(ghostEl);
            card.classList.add('dragging');
          }

          ghostEl.style.left = (touch.clientX - card.offsetWidth / 2) + 'px';
          ghostEl.style.top = (touch.clientY - card.offsetHeight / 2) + 'px';

          const elementUnder = document.elementFromPoint(touch.clientX, touch.clientY);
          if (elementUnder) {
            // Reordenação dinâmica por toque
            const targetCard = elementUnder.closest('.kanban-card');
            if (targetCard && targetCard !== card) {
              const bounding = targetCard.getBoundingClientRect();
              const offset = touch.clientY - bounding.top - bounding.height / 2;
              if (offset < 0) {
                targetCard.parentNode.insertBefore(card, targetCard);
              } else {
                targetCard.parentNode.insertBefore(card, targetCard.nextSibling);
              }
            } else {
              // Se está sobre o contêiner
              const container = elementUnder.closest('.kanban-cards-container');
              if (container) {
                if (activeContainer && activeContainer !== container) {
                  activeContainer.classList.remove('drag-over');
                }
                activeContainer = container;
                activeContainer.classList.add('drag-over');

                const cardsInCol = container.querySelectorAll('.kanban-card');
                if (cardsInCol.length === 0) {
                  container.appendChild(card);
                }
              } else {
                if (activeContainer) {
                  activeContainer.classList.remove('drag-over');
                  activeContainer = null;
                }
              }
            }
          }
        }, { passive: false });

        card.addEventListener('touchend', async (e) => {
          if (ghostEl) {
            ghostEl.remove();
            ghostEl = null;
          }
          card.classList.remove('dragging');

          if (activeContainer) {
            activeContainer.classList.remove('drag-over');
            const targetStatus = activeContainer.dataset.status;
            const fromStatus = card.dataset.fromStatus;
            const id = card.dataset.id;
            activeContainer = null;

            if (targetStatus && fromStatus && targetStatus.toLowerCase() !== fromStatus.toLowerCase()) {
              await atualizarStatusClienteKanban(id, targetStatus);
            } else {
              await salvarOrdemKanbanDOM();
            }
          } else {
            // Se soltou na mesma coluna por movimento sutil
            if (isDraggingAction) {
              await salvarOrdemKanbanDOM();
            }
          }

          if (isDraggingAction) {
            setTimeout(() => { isDraggingAction = false; }, 100);
          }
        });

        card.addEventListener('click', (e) => {
          if (isDraggingAction) {
            e.preventDefault();
            e.stopPropagation();
            return;
          }
          if (typeof window.setClientesVista === 'function') {
            window.setClientesVista('lista');
          }
          if (typeof window.navToPage === 'function') {
            window.navToPage('clientes');
          } else {
            const navItem = document.querySelector('.sidebar-nav a[data-page="clientes"]');
            if (navItem) navItem.click();
          }
          setTimeout(() => {
            if (typeof window.abrirDetalhesCliente === 'function') {
              window.abrirDetalhesCliente(c.id);
            }
          }, 100);
        });

        // Nome
        const nameEl = document.createElement('div');
        nameEl.className = 'kanban-card-title';
        nameEl.textContent = c.nome || 'Sem Nome';

        // Meta
        const metaEl = document.createElement('div');
        metaEl.className = 'kanban-card-meta';

        // Período
        if (c.dataInicio) {
          const dtStart = fmtDataBRAgenda(c.dataInicio);
          const dtEnd = c.dataFim ? fmtDataBRAgenda(c.dataFim) : '';
          const periodStr = dtEnd ? `${dtStart} - ${dtEnd}` : `A partir de ${dtStart}`;
          
          const pEl = document.createElement('span');
          pEl.textContent = periodStr;
          metaEl.appendChild(pEl);
        }

        // Pax
        if (c.adultos > 0 || c.criancas > 0) {
          const paxArr = [];
          if (c.adultos > 0) paxArr.push(`${c.adultos} ad`);
          if (c.criancas > 0) paxArr.push(`${c.criancas} cr`);
          
          const paxEl = document.createElement('span');
          paxEl.textContent = paxArr.join(' · ');
          metaEl.appendChild(paxEl);
        }

        // Valor
        if (c.valorTotal > 0) {
          const valEl = document.createElement('span');
          valEl.innerHTML = `<strong style="color:var(--crimson)">¥ ${c.valorTotal.toLocaleString('en-US')}</strong>`;
          metaEl.appendChild(valEl);
        }

        // Hotel
        if (c.hotel) {
          const hotEl = document.createElement('span');
          hotEl.textContent = c.hotel;
          hotEl.style.whiteSpace = 'nowrap';
          hotEl.style.overflow = 'hidden';
          hotEl.style.textOverflow = 'ellipsis';
          metaEl.appendChild(hotEl);
        }

        card.appendChild(nameEl);
        card.appendChild(metaEl);
        cardsContainer.appendChild(card);
      });
    }

    column.appendChild(cardsContainer);
    board.appendChild(column);
  });
}

async function atualizarStatusClienteKanban(id, novoStatus) {
  document.body.style.cursor = 'progress';

  try {
    // 1. Notion PATCH
    const notionRes = await fetch(`/api/notion/clientes/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: novoStatus })
    });

    if (!notionRes.ok) {
      throw new Error('Erro ao atualizar status no Notion');
    }

    // 2. Supabase POST
    const index = window.notionClients.findIndex(c => c.id === id);
    if (index !== -1) {
      const clienteOriginal = window.notionClients[index];
      const clienteAtualizado = { ...clienteOriginal, status: novoStatus };
      
      const localRes = await fetch('/api/clientes/local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(clienteAtualizado)
      });

      if (!localRes.ok) {
        console.warn('Erro ao atualizar status no banco local, continuando...');
      }

      window.notionClients[index] = clienteAtualizado;
    }

    // 3. UI Sync
    await salvarOrdemKanbanDOM();
    renderKanban();
    
    if (typeof window.renderClientesTabela === 'function') {
      window.renderClientesTabela();
    }

    // Se a ficha desse cliente estiver aberta no momento, atualiza ela também!
    if (window.clienteAtualVisualizado === id && typeof window.abrirDetalhesCliente === 'function') {
      window.abrirDetalhesCliente(id);
    }

    const select = document.getElementById('dashClienteSelect');
    if (select) {
      select.dataset.loadedCount = window.notionClients.length;
      const currentVal = select.value;
      select.innerHTML = '<option value="">Geral (Todos os orçamentos locais)</option>';
      window.notionClients.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.nome || 'Sem nome';
        select.appendChild(opt);
      });
      select.value = currentVal;
    }

  } catch (err) {
    console.error('Erro ao atualizar status do cliente:', err);
    alert('Erro ao atualizar status do cliente: ' + err.message);
    renderKanban();
  } finally {
    document.body.style.cursor = 'default';
  }
}


async function selecionarClienteDashboard(clientId) {
  const select = document.getElementById('dashClienteSelect');
  if (select) {
    select.value = clientId || '';
  }
  const containerGeral = document.getElementById('dashboardGeralContainer');
  const containerCliente = document.getElementById('dashboardClienteContainer');
  const titleEl = document.getElementById('dashboardPageTitle');
  if (!containerGeral || !containerCliente) return;

  const btnLink = document.getElementById('btnFichaLinkCliente');
  if (btnLink) {
    btnLink.style.display = clientId ? 'inline-flex' : 'none';
  }

  if (!clientId) {
    if (titleEl) titleEl.textContent = 'Painel Geral & Operacional';
    containerGeral.classList.remove('hidden');
    containerCliente.classList.add('hidden');
    renderDashboard();
    return;
  }

  const clientInfo = (window.notionClients || []).find(c => c.id === clientId);
  if (titleEl && clientInfo) {
    titleEl.textContent = `Financeiro do Cliente: ${clientInfo.nome || 'Sem nome'}`;
  }

  containerGeral.classList.add('hidden');
  containerCliente.classList.remove('hidden');

  // Set loading state
  document.getElementById('kpiCliRecebido').textContent = 'Carregando...';
  document.getElementById('kpiCliDespesas').textContent = 'Carregando...';
  document.getElementById('kpiCliCustoGuias').textContent = 'Carregando...';
  document.getElementById('kpiCliCaixaAtual').textContent = 'Carregando...';
  document.getElementById('kpiCliLucroProjetadoFinal').textContent = 'Carregando...';

  document.getElementById('cliFichaValorTotal').textContent = '...';
  document.getElementById('cliFichaTotalPago').textContent = '...';
  document.getElementById('cliFichaSaldoPagar').textContent = '...';
  document.getElementById('cliFichaStatusPgto').textContent = '...';

  try {
    const res = await fetch(`/api/dashboard/notion-data/${clientId}`);
    if (!res.ok) throw new Error('Erro ao buscar dados do Notion');
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Erro desconhecido');

    const summary = data.summary;
    const details = data.details;

    window.currentDashboardEntradas = details.entradas || [];
    window.currentDashboardSaidas = details.saidas || [];

    // Fill KPI cards
    document.getElementById('kpiCliRecebido').textContent = `¥ ${summary.totalRecebido.toLocaleString('en-US')}`;
    document.getElementById('kpiCliDespesas').textContent = `¥ ${summary.totalDespesas.toLocaleString('en-US')}`;
    document.getElementById('kpiCliCustoGuias').textContent = `¥ ${summary.custoGuiasTotal.toLocaleString('en-US')}`;
    
    const detEl = document.getElementById('kpiCliCustoGuiasDet');
    if (detEl) {
      detEl.textContent = `¥ ${summary.custoGuiasPago.toLocaleString('en-US')} Pago / ¥ ${summary.custoGuiasPendente.toLocaleString('en-US')} Pendente`;
    }

    document.getElementById('kpiCliCaixaAtual').textContent = `¥ ${summary.caixaAtual.toLocaleString('en-US')}`;

    // Fill client ficha info
    let clientInfo = data.clientInfo || (window.notionClients || []).find(c => c.id === clientId);

    const contrato = clientInfo ? (clientInfo.valorTotal || 0) : 0;
    const lucroProjetadoFinal = contrato - summary.totalDespesas - summary.custoGuiasTotal;

    const lucroProjEl = document.getElementById('kpiCliLucroProjetadoFinal');
    lucroProjEl.textContent = `¥ ${lucroProjetadoFinal.toLocaleString('en-US')}`;
    if (lucroProjetadoFinal < 0) {
      lucroProjEl.style.color = '#e74c3c';
    } else {
      lucroProjEl.style.color = 'var(--crimson)';
    }

    if (clientInfo) {
      document.getElementById('cliFichaValorTotal').textContent = `¥ ${(clientInfo.valorTotal || 0).toLocaleString('en-US')}`;
      document.getElementById('cliFichaTotalPago').textContent = `¥ ${(summary.totalRecebido || clientInfo.totalPago || 0).toLocaleString('en-US')}`;
      const realSaldo = Math.max(0, Math.round((clientInfo.valorTotal || 0) - (summary.totalRecebido || 0)));
      document.getElementById('cliFichaSaldoPagar').textContent = `¥ ${realSaldo.toLocaleString('en-US')}`;
      
      const statusEl = document.getElementById('cliFichaStatusPgto');
      statusEl.textContent = realSaldo <= 0 ? 'Pago' : (summary.totalRecebido > 0 ? 'Parcial' : (clientInfo.statusPagamento || 'Pendente'));
      
      // Color status based on value
      if (statusEl.textContent === 'Pago') {
        statusEl.style.color = '#2ecc71';
        statusEl.style.background = 'rgba(46, 204, 113, 0.1)';
      } else if (statusEl.textContent === 'Parcial' || statusEl.textContent === 'Pendente') {
        statusEl.style.color = '#f1c40f';
        statusEl.style.background = 'rgba(241, 196, 15, 0.1)';
      } else {
        statusEl.style.color = 'var(--ink-lt)';
        statusEl.style.background = 'rgba(0, 0, 0, 0.04)';
      }
    }

    // Render bar chart for comparison
    renderChartCliente(summary.totalRecebido, summary.totalDespesas + summary.custoGuiasTotal, summary.caixaAtual, lucroProjetadoFinal);

    // Populate Tables
    renderTableCliEntradas(details.entradas);
    renderTableCliSaidas(details.saidas);
    renderTableCliTasks(details.tasks);
    renderTableCliGuias(details.guias);

  } catch (err) {
    console.error(err);
    alert('Erro ao carregar dados do dashboard do cliente: ' + err.message);
  }
}

function renderChartCliente(recebido, despesas, caixa, lucro) {
  const ctx = document.getElementById('chartClienteFinanceiro')?.getContext('2d');
  if (!ctx) return;

  if (chartClienteFinanceiro) chartClienteFinanceiro.destroy();

  chartClienteFinanceiro = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Recebido', 'Custos Totais', 'Caixa Líquido', 'Lucro Projetado'],
      datasets: [{
        label: 'Valor (¥)',
        data: [recebido, despesas, caixa, lucro],
        backgroundColor: [
          'rgba(46, 204, 113, 0.75)',
          'rgba(231, 76, 60, 0.75)',
          'rgba(52, 152, 219, 0.75)',
          'rgba(196, 163, 90, 0.75)'
        ],
        borderColor: [
          '#2ecc71',
          '#e74c3c',
          '#3498db',
          '#c4a35a'
        ],
        borderWidth: 1,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return '¥ ' + value.toLocaleString('en-US');
            }
          }
        }
      },
      plugins: {
        legend: {
          display: false
        }
      }
    }
  });
}

function renderTableCliEntradas(entradas) {
  const tbody = document.querySelector('#tableCliEntradas tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!entradas || entradas.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:15px; color:#888;">Nenhum pagamento registrado.</td></tr>';
    return;
  }
  entradas.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${e.data ? fmtDataBR(e.data) : '-'}</td>
      <td><strong>${e.descricao}</strong></td>
      <td><span class="pdf-tag" style="margin-top:0">${e.tipo || '-'}</span></td>
      <td style="text-align:right; font-family:var(--ff-num); font-weight:600; color:#2ecc71">¥ ${e.valor.toLocaleString('en-US')}</td>
      <td style="text-align:center; white-space:nowrap;">
        <button class="btn-icon-tiny" onclick="editarEntradaDash('${e.id}')" title="Editar lançamento no Notion" style="cursor:pointer; background:none; border:none; color:var(--crimson); padding:4px 6px; font-size:14px;">✏️</button>
        <button class="btn-icon-tiny" onclick="excluirEntradaDash('${e.id}')" title="Excluir lançamento no Notion" style="cursor:pointer; background:none; border:none; color:#e74c3c; padding:4px 6px; font-size:14px;">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderTableCliSaidas(saidas) {
  const tbody = document.querySelector('#tableCliSaidas tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!saidas || saidas.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:15px; color:#888;">Nenhuma despesa registrada.</td></tr>';
    return;
  }
  saidas.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${s.data ? fmtDataBR(s.data) : '-'}</td>
      <td><strong>${s.descricao}</strong></td>
      <td><span class="pdf-tag" style="margin-top:0">${s.categoria || '-'}</span></td>
      <td>${s.tipoServico || '-'}</td>
      <td style="text-align:right; font-family:var(--ff-num); font-weight:600; color:#e74c3c">¥ ${s.valor.toLocaleString('en-US')}</td>
      <td style="text-align:center; white-space:nowrap;">
        <button class="btn-icon-tiny" onclick="editarSaidaDash('${s.id}')" title="Editar lançamento no Notion" style="cursor:pointer; background:none; border:none; color:var(--crimson); padding:4px 6px; font-size:14px;">✏️</button>
        <button class="btn-icon-tiny" onclick="excluirSaidaDash('${s.id}')" title="Excluir lançamento no Notion" style="cursor:pointer; background:none; border:none; color:#e74c3c; padding:4px 6px; font-size:14px;">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function renderTableCliTasks(tasks) {
  const tbody = document.querySelector('#tableCliTasks tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (tasks.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:15px; color:#888;">Nenhuma task registrada.</td></tr>';
    return;
  }
  tasks.forEach(t => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${t.dataServico ? fmtDataBR(t.dataServico) : '-'}</td>
      <td><strong>${t.nome}</strong></td>
      <td><span class="pdf-tag" style="margin-top:0">${t.status || '-'}</span></td>
      <td style="text-align:right; font-family:var(--ff-num)">¥ ${t.totalCliente.toLocaleString('en-US')}</td>
      <td style="text-align:right; font-family:var(--ff-num); color:var(--crimson)">¥ ${t.taxa.toLocaleString('en-US')}</td>
      <td style="text-align:right; font-family:var(--ff-num); color:var(--gold-dk)">¥ ${t.lucro.toLocaleString('en-US')}</td>
    `;
    tbody.appendChild(tr);
  });
}

function switchCliDashTab(event, tabId) {
  event.preventDefault();
  const tabContainer = event.target.closest('.card');
  const tabs = tabContainer.querySelectorAll('.tab');
  const tabContents = tabContainer.querySelectorAll('.tab-content');

  tabs.forEach(t => t.classList.remove('active'));
  tabContents.forEach(c => {
    c.classList.remove('active');
    c.style.display = 'none';
  });

  event.target.classList.add('active');
  const activeContent = document.getElementById(tabId);
  if (activeContent) {
    activeContent.classList.add('active');
    activeContent.style.display = 'block';
  }
}

async function carregarAgendaOperacional() {
  const listHoje = document.getElementById('agendaHojeLista');
  const listSemana = document.getElementById('agendaSemanaLista');
  const dateHojeText = document.getElementById('agendaHojeData');
  
  if (!listHoje || !listSemana) return;

  try {
    const hoje = new Date();
    const y = hoje.getFullYear();
    const m = String(hoje.getMonth() + 1).padStart(2, '0');
    const d = String(hoje.getDate()).padStart(2, '0');
    const hojeStr = `${y}-${m}-${d}`;
    
    // Atualizar texto de Hoje
    if (dateHojeText) {
      dateHojeText.textContent = hoje.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    // Buscar eventos
    const res = await fetch('/api/calendario/eventos');
    if (!res.ok) throw new Error('Erro ao buscar eventos');
    const eventos = await res.json();

    // Data de 7 dias à frente
    const limiteSemana = new Date(hoje);
    limiteSemana.setDate(limiteSemana.getDate() + 7);
    const yL = limiteSemana.getFullYear();
    const mL = String(limiteSemana.getMonth() + 1).padStart(2, '0');
    const dL = String(limiteSemana.getDate()).padStart(2, '0');
    const limiteSemanaStr = `${yL}-${mL}-${dL}`;

    // Filtrar eventos de Hoje
    const eventosHoje = eventos.filter(ev => ev.dataServico === hojeStr).sort((a,b) => (a.horaEncontro || '').localeCompare(b.horaEncontro || ''));

    // Filtrar eventos da Semana (excluindo hoje e limitando aos próximos 7 dias)
    const eventosSemana = eventos.filter(ev => ev.dataServico > hojeStr && ev.dataServico <= limiteSemanaStr).sort((a,b) => {
      const dataDiff = a.dataServico.localeCompare(b.dataServico);
      if (dataDiff !== 0) return dataDiff;
      return (a.horaEncontro || '').localeCompare(b.horaEncontro || '');
    });

    // Renderizar lista de Hoje
    renderListaAgenda(eventosHoje, listHoje, true);

    // Renderizar lista de Semana
    renderListaAgenda(eventosSemana, listSemana, false);

  } catch (err) {
    console.error('Erro na agenda operacional:', err);
    listHoje.innerHTML = `<p style="color:#e74c3c; font-size:12px;">Falha ao carregar a agenda.</p>`;
    listSemana.innerHTML = `<p style="color:#e74c3c; font-size:12px;">Falha ao carregar a agenda.</p>`;
  }
}

function renderListaAgenda(eventos, container, ehHoje) {
  container.innerHTML = '';
  if (eventos.length === 0) {
    container.innerHTML = `<p style="color:var(--ink-lt); font-size:12px; font-style:italic; padding:10px 0;">Nenhum serviço agendado para este período.</p>`;
    return;
  }

  eventos.forEach(ev => {
    let tipoClassSuffix = 'transporte';
    const tLower = (ev.tipoServico || '').toLowerCase();
    
    if (tLower.includes('roteiro')) {
      tipoClassSuffix = 'tour';
    } else if (tLower.includes('experiência') || tLower.includes('experiencia')) {
      tipoClassSuffix = 'experiencia';
    } else {
      tipoClassSuffix = 'transporte';
    }

    const dataFormatada = !ehHoje ? fmtDataBRAgenda(ev.dataServico) : '';
    const dateBadge = dataFormatada ? `<span style="font-size:10px; background:rgba(0,0,0,0.06); color:var(--ink-mid); padding:2px 6px; border-radius:4px; font-weight:600;">${dataFormatada}</span>` : '';
    
    // Chips de colaboradores
    const colabs = ev.assignee && ev.assignee.length > 0
      ? `<div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:6px;">
           ${ev.assignee.map(a => `<span style="font-size:10px; background:rgba(107,31,42,0.08); color:var(--crimson); padding:2px 6px; border-radius:12px; font-weight:600; display:inline-flex; align-items:center; gap:2.5px;"><svg class="v-icon" style="stroke:var(--crimson); width:1.1em; height:1.1em; margin-right:0;"><use href="#icon-user"></use></svg>${a.name}</span>`).join('')}
         </div>`
      : `<span style="font-size:10px; color:var(--ink-lt); font-style:italic; display:block; margin-top:6px;">Sem colaborador designado</span>`;

    const hora = ev.horaEncontro ? `${ev.horaEncontro}` : '';
    const local = ev.localEncontro ? `${ev.localEncontro}` : '';
    const details = [hora, local].filter(Boolean).join(' &nbsp;·&nbsp; ');

    const card = document.createElement('div');
    card.className = `calendar-event-item card-type-${tipoClassSuffix}`;
    Object.assign(card.style, {
      padding: '12px 14px',
      borderRadius: '6px',
      borderLeft: '4px solid',
      border: '1px solid',
      boxShadow: '0 2px 8px rgba(0,0,0,0.03)',
      display: 'flex',
      flexDirection: 'column',
      gap: '4px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      marginBottom: '4px',
      whiteSpace: 'normal',
      overflow: 'visible',
      textOverflow: 'clip'
    });

    card.onclick = () => {
      if (typeof window.abrirCalendarioEventModal === 'function') {
        // Altera a aba para calendário e abre o modal
        const navItem = document.querySelector('.sidebar-nav a[data-page="calendario"]');
        if (navItem) {
          navItem.click();
          setTimeout(() => {
            window.abrirCalendarioEventModal(ev.id);
          }, 300);
        }
      }
    };

    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; width:100%; gap:8px;">
        <span style="font-size:13px; font-weight:700; color:var(--ink); line-height:1.3;">${ev.titulo}</span>
        ${dateBadge}
      </div>
      <div style="font-size:11px; color:var(--ink-lt); font-weight:500;">
        Cliente: <strong style="color:var(--ink-mid)">${ev.clienteNome || 'Geral'}</strong>
      </div>
      ${details ? `<div style="font-size:11px; color:var(--ink-mid); font-style:italic; margin-top:2px;">${details}</div>` : ''}
      ${colabs}
    `;

    container.appendChild(card);
  });
}

function fmtDataBRAgenda(str) {
  if(!str) return '—';
  const parts = str.split('-');
  if(parts.length !== 3) return str;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

// --- Novas Funções de Controle Financeiro e Diárias ---

async function inicializarDashboardFinanceiro() {
  try {
    const resContas = await fetch('/api/notion/contas');
    if (resContas.ok) {
      window.notionContas = await resContas.json();
      const selectConta = document.getElementById('modalPagarGuiaConta');
      if (selectConta) {
        selectConta.innerHTML = '<option value="">Selecione uma conta...</option>';
        window.notionContas.forEach(c => {
          const opt = document.createElement('option');
          opt.value = c.id;
          opt.textContent = c.nome;
          selectConta.appendChild(opt);
        });
      }
    }
    const resConfig = await fetch('/api/config');
    if (resConfig.ok) {
      window.appConfig = await resConfig.json();
    }
  } catch (e) {
    console.error('Erro ao inicializar dados financeiros:', e);
  }
}

async function carregarSaldosContas() {
  const container = document.getElementById('saldosContasContainer');
  if (!container) return;

  try {
    const res = await fetch('/api/dashboard/saldos-contas');
    if (!res.ok) throw new Error('Erro ao buscar saldos de contas');
    const contas = await res.json();
    window.notionSaldosContas = contas;
    
    // Aplicar ordenação personalizada do localStorage se houver
    const localOrder = localStorage.getItem('contas_order');
    if (localOrder) {
      try {
        const orderIds = JSON.parse(localOrder);
        contas.sort((a, b) => {
          const idxA = orderIds.indexOf(a.id);
          const idxB = orderIds.indexOf(b.id);
          if (idxA !== -1 && idxB !== -1) return idxA - idxB;
          if (idxA !== -1) return -1;
          if (idxB !== -1) return 1;
          return 0;
        });
      } catch (err) {
        console.error('Erro ao fazer parse da ordem das contas:', err);
      }
    } else {
      contas.sort((a, b) => a.nome.localeCompare(b.nome));
    }

    // 1. Calcular KPIs Consolidados
    let totalCaixaJPY = 0;
    let totalEntradasMesJPY = 0;
    let totalSaidasMesJPY = 0;

    const rateBRL = window.appConfig?.cambio_jpy_brl || 0.031670;
    const rateUSD = window.appConfig?.cambio_jpy_usd || 0.006280;

    const hoje = new Date();
    const anoMesAtual = hoje.toISOString().substring(0, 7); // "yyyy-mm"

    contas.forEach(c => {
      // Caixa consolidado
      totalCaixaJPY += c.saldoJPY;
      if (c.saldoBRL !== 0) {
        totalCaixaJPY += Math.round(c.saldoBRL / rateBRL);
      }
      if (c.saldoUSD !== 0) {
        totalCaixaJPY += Math.round(c.saldoUSD / rateUSD);
      }

      // Entradas e saídas do mês
      (c.movimentacoes || []).forEach(m => {
        if (m.data && m.data.startsWith(anoMesAtual)) {
          const valorMovJPY = m.valorJPY || 0;
          if (m.tipo === 'entrada') {
            totalEntradasMesJPY += valorMovJPY;
          } else {
            totalSaidasMesJPY += valorMovJPY;
          }
        }
      });
    });

    // Renderizar KPIs
    const kpiCaixa = document.getElementById('kpiCaixaConsolidado');
    const kpiEntradas = document.getElementById('kpiEntradasMes');
    const kpiSaidas = document.getElementById('kpiSaidasMes');
    const subkpiEntradas = document.getElementById('subkpiEntradasMes');
    const subkpiSaidas = document.getElementById('subkpiSaidasMes');

    const mesesNomes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    const mesAtualNome = mesesNomes[hoje.getMonth()];

    if (kpiCaixa) kpiCaixa.textContent = `¥ ${totalCaixaJPY.toLocaleString('en-US')}`;
    if (kpiEntradas) kpiEntradas.textContent = `¥ ${totalEntradasMesJPY.toLocaleString('en-US')}`;
    if (kpiSaidas) kpiSaidas.textContent = `¥ ${totalSaidasMesJPY.toLocaleString('en-US')}`;
    if (subkpiEntradas) subkpiEntradas.textContent = `${mesAtualNome} / ${hoje.getFullYear()}`;
    if (subkpiSaidas) subkpiSaidas.textContent = `${mesAtualNome} / ${hoje.getFullYear()}`;

    // Atualizar diárias pendentes na coluna da direita
    if (typeof carregarDiariasPendentesContabilidade === 'function') {
      carregarDiariasPendentesContabilidade();
    }

    container.innerHTML = '';
    if (contas.length === 0) {
      container.innerHTML = '<div style="color:var(--ink-lt); font-size:12px; font-style:italic;">Nenhuma conta encontrada.</div>';
      return;
    }

    contas.forEach(c => {
      const card = document.createElement('div');
      card.className = 'kpi-card account-card';
      card.setAttribute('draggable', 'true');
      card.dataset.id = c.id;
      
      let dragging = false;
      card.addEventListener('dragstart', () => {
        dragging = true;
      });
      card.addEventListener('dragend', () => {
        setTimeout(() => { dragging = false; }, 50);
      });
      card.onclick = () => {
        if (dragging) return;
        abrirVisaoGeralConta(c.id);
      };

      Object.assign(card.style, {
        background: 'var(--warm-white)',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border)',
        boxShadow: 'var(--shadow)',
        display: 'flex',
        flexDirection: 'column',
        gap: '8px',
        transition: 'transform 0.2s, box-shadow 0.2s',
        cursor: 'grab'
      });

      card.onmouseover = () => { 
        card.style.transform = 'translateY(-2px)'; 
        card.style.boxShadow = '0 6px 16px rgba(0,0,0,0.06)'; 
      };
      card.onmouseout = () => { 
        card.style.transform = 'none'; 
        card.style.boxShadow = 'var(--shadow)'; 
      };

      const title = document.createElement('h4');
      Object.assign(title.style, {
        fontSize: '14px',
        color: 'var(--crimson)',
        fontWeight: '700',
        margin: '0',
        textTransform: 'uppercase',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      });
      title.innerHTML = `<span style="display:inline-flex; align-items:center; gap:4px;"><svg class="v-icon" style="margin-right:2px;"><use href="#icon-dollar-sign"></use></svg>${c.nome}</span> <span style="font-size:10px; color:var(--ink-lt); font-weight:500; text-transform:none;">Ver Extrato ➔</span>`;
      card.appendChild(title);

      const saldosWrapper = document.createElement('div');
      Object.assign(saldosWrapper.style, {
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        marginTop: '6px'
      });

      const hasBRL = c.saldoBRL !== 0;
      const hasJPY = c.saldoJPY !== 0;
      const hasUSD = c.saldoUSD !== 0;

      if (!hasBRL && !hasJPY && !hasUSD) {
        const p = document.createElement('p');
        Object.assign(p.style, {
          fontFamily: 'var(--ff-display)',
          fontSize: '18px',
          color: 'var(--ink-mid)',
          margin: '0',
          fontWeight: '600'
        });
        p.textContent = '¥ 0';
        saldosWrapper.appendChild(p);
      } else {
        if (hasJPY) {
          const p = document.createElement('p');
          Object.assign(p.style, {
            fontFamily: 'var(--ff-display)',
            fontSize: '18px',
            color: 'var(--gold-dk)',
            margin: '0',
            fontWeight: '600'
          });
          p.textContent = `¥ ${Math.round(c.saldoJPY).toLocaleString('en-US')}`;
          saldosWrapper.appendChild(p);
        }
        if (hasBRL) {
          const p = document.createElement('p');
          Object.assign(p.style, {
            fontFamily: 'var(--ff-display)',
            fontSize: '18px',
            color: '#2ecc71',
            margin: '0',
            fontWeight: '600'
          });
          p.textContent = `R$ ${c.saldoBRL.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          saldosWrapper.appendChild(p);
        }
        if (hasUSD) {
          const p = document.createElement('p');
          Object.assign(p.style, {
            fontFamily: 'var(--ff-display)',
            fontSize: '18px',
            color: '#3498db',
            margin: '0',
            fontWeight: '600'
          });
          p.textContent = `$ ${c.saldoUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          saldosWrapper.appendChild(p);
        }
      }

      card.appendChild(saldosWrapper);

      // Histórico de Movimentações (10 últimas)
      const movSection = document.createElement('div');
      Object.assign(movSection.style, {
        marginTop: '12px',
        borderTop: '1px dashed var(--border)',
        paddingTop: '10px',
        display: 'flex',
        flexDirection: 'column',
        gap: '6px'
      });

      const movTitle = document.createElement('div');
      Object.assign(movTitle.style, {
        fontSize: '10px',
        fontWeight: '700',
        color: 'var(--ink-lt)',
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
        marginBottom: '2px'
      });
      movTitle.textContent = 'Últimas Movimentações';
      movSection.appendChild(movTitle);

      const ultimas = c.movimentacoes.slice(0, 10);
      if (ultimas.length === 0) {
        const p = document.createElement('div');
        Object.assign(p.style, {
          fontSize: '11px',
          color: 'var(--ink-lt)',
          fontStyle: 'italic',
          padding: '4px 0'
        });
        p.textContent = 'Sem movimentações recentes';
        movSection.appendChild(p);
      } else {
        ultimas.forEach(m => {
          const row = document.createElement('div');
          Object.assign(row.style, {
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            fontSize: '11px',
            gap: '8px'
          });

          const left = document.createElement('div');
          Object.assign(left.style, {
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            color: 'var(--ink-mid)',
            flex: '1'
          });
          
          const color = m.tipo === 'entrada' ? '#2ecc71' : '#e74c3c';
          const dtFormated = m.data ? m.data.substring(5, 10).split('-').reverse().join('/') : '--/--';
          
          left.innerHTML = `<span style="margin-right:6px; color:${color}; font-size:10px;">●</span><span style="font-weight:600; margin-right:4px;">[${dtFormated}]</span><span>${m.descricao}</span>`;
          
          const right = document.createElement('div');
          Object.assign(right.style, {
            fontFamily: 'var(--ff-num)',
            fontWeight: '600',
            color: m.tipo === 'entrada' ? '#2ecc71' : '#e74c3c',
            whiteSpace: 'nowrap'
          });

          let valStr = '';
          if (m.moedaOriginal === 'BRL') valStr = `R$ ${m.valorOriginal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          else if (m.moedaOriginal === 'USD') valStr = `$ ${m.valorOriginal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
          else valStr = `¥ ${Math.round(m.valorOriginal).toLocaleString('en-US')}`;

          right.textContent = `${m.tipo === 'entrada' ? '+' : '-'} ${valStr}`;

          row.appendChild(left);
          row.appendChild(right);
          movSection.appendChild(row);
        });
      }

      card.appendChild(movSection);
      container.appendChild(card);
    });

    // Adicionar eventos de drag and drop no container
    let dragSrcEl = null;

    container.addEventListener('dragstart', (e) => {
      const card = e.target.closest('.account-card');
      if (!card) return;
      dragSrcEl = card;
      e.dataTransfer.effectAllowed = 'move';
      card.style.opacity = '0.4';
      card.style.cursor = 'grabbing';
    });

    container.addEventListener('dragover', (e) => {
      e.preventDefault();
      const targetCard = e.target.closest('.account-card');
      if (targetCard && dragSrcEl && dragSrcEl !== targetCard) {
        const cards = Array.from(container.querySelectorAll('.account-card'));
        const srcIdx = cards.indexOf(dragSrcEl);
        const targetIdx = cards.indexOf(targetCard);
        if (srcIdx < targetIdx) {
          targetCard.after(dragSrcEl);
        } else {
          targetCard.before(dragSrcEl);
        }
      }
      return false;
    });

    container.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      return false;
    });

    container.addEventListener('dragend', (e) => {
      const card = e.target.closest('.account-card');
      if (card) {
        card.style.opacity = '1';
        card.style.cursor = 'grab';
      }
      
      // Salvar a nova ordem no localStorage
      const cards = Array.from(container.querySelectorAll('.account-card'));
      const newOrder = cards.map(el => el.dataset.id);
      localStorage.setItem('contas_order', JSON.stringify(newOrder));
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = '<div style="color:#e74c3c; font-size:12px;">Erro ao carregar saldos.</div>';
  }
}

function renderTableCliGuias(guias) {
  const tbody = document.querySelector('#tableCliGuias tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!guias || guias.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:15px; color:#888;">Nenhuma diária de guia registrada.</td></tr>';
    return;
  }
  guias.forEach(g => {
    const tr = document.createElement('tr');
    const idCheckbox = `chk-guia-${g.id}-${g.colabId}`;
    const isChecked = g.pago ? 'checked disabled' : '';
    const labelStatus = g.pago 
      ? '<span class="pdf-tag" style="background:#2ecc71; color:white; margin:0;">Pago</span>'
      : '<span class="pdf-tag" style="background:#f1c40f; color:white; margin:0;">Pendente</span>';
    
    tr.innerHTML = `
      <td>${g.dataServico ? fmtDataBR(g.dataServico) : '-'}</td>
      <td><strong>${g.titulo}</strong></td>
      <td>${g.colabName}</td>
      <td style="text-align:right; font-family:var(--ff-num); font-weight:600;">¥ ${g.valor.toLocaleString('en-US')}</td>
      <td style="text-align:center; display:flex; align-items:center; justify-content:center; gap:8px; height:100%; border:none;">
        <input type="checkbox" id="${idCheckbox}" ${isChecked} onchange="iniciarPagamentoGuia('${g.id}', '${g.colabId}', '${g.colabName}', '${g.titulo}', ${g.valor})" style="width:16px; height:16px; cursor:pointer;">
        ${labelStatus}
      </td>
      <td style="text-align:center;">
        <button onclick="deletarItemCalendarioTabela('${g.id}', '${g.titulo.replace(/'/g, "\\'")}')" style="background:none; border:none; color:#e74c3c; cursor:pointer; font-size:14px; padding: 4px; display:inline-flex; align-items:center; justify-content:center;" title="Excluir Item do Calendário"><svg class="v-icon no-margin" style="stroke:#e74c3c;"><use href="#icon-trash"></use></svg></button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function deletarItemCalendarioTabela(id, titulo) {
  if (!confirm(`Deseja realmente excluir o dia/serviço "${titulo}" do calendário local e arquivar o card correspondente no Notion? Esta ação não pode ser desfeita.`)) {
    return;
  }
  
  try {
    const res = await fetch(`/api/calendario/eventos/${id}`, {
      method: 'DELETE'
    });
    
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao deletar dia do calendário');
    }
    
    alert('Dia excluído com sucesso do calendário e arquivado no Notion!');
    
    // Recarrega os dados do dashboard do cliente selecionado
    const clientId = document.getElementById('dashClienteSelect').value;
    if (clientId) {
      await selecionarClienteDashboard(clientId);
    }
  } catch (err) {
    console.error(err);
    alert(`Erro ao excluir dia: ${err.message}`);
  }
}

window.iniciarPagamentoGuia = function(eventoId, colaboradorId, colaboradorNome, servicoNome, valorDiaria, clienteId = null) {
  const chk = document.getElementById(`chk-guia-${eventoId}-${colaboradorId}`);
  if (chk && !chk.checked) {
    return;
  }
  
  const ev = typeof calEventos !== 'undefined' ? calEventos.find(e => e.id === eventoId) : null;
  const cliId = clienteId || (ev ? ev.clienteId : null) || document.getElementById('dashClienteSelect')?.value || 'cliente_desconhecido';

  currentPagamentoGuia = {
    eventoId,
    colaboradorId,
    clienteId: cliId,
    valorDiaria
  };

  document.getElementById('modalPagarGuiaServicoInfo').textContent = `Serviço: ${servicoNome}`;
  document.getElementById('modalPagarGuiaColab').value = colaboradorNome;
  
  const selectMoeda = document.getElementById('modalPagarGuiaMoeda');
  selectMoeda.value = 'JPY';
  
  const inputValor = document.getElementById('modalPagarGuiaValor');
  inputValor.value = valorDiaria;
  
  document.getElementById('modalPagarGuiaPreviewJPYWrapper').style.display = 'none';
  
  const modal = document.getElementById('modalPagarGuia');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};
const iniciarPagamentoGuia = window.iniciarPagamentoGuia;

window.fecharModalPagarGuia = function() {
  const modal = document.getElementById('modalPagarGuia');
  modal.style.display = 'none';
  modal.classList.add('hidden');
  modal.classList.remove('active');
  
  if (currentPagamentoGuia) {
    const chk = document.getElementById(`chk-guia-${currentPagamentoGuia.eventoId}-${currentPagamentoGuia.colaboradorId}`);
    if (chk && !chk.disabled) {
      chk.checked = false;
    }
    const sel = document.getElementById(`pago_select_${currentPagamentoGuia.eventoId}`);
    if (sel) {
      sel.value = 'false';
    }
  }
  currentPagamentoGuia = null;
};
const fecharModalPagarGuia = window.fecharModalPagarGuia;

function onChangeMoedaPagarGuia() {
  const moeda = document.getElementById('modalPagarGuiaMoeda').value;
  const valorInput = Number(document.getElementById('modalPagarGuiaValor').value) || 0;
  const wrapper = document.getElementById('modalPagarGuiaPreviewJPYWrapper');
  const previewText = document.getElementById('modalPagarGuiaPreviewJPY');
  
  if (moeda === 'JPY') {
    wrapper.style.display = 'none';
    return;
  }

  let rate = 1;
  if (moeda === 'BRL') {
    rate = window.appConfig?.cambio_jpy_brl || 0.031670;
  } else if (moeda === 'USD') {
    rate = window.appConfig?.cambio_jpy_usd || 0.006280;
  }

  const valorJPY = Math.round(valorInput / rate);
  previewText.textContent = `¥ ${valorJPY.toLocaleString('en-US')} JPY`;
  wrapper.style.display = 'block';
}

// Adicionar eventos e handlers
document.addEventListener('DOMContentLoaded', () => {
  const inputVal = document.getElementById('modalPagarGuiaValor');
  if (inputVal) {
    inputVal.addEventListener('input', onChangeMoedaPagarGuia);
  }

  const btnConfirmar = document.getElementById('btnConfirmarPagarGuia');
  if (btnConfirmar) {
    btnConfirmar.addEventListener('click', async () => {
      if (!currentPagamentoGuia) return;
      
      const contaId = document.getElementById('modalPagarGuiaConta').value;
      const moeda = document.getElementById('modalPagarGuiaMoeda').value;
      const valorInput = Number(document.getElementById('modalPagarGuiaValor').value) || 0;
      
      if (!contaId) {
        alert('Selecione a conta pagadora do Notion.');
        return;
      }
      if (valorInput <= 0) {
        alert('Preencha um valor válido para o pagamento.');
        return;
      }

      document.body.style.cursor = 'progress';
      btnConfirmar.disabled = true;
      const oldText = btnConfirmar.textContent;
      btnConfirmar.textContent = 'Enviando...';

      try {
        const response = await fetch('/api/calendario/pagar-guia', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            eventoId: currentPagamentoGuia.eventoId,
            colaboradorId: currentPagamentoGuia.colaboradorId,
            clienteId: currentPagamentoGuia.clienteId,
            contaId: contaId,
            moeda: moeda,
            valorMoedaOriginal: valorInput
          })
        });

        if (!response.ok) {
          const err = await response.json();
          throw new Error(err.error || 'Erro na requisição');
        }

        alert('Pagamento registrado com sucesso no Supabase e na base de Saídas do Notion!');
        fecharModalPagarGuia();
        
        const clientId = document.getElementById('dashClienteSelect')?.value;
        if (clientId && typeof selecionarClienteDashboard === 'function') {
          await selecionarClienteDashboard(clientId);
        }
        if (typeof filtrarDashColaborador === 'function' && typeof calSelectedColaboradorId !== 'undefined' && calSelectedColaboradorId) {
          filtrarDashColaborador();
        }
        await carregarSaldosContas();
        
      } catch (err) {
        console.error(err);
        alert('Erro ao registrar pagamento: ' + err.message);
      } finally {
        document.body.style.cursor = 'default';
        btnConfirmar.disabled = false;
        btnConfirmar.textContent = oldText;
      }
    });
  }
});

// --- Modal de Visão Geral e Extrato de Conta ---

function abrirVisaoGeralConta(contaId) {
  const conta = (window.notionSaldosContas || []).find(c => c.id === contaId);
  if (!conta) return;

  window.currentVisaoGeralContaId = contaId;

  // Preencher título
  document.getElementById('modalVisaoGeralContaTitulo').textContent = `Extrato da Conta: ${conta.nome}`;

  // Preencher link para editar a conta no Notion
  const linkEditar = document.getElementById('modalVisaoGeralContaEditarLink');
  if (linkEditar) {
    linkEditar.href = `https://notion.so/${conta.id.replace(/-/g, '')}`;
  }

  // Preencher select de meses/anos com base nas movimentações
  const selectFiltro = document.getElementById('modalVisaoGeralContaMesFiltro');
  selectFiltro.innerHTML = '<option value="">Todos os meses</option>';

  const periodosUnicos = new Set();
  conta.movimentacoes.forEach(m => {
    if (m.data && m.data.length >= 7) {
      periodosUnicos.add(m.data.substring(0, 7)); // yyyy-mm
    }
  });

  const periodosSorted = Array.from(periodosUnicos).sort().reverse();
  const mesesNomes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

  periodosSorted.forEach(p => {
    const parts = p.split('-');
    const ano = parts[0];
    const mesIndex = parseInt(parts[1]) - 1;
    const opt = document.createElement('option');
    opt.value = p;
    opt.textContent = `${mesesNomes[mesIndex]} / ${ano}`;
    selectFiltro.appendChild(opt);
  });

  // Chamar função de filtro inicial (Todos os meses)
  onFiltroMesVisaoGeralConta();

  // Exibir modal
  const modal = document.getElementById('modalVisaoGeralConta');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
}

function fecharModalVisaoGeralConta() {
  const modal = document.getElementById('modalVisaoGeralConta');
  modal.style.display = 'none';
  modal.classList.add('hidden');
  modal.classList.remove('active');
  window.currentVisaoGeralContaId = null;
}

function onFiltroMesVisaoGeralConta() {
  const contaId = window.currentVisaoGeralContaId;
  const conta = (window.notionSaldosContas || []).find(c => c.id === contaId);
  if (!conta) return;

  const periodo = document.getElementById('modalVisaoGeralContaMesFiltro').value; // yyyy-mm ou ""

  // Filtrar
  const filtradas = periodo
    ? conta.movimentacoes.filter(m => m.data && m.data.startsWith(periodo))
    : conta.movimentacoes;

  // Calcular balanço do período filtrado
  const balanco = {
    JPY: { entradas: 0, saidas: 0 },
    BRL: { entradas: 0, saidas: 0 },
    USD: { entradas: 0, saidas: 0 }
  };

  filtradas.forEach(m => {
    const moeda = m.moedaOriginal || 'JPY';
    const val = Number(m.valorOriginal) || 0;
    if (m.tipo === 'entrada') {
      if (balanco[moeda]) balanco[moeda].entradas += val;
    } else {
      if (balanco[moeda]) balanco[moeda].saidas += val;
    }
  });

  // Renderizar Balanço no display
  const balancoWrapper = document.getElementById('modalVisaoGeralContaBalancoWrapper');
  balancoWrapper.innerHTML = '';

  const moedasAtivas = Object.keys(balanco).filter(moeda => balanco[moeda].entradas !== 0 || balanco[moeda].saidas !== 0);

  if (moedasAtivas.length === 0) {
    balancoWrapper.innerHTML = '<span style="color:var(--ink-lt); font-style:italic;">Sem movimentações no período selecionado.</span>';
  } else {
    moedasAtivas.forEach(moeda => {
      const data = balanco[moeda];
      const saldo = data.entradas - data.saidas;
      
      let symb = '¥';
      let format = (v) => Math.round(v).toLocaleString('en-US');
      
      if (moeda === 'BRL') {
        symb = 'R$';
        format = (v) => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      } else if (moeda === 'USD') {
        symb = '$';
        format = (v) => v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }

      const div = document.createElement('div');
      Object.assign(div.style, {
        background: 'rgba(255,255,255,0.8)',
        padding: '6px 12px',
        borderRadius: '6px',
        border: '1px solid var(--border)',
        display: 'flex',
        flexWrap: 'wrap',
        gap: '8px',
        fontWeight: '500'
      });

      const spanEntradas = `<span style="color:#2ecc71;">Entradas: +${symb}${format(data.entradas)}</span>`;
      const spanSaidas = `<span style="color:#e74c3c;">Saídas: -${symb}${format(data.saidas)}</span>`;
      const spanSaldo = `<strong style="color:${saldo >= 0 ? '#2ecc71' : '#e74c3c'}">Balanço: ${saldo >= 0 ? '+' : ''}${symb}${format(saldo)}</strong>`;

      div.innerHTML = `${spanEntradas} | ${spanSaidas} | ${spanSaldo}`;
      balancoWrapper.appendChild(div);
    });
  }

  // Preencher Tabela
  const tbody = document.querySelector('#tableModalVisaoGeralConta tbody');
  tbody.innerHTML = '';

  if (filtradas.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:20px; color:#888; font-style:italic;">Nenhuma movimentação para o período.</td></tr>';
    return;
  }

  filtradas.forEach(m => {
    const tr = document.createElement('tr');
    
    // Formatar data
    let dateStr = '-';
    if (m.data) {
      const parts = m.data.split('-');
      if (parts.length === 3) dateStr = `${parts[2]}/${parts[1]}/${parts[0]}`;
    }

    const tipoLabel = m.tipo === 'entrada'
      ? '<span style="background:rgba(46, 204, 113, 0.1); color:#2ecc71; padding:2px 8px; border-radius:4px; font-weight:600; font-size:11px; display:inline-flex; align-items:center; gap:4px;"><span style="color:#2ecc71;">●</span> Entrada</span>'
      : '<span style="background:rgba(231, 76, 60, 0.1); color:#e74c3c; padding:2px 8px; border-radius:4px; font-weight:600; font-size:11px; display:inline-flex; align-items:center; gap:4px;"><span style="color:#e74c3c;">●</span> Saída</span>';

    let valorOrigStr = '';
    if (m.moedaOriginal === 'BRL') valorOrigStr = `R$ ${m.valorOriginal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    else if (m.moedaOriginal === 'USD') valorOrigStr = `$ ${m.valorOriginal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    else valorOrigStr = `¥ ${Math.round(m.valorOriginal).toLocaleString('en-US')}`;

    const notionPageUrl = `https://notion.so/${m.id.replace(/-/g, '')}`;
    const btnAcao = `<a href="${notionPageUrl}" target="_blank" class="btn-secondary" style="padding: 4px 10px; font-size: 11px; text-decoration: none; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid var(--border);"><svg class="v-icon no-margin" style="stroke:var(--ink-mid); width:1.1em; height:1.1em;"><use href="#icon-edit"></use></svg> Editar no Notion</a>`;

    tr.innerHTML = `
      <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04);">${dateStr}</td>
      <td style="padding: 10px 12px; border-bottom:1px solid rgba(0,0,0,0.04);">${tipoLabel}</td>
      <td style="padding: 10px 12px; font-size: 12px; font-weight:500; border-bottom:1px solid rgba(0,0,0,0.04);">${m.descricao}</td>
      <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); color:var(--ink-mid);">${m.clienteNome || '-'}</td>
      <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); color:var(--ink-mid);">${m.colaboradorNome || '-'}</td>
      <td style="padding: 10px 12px; text-align: right; font-family:var(--ff-num); font-size: 12px; font-weight:600; color:${m.tipo === 'entrada' ? '#2ecc71' : '#e74c3c'}; border-bottom:1px solid rgba(0,0,0,0.04);">${valorOrigStr}</td>
      <td style="padding: 10px 12px; text-align: right; font-family:var(--ff-num); font-size: 12px; font-weight:600; border-bottom:1px solid rgba(0,0,0,0.04);">¥ ${Math.round(m.valorJPY).toLocaleString('en-US')}</td>
      <td style="padding: 10px 12px; text-align: center; border-bottom:1px solid rgba(0,0,0,0.04);">${btnAcao}</td>
    `;
    tbody.appendChild(tr);
  });
}

// --- Modal de Registrar Entrada / Recebimento de Cliente ---

window.copiarLinkClienteFromId = async function(clientId) {
  if (!clientId || clientId === 'Geral') {
    alert('Selecione um cliente no menu superior para copiar o link correspondente.');
    return;
  }

  // O link agora vem do servidor, já com o token de acesso (?t=...) do portal
  let link = '';
  try {
    const res = await fetch('/api/clientes/' + encodeURIComponent(clientId) + '/portal-link');
    if (res.ok) {
      const data = await res.json();
      if (data && data.url) link = data.url;
    }
  } catch (e) {
    console.error('Erro ao gerar link do portal no servidor:', e);
  }

  // Fallback local (sem token) caso o servidor não responda
  if (!link) {
    const clientInfo = (window.notionClients || []).find(c => c.id === clientId);
    if (clientInfo && clientInfo.nome) {
      const slug = clientInfo.nome.toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/--+/g, '-')
        .trim();
      link = `${window.location.origin}/cliente/${slug}`;
    } else {
      link = `${window.location.origin}/cliente.html?id=${clientId}`;
    }
  }

  navigator.clipboard.writeText(link).then(() => {
    alert('Link da Área do Cliente copiado com sucesso para a área de transferência!');
  }).catch(err => {
    console.error('Erro ao copiar link:', err);
    const tempInput = document.createElement('input');
    tempInput.value = link;
    document.body.appendChild(tempInput);
    tempInput.select();
    try {
      document.execCommand('copy');
      alert('Link da Área do Cliente copiado com sucesso!');
    } catch (e) {
      alert('Não foi possível copiar o link automaticamente. Copie manualmente: ' + link);
    }
    document.body.removeChild(tempInput);
  });
};

window.copiarLinkCliente = function() {
  const clientId = document.getElementById('dashClienteSelect').value;
  window.copiarLinkClienteFromId(clientId);
};

async function abrirModalRegistrarEntrada() {
  const clienteId = document.getElementById('dashClienteSelect').value;
  if (!clienteId) {
    alert('Selecione um cliente primeiro.');
    return;
  }

  // Preencher descrição padrão com o nome do cliente selecionado
  const selectCli = document.getElementById('dashClienteSelect');
  const clienteNome = selectCli.options[selectCli.selectedIndex].text;
  document.getElementById('modalRegistrarEntradaDesc').value = `Pagamento - ${clienteNome}`;
  
  // Preencher e desabilitar o select de cliente do modal
  const selectCliModal = document.getElementById('modalRegistrarEntradaCliente');
  if (selectCliModal) {
    selectCliModal.innerHTML = '';
    const opt = document.createElement('option');
    opt.value = clienteId;
    opt.textContent = clienteNome;
    selectCliModal.appendChild(opt);
    selectCliModal.value = clienteId;
    selectCliModal.disabled = true;
  }
  
  // Resetar outros campos
  document.getElementById('modalRegistrarEntradaMoeda').value = 'JPY';
  document.getElementById('modalRegistrarEntradaValor').value = '';
  document.getElementById('modalRegistrarEntradaPreviewJPYWrapper').style.display = 'none';
  { const _j = document.getElementById('modalRegistrarEntradaValorJPY'); if (_j) _j.value = ''; const _c = document.getElementById('modalRegistrarEntradaCambio'); if (_c) _c.value = ''; const _w = document.getElementById('modalRegistrarEntradaConvWrapper'); if (_w) _w.style.display = 'none'; }
  document.getElementById('modalRegistrarEntradaData').value = new Date().toISOString().substring(0, 10);

  // Carregar contas
  const selectConta = document.getElementById('modalRegistrarEntradaConta');
  selectConta.innerHTML = '<option value="">Selecione a conta receptora...</option>';

  try {
    const res = await fetch('/api/notion/contas');
    if (!res.ok) throw new Error('Erro ao buscar contas');
    const contas = await res.json();
    
    contas.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectConta.appendChild(opt);
    });
  } catch (err) {
    console.error(err);
    selectConta.innerHTML = '<option value="">Erro ao carregar contas</option>';
  }

  // Exibir modal
  const modal = document.getElementById('modalRegistrarEntrada');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
}

function fecharModalRegistrarEntrada() {
  const modal = document.getElementById('modalRegistrarEntrada');
  if (modal) {
    modal.style.display = 'none';
    modal.classList.add('hidden');
    modal.classList.remove('active');
  }
  const editEl = document.getElementById('modalRegistrarEntradaEditId');
  if (editEl) editEl.value = '';
  const titleEl = document.querySelector('#modalRegistrarEntrada .event-modal-title');
  if (titleEl) titleEl.textContent = 'Registrar Recebimento';
  const btnBtn = document.getElementById('btnConfirmarRegistrarEntrada');
  if (btnBtn) btnBtn.textContent = 'Confirmar Recebimento';
}

function fecharModalRegistrarSaida() {
  const modal = document.getElementById('modalRegistrarSaida');
  if (modal) {
    modal.style.display = 'none';
    modal.classList.add('hidden');
    modal.classList.remove('active');
  }
  const editEl = document.getElementById('modalRegistrarSaidaEditId');
  if (editEl) editEl.value = '';
  const titleEl = document.querySelector('#modalRegistrarSaida .event-modal-title');
  if (titleEl) titleEl.textContent = 'Registrar Pagamento / Despesa';
  const btnBtn = document.getElementById('btnConfirmarRegistrarSaida');
  if (btnBtn) btnBtn.textContent = 'Confirmar Pagamento';
}

// ── FUNÇÕES DE EDIÇÃO E EXCLUSÃO DE ENTRADAS E SAÍDAS NO DASHBOARD ─────────────
window.editarEntradaDash = async function(id) {
  const e = (window.currentDashboardEntradas || []).find(x => x.id === id);
  if (!e) {
    alert('Informações da entrada não encontradas.');
    return;
  }

  document.getElementById('modalRegistrarEntradaEditId').value = id;
  document.getElementById('modalRegistrarEntradaDesc').value = e.descricao || '';
  document.getElementById('modalRegistrarEntradaValor').value = e.valorOriginal || e.valor;
  document.getElementById('modalRegistrarEntradaMoeda').value = e.moeda || 'JPY';
  document.getElementById('modalRegistrarEntradaData').value = e.data || new Date().toISOString().substring(0, 10);
  if (document.getElementById('modalRegistrarEntradaValorJPY')) {
    document.getElementById('modalRegistrarEntradaValorJPY').value = e.valor || '';
  }

  const titleEl = document.querySelector('#modalRegistrarEntrada .event-modal-title');
  if (titleEl) titleEl.textContent = 'Editar Recebimento (Entrada)';
  const btnBtn = document.getElementById('btnConfirmarRegistrarEntrada');
  if (btnBtn) btnBtn.textContent = 'Salvar Alterações';

  const selectConta = document.getElementById('modalRegistrarEntradaConta');
  selectConta.innerHTML = '<option value="">Carregando contas...</option>';
  try {
    const res = await fetch('/api/notion/contas');
    if (res.ok) {
      const contas = await res.json();
      selectConta.innerHTML = '<option value="">Selecione a conta...</option>';
      contas.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.nome;
        selectConta.appendChild(opt);
      });
      if (e.contaId) selectConta.value = e.contaId;
    }
  } catch (err) {
    console.error(err);
  }

  onMoedaChangeRegistrarEntrada();

  const modal = document.getElementById('modalRegistrarEntrada');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};

window.excluirEntradaDash = async function(id) {
  if (!confirm('Tem certeza de que deseja excluir este recebimento no Notion?')) return;
  document.body.style.cursor = 'wait';
  try {
    const res = await fetch(`/api/notion/entradas/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao excluir');
    }
    alert('Recebimento excluído com sucesso no Notion!');
    const clientId = document.getElementById('dashClienteSelect').value;
    if (typeof selecionarClienteDashboard === 'function') {
      await selecionarClienteDashboard(clientId);
    }
    if (typeof carregarSaldosContas === 'function') {
      await carregarSaldosContas();
    }
  } catch (err) {
    console.error(err);
    alert('Erro ao excluir recebimento: ' + err.message);
  } finally {
    document.body.style.cursor = 'default';
  }
};

window.editarSaidaDash = async function(id) {
  const s = (window.currentDashboardSaidas || []).find(x => x.id === id);
  if (!s) {
    alert('Informações da saída não encontradas.');
    return;
  }

  document.getElementById('modalRegistrarSaidaEditId').value = id;
  document.getElementById('modalRegistrarSaidaDesc').value = s.descricao || '';
  document.getElementById('modalRegistrarSaidaValor').value = s.valor || '';
  document.getElementById('modalRegistrarSaidaData').value = s.data || new Date().toISOString().substring(0, 10);

  const titleEl = document.querySelector('#modalRegistrarSaida .event-modal-title');
  if (titleEl) titleEl.textContent = 'Editar Saída / Despesa';
  const btnBtn = document.getElementById('btnConfirmarRegistrarSaida');
  if (btnBtn) btnBtn.textContent = 'Salvar Alterações';

  const selectConta = document.getElementById('modalRegistrarSaidaConta');
  selectConta.innerHTML = '<option value="">Carregando contas...</option>';
  try {
    const res = await fetch('/api/notion/contas');
    if (res.ok) {
      const contas = await res.json();
      selectConta.innerHTML = '<option value="">Selecione a conta...</option>';
      contas.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.nome;
        selectConta.appendChild(opt);
      });
      if (s.contaId) selectConta.value = s.contaId;
    }
  } catch (err) {
    console.error(err);
  }

  const modal = document.getElementById('modalRegistrarSaida');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};

window.excluirSaidaDash = async function(id) {
  if (!confirm('Tem certeza de que deseja excluir esta saída/despesa no Notion?')) return;
  document.body.style.cursor = 'wait';
  try {
    const res = await fetch(`/api/notion/saidas/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Erro ao excluir');
    }
    alert('Saída/Despesa excluída com sucesso no Notion!');
    const clientId = document.getElementById('dashClienteSelect').value;
    if (typeof selecionarClienteDashboard === 'function') {
      await selecionarClienteDashboard(clientId);
    }
    if (typeof carregarSaldosContas === 'function') {
      await carregarSaldosContas();
    }
  } catch (err) {
    console.error(err);
    alert('Erro ao excluir saída: ' + err.message);
  } finally {
    document.body.style.cursor = 'default';
  }
};

function updatePreviewEntrada() {
  const moeda = document.getElementById('modalRegistrarEntradaMoeda').value;
  const wrapper = document.getElementById('modalRegistrarEntradaPreviewJPYWrapper');
  const previewText = document.getElementById('modalRegistrarEntradaPreviewJPY');
  if (!wrapper) return;
  const rs = Number(document.getElementById('modalRegistrarEntradaValor').value) || 0;
  const jp = Number(document.getElementById('modalRegistrarEntradaValorJPY')?.value) || 0;
  if (moeda === 'JPY' || jp <= 0) { wrapper.style.display = 'none'; return; }
  const sim = moeda === 'BRL' ? 'R$' : '$';
  let txt = '';
  if (rs > 0) txt += `Cobrar ${sim} ${rs.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} · `;
  txt += `credita ¥ ${jp.toLocaleString('en-US')}`;
  previewText.textContent = txt;
  wrapper.style.display = 'flex';
}

// Equação: valor a cobrar (R$/$) = ¥ que quita × câmbio turismo. O ¥ (a obrigação) é a âncora.
// Câmbio digitado -> se já tem o ¥, calcula o R$ A COBRAR do cliente; senão, calcula o ¥ pelo R$.
// (Setar .value via JS não dispara os handlers dos outros campos, então não há loop.)
function syncEntradaFromCambio() {
  const rs = Number(document.getElementById('modalRegistrarEntradaValor').value) || 0;
  const ipr = Number(document.getElementById('modalRegistrarEntradaCambio').value) || 0; // ienes por real
  const jp = Number(document.getElementById('modalRegistrarEntradaValorJPY').value) || 0;
  if (ipr > 0 && jp > 0) {
    document.getElementById('modalRegistrarEntradaValor').value = (jp / ipr).toFixed(2);  // R$ a cobrar = ¥ / (ienes por real)
  } else if (ipr > 0 && rs > 0) {
    document.getElementById('modalRegistrarEntradaValorJPY').value = Math.round(rs * ipr);
  }
  updatePreviewEntrada();
}

// ¥ digitado -> se já tem o câmbio, calcula o R$ a cobrar; senão, calcula o câmbio pelo R$.
function syncEntradaFromJPY() {
  const rs = Number(document.getElementById('modalRegistrarEntradaValor').value) || 0;
  const ipr = Number(document.getElementById('modalRegistrarEntradaCambio').value) || 0;
  const jp = Number(document.getElementById('modalRegistrarEntradaValorJPY').value) || 0;
  if (jp > 0 && ipr > 0) {
    document.getElementById('modalRegistrarEntradaValor').value = (jp / ipr).toFixed(2);
  } else if (jp > 0 && rs > 0) {
    document.getElementById('modalRegistrarEntradaCambio').value = (jp / rs).toFixed(2); // ienes por real = ¥ / R$
  }
  updatePreviewEntrada();
}

function onMoedaChangeRegistrarEntrada() {
  const moeda = document.getElementById('modalRegistrarEntradaMoeda').value;
  const conv = document.getElementById('modalRegistrarEntradaConvWrapper');
  const unidade = document.getElementById('modalRegistrarEntradaCambioUnidade');
  if (conv) conv.style.display = (moeda === 'JPY') ? 'none' : 'flex';
  if (unidade) unidade.textContent = moeda === 'USD' ? '(ienes por dólar)' : '(ienes por real)';
  updatePreviewEntrada();
}

function onValorChangeRegistrarEntrada() {
  // Digitou o R$ a cobrar: com o ¥ preenchido, recalcula o câmbio (ienes/real); senão, com câmbio, recalcula o ¥.
  const rs = Number(document.getElementById('modalRegistrarEntradaValor')?.value) || 0;
  const ipr = Number(document.getElementById('modalRegistrarEntradaCambio')?.value) || 0;
  const jp = Number(document.getElementById('modalRegistrarEntradaValorJPY')?.value) || 0;
  if (rs > 0 && jp > 0) {
    document.getElementById('modalRegistrarEntradaCambio').value = (jp / rs).toFixed(2);
  } else if (rs > 0 && ipr > 0) {
    document.getElementById('modalRegistrarEntradaValorJPY').value = Math.round(rs * ipr);
  }
  updatePreviewEntrada();
}

// Configurar o listener para confirmar o recebimento
document.addEventListener('DOMContentLoaded', () => {
  const btnConfirmar = document.getElementById('btnConfirmarRegistrarEntrada');
  if (btnConfirmar) {
    btnConfirmar.addEventListener('click', async () => {
      const editId = document.getElementById('modalRegistrarEntradaEditId').value;
      let clienteId = document.getElementById('modalRegistrarEntradaCliente').value;
      if (!clienteId) {
        clienteId = document.getElementById('dashClienteSelect').value;
      }
      
      const descricao = document.getElementById('modalRegistrarEntradaDesc').value.trim();
      const moeda = document.getElementById('modalRegistrarEntradaMoeda').value;
      const valorOriginal = Number(document.getElementById('modalRegistrarEntradaValor').value) || 0;
      const contaId = document.getElementById('modalRegistrarEntradaConta').value;
      const data = document.getElementById('modalRegistrarEntradaData').value;
      const valorJPYManual = Number(document.getElementById('modalRegistrarEntradaValorJPY')?.value) || 0;

      if (!clienteId || clienteId === 'Geral') {
        alert('Selecione o cliente vinculado ao pagamento.');
        return;
      }
      if (!descricao) {
        alert('Por favor, insira a descrição da entrada.');
        return;
      }
      if (valorOriginal <= 0) {
        alert('Por favor, insira um valor válido maior que zero.');
        return;
      }
      if (!contaId) {
        alert('Por favor, selecione a conta receptora.');
        return;
      }
      if (moeda !== 'JPY' && valorJPYManual <= 0) {
        alert('Informe o valor em iene (¥) que este pagamento quita.');
        return;
      }

      const oldText = btnConfirmar.textContent;
      btnConfirmar.disabled = true;
      btnConfirmar.textContent = 'Gravando...';
      document.body.style.cursor = 'wait';

      try {
        const url = editId ? `/api/notion/entradas/${editId}` : '/api/notion/registrar-entrada';
        const method = editId ? 'PUT' : 'POST';

        const response = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clienteId,
            descricao,
            valorOriginal,
            moeda,
            valorJPYManual,
            contaId,
            data
          })
        });

        if (!response.ok) {
          const err = await response.json();
          throw new Error(err.error || 'Erro na requisição');
        }

        alert(editId ? 'Recebimento atualizado com sucesso no Notion!' : 'Recebimento registrado com sucesso no Notion!');
        fecharModalRegistrarEntrada();

        // Recarregar os dados do cliente e os saldos/extrato de contabilidade
        const clientId = document.getElementById('dashClienteSelect').value;
        if (typeof selecionarClienteDashboard === 'function') {
          await selecionarClienteDashboard(clientId);
        }
        if (typeof carregarSaldosContas === 'function') {
          await carregarSaldosContas();
        }

      } catch (err) {
        console.error(err);
        alert('Erro ao salvar recebimento: ' + err.message);
      } finally {
        document.body.style.cursor = 'default';
        btnConfirmar.disabled = false;
        btnConfirmar.textContent = oldText;
      }
    });
  }

  // Configurar o listener para confirmar a saída/pagamento
  const btnConfirmarSaida = document.getElementById('btnConfirmarRegistrarSaida');
  if (btnConfirmarSaida) {
    btnConfirmarSaida.addEventListener('click', async () => {
      const editId = document.getElementById('modalRegistrarSaidaEditId').value;
      const descricao = document.getElementById('modalRegistrarSaidaDesc').value.trim();
      const moeda = document.getElementById('modalRegistrarSaidaMoeda').value;
      const valorOriginal = Number(document.getElementById('modalRegistrarSaidaValor').value) || 0;
      const contaId = document.getElementById('modalRegistrarSaidaConta').value;
      const data = document.getElementById('modalRegistrarSaidaData').value;
      const clienteId = document.getElementById('modalRegistrarSaidaCliente').value;
      const colaboradorId = document.getElementById('modalRegistrarSaidaColab').value;
      const eventoId = document.getElementById('modalRegistrarSaidaEventoId').value;
      const taskId = document.getElementById('modalRegistrarSaidaTask')?.value || undefined;

      if (!descricao) {
        alert('Por favor, insira a descrição da saída.');
        return;
      }
      if (valorOriginal <= 0) {
        alert('Por favor, insira um valor válido maior que zero.');
        return;
      }
      if (!contaId) {
        alert('Por favor, selecione a conta debitada.');
        return;
      }

      const oldText = btnConfirmarSaida.textContent;
      btnConfirmarSaida.disabled = true;
      btnConfirmarSaida.textContent = 'Gravando...';
      document.body.style.cursor = 'wait';

      try {
        const url = editId ? `/api/notion/saidas/${editId}` : '/api/notion/registrar-saida';
        const method = editId ? 'PUT' : 'POST';

        const response = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clienteId: clienteId || undefined,
            colaboradorId: colaboradorId || undefined,
            eventoId: eventoId || undefined,
            descricao,
            valorOriginal,
            moeda,
            contaId,
            data,
            taskId: taskId || undefined
          })
        });

        if (!response.ok) {
          const err = await response.json();
          throw new Error(err.error || 'Erro na requisição');
        }

        alert(editId ? 'Saída atualizada com sucesso no Notion!' : 'Saída registrada com sucesso no Notion!');
        fecharModalRegistrarSaida();

        // Recarregar os dados do cliente e os saldos/extrato de contabilidade
        const clientId = document.getElementById('dashClienteSelect').value;
        if (clientId && clientId !== 'Geral' && typeof selecionarClienteDashboard === 'function') {
          await selecionarClienteDashboard(clientId);
        }
        if (typeof carregarSaldosContas === 'function') {
          await carregarSaldosContas();
        }

      } catch (err) {
        console.error(err);
        alert('Erro ao salvar saída: ' + err.message);
      } finally {
        document.body.style.cursor = 'default';
        btnConfirmarSaida.disabled = false;
        btnConfirmarSaida.textContent = oldText;
      }
    });
  }
});

// --- Novas Funções de Ações Financeiras Rápidas da Contabilidade ---

window.abrirModalRegistrarEntradaGeral = async function() {
  // Resetar campos
  document.getElementById('modalRegistrarEntradaDesc').value = 'Recebimento de Cliente';
  document.getElementById('modalRegistrarEntradaMoeda').value = 'JPY';
  document.getElementById('modalRegistrarEntradaValor').value = '';
  document.getElementById('modalRegistrarEntradaPreviewJPYWrapper').style.display = 'none';
  { const _j = document.getElementById('modalRegistrarEntradaValorJPY'); if (_j) _j.value = ''; const _c = document.getElementById('modalRegistrarEntradaCambio'); if (_c) _c.value = ''; const _w = document.getElementById('modalRegistrarEntradaConvWrapper'); if (_w) _w.style.display = 'none'; }
  document.getElementById('modalRegistrarEntradaData').value = new Date().toISOString().substring(0, 10);

  // Popular select de clientes com a lista global notionClients
  const selectCliModal = document.getElementById('modalRegistrarEntradaCliente');
  if (selectCliModal) {
    selectCliModal.innerHTML = '<option value="">Selecione o cliente...</option>';
    const clientes = window.notionClients || [];
    clientes.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectCliModal.appendChild(opt);
    });
    selectCliModal.disabled = false;
  }

  // Carregar contas
  const selectConta = document.getElementById('modalRegistrarEntradaConta');
  selectConta.innerHTML = '<option value="">Selecione a conta receptora...</option>';

  try {
    const res = await fetch('/api/notion/contas');
    if (!res.ok) throw new Error('Erro ao buscar contas');
    const contas = await res.json();
    
    contas.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectConta.appendChild(opt);
    });
  } catch (err) {
    console.error(err);
    selectConta.innerHTML = '<option value="">Erro ao carregar contas</option>';
  }

  // Exibir modal
  const modal = document.getElementById('modalRegistrarEntrada');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};

window.abrirModalRegistrarSaidaGeral = async function() {
  // Resetar campos
  document.getElementById('modalRegistrarSaidaDesc').value = '';
  document.getElementById('modalRegistrarSaidaMoeda').value = 'JPY';
  document.getElementById('modalRegistrarSaidaValor').value = '';
  document.getElementById('modalRegistrarSaidaPreviewJPYWrapper').style.display = 'none';
  document.getElementById('modalRegistrarSaidaData').value = new Date().toISOString().substring(0, 10);
  document.getElementById('modalRegistrarSaidaEventoId').value = '';

  // Carregar contas
  const selectConta = document.getElementById('modalRegistrarSaidaConta');
  selectConta.innerHTML = '<option value="">Selecione a conta debitada...</option>';

  // Carregar clientes
  const selectCli = document.getElementById('modalRegistrarSaidaCliente');
  selectCli.innerHTML = '<option value="">Nenhum cliente (Despesa geral)</option>';

  // Carregar colaboradores
  const selectColab = document.getElementById('modalRegistrarSaidaColab');
  selectColab.innerHTML = '<option value="">Nenhum colaborador</option>';

  // Setup select de Tasks
  const selectTask = document.getElementById('modalRegistrarSaidaTask');
  if (selectTask) {
    selectTask.innerHTML = '<option value="">Selecione um cliente primeiro...</option>';
  }

  // Função para carregar as tasks do cliente
  window.carregarTasksDoClienteNoModal = async function(clientId) {
    if (!selectTask) return;
    if (!clientId) {
      selectTask.innerHTML = '<option value="">Selecione um cliente primeiro...</option>';
      return;
    }
    selectTask.innerHTML = '<option value="">Carregando serviços...</option>';
    try {
      const res = await fetch(`/api/notion/tasks-cliente/${clientId}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      selectTask.innerHTML = '<option value="">Nenhum (Despesa avulsa)</option>';
      if (data.success && data.tasks && data.tasks.length > 0) {
        data.tasks.forEach(t => {
          const opt = document.createElement('option');
          opt.value = t.id;
          opt.textContent = t.nome;
          selectTask.appendChild(opt);
        });
      }
    } catch (e) {
      console.error(e);
      selectTask.innerHTML = '<option value="">Erro ao carregar serviços</option>';
    }
  };

  selectCli.onchange = function() {
    window.carregarTasksDoClienteNoModal(this.value);
  };

  try {
    // 1. Contas
    const res = await fetch('/api/notion/contas');
    if (!res.ok) throw new Error('Erro ao buscar contas');
    const contas = await res.json();
    contas.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectConta.appendChild(opt);
    });

    // 2. Clientes
    const clis = window.notionClients || [];
    clis.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectCli.appendChild(opt);
    });

    // 3. Colaboradores
    const colabs = window.calColaboradores || [];
    colabs.forEach(col => {
      const opt = document.createElement('option');
      opt.value = col.id;
      opt.textContent = col.name;
      selectColab.appendChild(opt);
    });

    // Se já houver um cliente selecionado na tela do dashboard
    const currentClientId = document.getElementById('dashClienteSelect')?.value || '';
    if (currentClientId && currentClientId !== 'Geral') {
      selectCli.value = currentClientId;
      window.carregarTasksDoClienteNoModal(currentClientId);
    } else {
      window.carregarTasksDoClienteNoModal('');
    }

  } catch (err) {
    console.error(err);
    selectConta.innerHTML = '<option value="">Erro ao carregar contas</option>';
  }

  // Exibir modal
  const modal = document.getElementById('modalRegistrarSaida');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};

window.fecharModalRegistrarSaida = function() {
  const modal = document.getElementById('modalRegistrarSaida');
  modal.style.display = 'none';
  modal.classList.add('hidden');
  modal.classList.remove('active');
};

window.onMoedaChangeRegistrarSaida = function() {
  onValorChangeRegistrarSaida();
};

window.onValorChangeRegistrarSaida = function() {
  const moeda = document.getElementById('modalRegistrarSaidaMoeda').value;
  const valorInput = Number(document.getElementById('modalRegistrarSaidaValor').value) || 0;
  const wrapper = document.getElementById('modalRegistrarSaidaPreviewJPYWrapper');
  const previewText = document.getElementById('modalRegistrarSaidaPreviewJPY');

  if (moeda === 'JPY' || valorInput === 0) {
    wrapper.style.display = 'none';
    return;
  }

  const rateBRL = window.appConfig?.cambio_jpy_brl || 0.031670;
  const rateUSD = window.appConfig?.cambio_jpy_usd || 0.006280;

  let estimadoJPY = 0;
  if (moeda === 'BRL') {
    estimadoJPY = Math.round(valorInput / rateBRL);
  } else if (moeda === 'USD') {
    estimadoJPY = Math.round(valorInput / rateUSD);
  }

  previewText.textContent = `¥ ${estimadoJPY.toLocaleString('en-US')}`;
  wrapper.style.display = 'flex';
};

// --- Funções de Gestão de Diárias Pendentes na Contabilidade ---

window.carregarDiariasPendentesContabilidade = async function() {
  const container = document.getElementById('diarasPendentesContabilidadeContainer');
  if (!container) return;

  try {
    const res = await fetch('/api/financeiro/diarias-pendentes');
    if (!res.ok) throw new Error('Erro ao buscar diárias pendentes');
    const diarias = await res.json();

    container.innerHTML = '';
    if (diarias.length === 0) {
      container.innerHTML = `
        <div style="text-align:center; padding: 24px; color: var(--ink-lt); font-style: italic; font-size: 13px;">
          Todas as diárias de guias foram pagas!
        </div>`;
      return;
    }

    diarias.forEach(d => {
      const item = document.createElement('div');
      Object.assign(item.style, {
        background: 'rgba(0,0,0,0.01)',
        border: '1px solid var(--border)',
        borderRadius: '8px',
        padding: '12px 14px',
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        fontSize: '12px'
      });

      // Formatação de data
      let dateStr = d.dataServico || '';
      if (dateStr) {
        const parts = dateStr.split('-');
        if (parts.length === 3) dateStr = `${parts[2]}/${parts[1]}/${parts[0]}`;
      }

      item.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:4px;">
          <strong style="color:var(--crimson); font-size:13px; display:inline-flex; align-items:center; gap:2.5px;"><svg class="v-icon" style="stroke:var(--crimson); width:1.1em; height:1.1em; margin-right:0;"><use href="#icon-user"></use></svg>${d.colaboradorNome}</strong>
          <span style="font-size:10px; background:rgba(0,0,0,0.05); color:var(--ink-mid); padding:2px 6px; border-radius:4px; font-weight:600;">${dateStr}</span>
        </div>
        <div style="font-weight:600; color:var(--ink-dk); margin-top:2px;">${d.eventoTitulo}</div>
        <div style="font-size:11px; color:var(--ink-lt);">
          Cliente: <span style="color:var(--ink-mid); font-weight:500;">${d.clienteNome}</span>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px; border-top:1px dashed var(--border); padding-top:8px;">
          <span style="font-family:var(--ff-num); font-size:13px; font-weight:700; color:var(--gold-dk);">¥ ${d.valorDiaria.toLocaleString('en-US')}</span>
          <button class="btn-primary" onclick="iniciarPagamentoGuiaDeContabilidade('${d.eventoId}', '${d.colaboradorId}', '${d.colaboradorNome}', '${d.eventoTitulo}', ${d.valorDiaria}, '${d.clienteId}')" style="margin:0; padding:6px 12px; font-size:11px; border-radius:6px; font-weight:600; background-color:#e74c3c; border-color:#c0392b;">
            Pagar Guia
          </button>
        </div>
      `;
      container.appendChild(item);
    });

  } catch (err) {
    console.error('Erro ao carregar diárias pendentes:', err);
    container.innerHTML = '<div style="color:#e74c3c; font-size:12px;">Erro ao carregar diárias pendentes.</div>';
  }
};

window.iniciarPagamentoGuiaDeContabilidade = async function(eventoId, colaboradorId, colaboradorNome, servicoNome, valorDiaria, clienteId) {
  currentPagamentoGuia = {
    eventoId,
    colaboradorId,
    clienteId: clienteId || 'cliente_desconhecido',
    valorDiaria
  };

  document.getElementById('modalPagarGuiaServicoInfo').textContent = `Serviço: ${servicoNome}`;
  document.getElementById('modalPagarGuiaColab').value = colaboradorNome;
  
  const selectMoeda = document.getElementById('modalPagarGuiaMoeda');
  selectMoeda.value = 'JPY';
  
  const inputValor = document.getElementById('modalPagarGuiaValor');
  inputValor.value = valorDiaria;
  
  document.getElementById('modalPagarGuiaPreviewJPYWrapper').style.display = 'none';
  
  // Carregar contas
  const selectConta = document.getElementById('modalPagarGuiaConta');
  selectConta.innerHTML = '<option value="">Carregando contas...</option>';
  
  try {
    const res = await fetch('/api/notion/contas');
    if (!res.ok) throw new Error('Erro ao buscar contas');
    const contas = await res.json();
    
    selectConta.innerHTML = '<option value="">Selecione a conta pagadora...</option>';
    contas.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      selectConta.appendChild(opt);
    });
  } catch (err) {
    console.error(err);
    selectConta.innerHTML = '<option value="">Erro ao carregar contas</option>';
  }

  const modal = document.getElementById('modalPagarGuia');
  modal.style.display = 'flex';
  modal.classList.remove('hidden');
  modal.classList.add('active');
};

// Exposição explícita de funções globais do dashboard
window.selecionarClienteDashboard = selecionarClienteDashboard;
window.carregarSaldosContas = carregarSaldosContas;
window.renderDashboard = renderDashboard;

window.currentResumoMensalTipo = null;
window.currentResumoMensalTransacoes = null;

window.abrirResumoMensal = function(tipo) {
  window.currentResumoMensalTipo = tipo;

  // Preencher Título
  const tituloEl = document.getElementById('modalResumoMensalTitulo');
  if (tituloEl) {
    tituloEl.textContent = tipo === 'entrada' 
      ? 'Histórico Mensal: Recebimentos' 
      : 'Histórico Mensal: Pagamentos / Despesas';
  }

  // Coletar todas as transações daquele tipo (entradas ou saídas) de TODAS as contas
  const transacoes = [];
  const periodosUnicos = new Set();

  (window.notionSaldosContas || []).forEach(conta => {
    (conta.movimentacoes || []).forEach(m => {
      if (m.tipo === tipo) {
        // Enriquecer a transação com o nome da conta para a tabela
        transacoes.push({
          ...m,
          contaNome: conta.nome
        });
        if (m.data && m.data.length >= 7) {
          periodosUnicos.add(m.data.substring(0, 7)); // yyyy-mm
        }
      }
    });
  });

  // Salvar a lista consolidada globalmente no modal
  window.currentResumoMensalTransacoes = transacoes;

  // Ordenar transações por data decrescente
  transacoes.sort((a, b) => (b.data || '').localeCompare(a.data || ''));

  // Preencher select de meses/anos
  const selectFiltro = document.getElementById('modalResumoMensalMesFiltro');
  if (selectFiltro) {
    selectFiltro.innerHTML = '';

    const periodosSorted = Array.from(periodosUnicos).sort().reverse();
    const mesesNomes = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

    // Descobrir qual é o período padrão (mês atual)
    const hoje = new Date();
    const anoMesAtual = hoje.toISOString().substring(0, 7); // "yyyy-mm"

    let selecionouAlgum = false;
    periodosSorted.forEach(p => {
      const parts = p.split('-');
      const ano = parts[0];
      const mesIndex = parseInt(parts[1]) - 1;
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = `${mesesNomes[mesIndex]} / ${ano}`;
      
      // Deixar selecionado o mês atual por padrão se ele existir
      if (p === anoMesAtual) {
        opt.selected = true;
        selecionouAlgum = true;
      }
      
      selectFiltro.appendChild(opt);
    });

    // Se o mês atual não tem transações, seleciona o mês mais recente disponível
    if (!selecionouAlgum && periodosSorted.length > 0) {
      selectFiltro.value = periodosSorted[0];
    }
  }

  // Chamar filtro
  window.onFiltroMesResumoMensal();

  // Exibir modal
  const modal = document.getElementById('modalResumoMensal');
  if (modal) {
    modal.style.display = 'flex';
    modal.classList.remove('hidden');
    modal.classList.add('active');
  }
};

window.fecharModalResumoMensal = function() {
  const modal = document.getElementById('modalResumoMensal');
  if (modal) {
    modal.style.display = 'none';
    modal.classList.add('hidden');
    modal.classList.remove('active');
  }
  window.currentResumoMensalTipo = null;
  window.currentResumoMensalTransacoes = null;
};

window.onFiltroMesResumoMensal = function() {
  const selectFiltro = document.getElementById('modalResumoMensalMesFiltro');
  if (!selectFiltro) return;
  const periodo = selectFiltro.value;
  const transacoes = window.currentResumoMensalTransacoes || [];

  const filtradas = periodo
    ? transacoes.filter(m => m.data && m.data.startsWith(periodo))
    : transacoes;

  // Calcular totais
  const balanco = { JPY: 0, BRL: 0, USD: 0 };
  filtradas.forEach(m => {
    const moeda = m.moedaOriginal || 'JPY';
    const val = Number(m.valorOriginal) || 0;
    if (balanco[moeda] !== undefined) {
      balanco[moeda] += val;
    }
  });

  // Renderizar Balanço no display
  const balancoWrapper = document.getElementById('modalResumoMensalBalancoWrapper');
  if (balancoWrapper) {
    balancoWrapper.innerHTML = '';

    const moedasAtivas = Object.keys(balanco).filter(moeda => balanco[moeda] !== 0);

    if (moedasAtivas.length === 0) {
      balancoWrapper.innerHTML = '<span style="color:var(--ink-lt); font-style:italic;">Sem movimentações no período.</span>';
    } else {
      const spans = moedasAtivas.map(moeda => {
        let symb = '¥';
        let format = (v) => Math.round(v).toLocaleString('en-US');
        if (moeda === 'BRL') {
          symb = 'R$';
          format = (v) => v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        } else if (moeda === 'USD') {
          symb = '$';
          format = (v) => v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
        const label = window.currentResumoMensalTipo === 'entrada' ? 'Recebido' : 'Pago';
        const color = window.currentResumoMensalTipo === 'entrada' ? '#2ecc71' : '#e74c3c';
        return `<span style="color:${color}; font-weight:700;">Total ${label}: ${symb}${format(balanco[moeda])}</span>`;
      });
      balancoWrapper.innerHTML = spans.join(' | ');
    }
  }

  // Preencher Tabela
  const tbody = document.querySelector('#tableModalResumoMensal tbody');
  if (tbody) {
    tbody.innerHTML = '';

    if (filtradas.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:20px; color:#888; font-style:italic;">Nenhuma movimentação para o período.</td></tr>';
      return;
    }

    filtradas.forEach(m => {
      const tr = document.createElement('tr');
      
      // Formatar data
      let dateStr = '-';
      if (m.data) {
        const parts = m.data.split('-');
        if (parts.length === 3) dateStr = `${parts[2]}/${parts[1]}/${parts[0]}`;
      }

      let valorOrigStr = '';
      if (m.moedaOriginal === 'BRL') valorOrigStr = `R$ ${m.valorOriginal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      else if (m.moedaOriginal === 'USD') valorOrigStr = `$ ${m.valorOriginal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      else valorOrigStr = `¥ ${Math.round(m.valorOriginal).toLocaleString('en-US')}`;

      const valorJPYStr = `¥ ${Math.round(m.valorJPY || 0).toLocaleString('en-US')}`;

      const clientName = m.clienteNome || '-';
      const colabName = m.colaboradorNome || '-';

      const notionPageUrl = `https://notion.so/${m.id.replace(/-/g, '')}`;
      const btnAcao = `<a href="${notionPageUrl}" target="_blank" class="btn-secondary" style="padding: 4px 10px; font-size: 11px; text-decoration: none; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid var(--border);"><svg class="v-icon no-margin" style="stroke:var(--ink-mid); width:1.1em; height:1.1em;"><use href="#icon-edit"></use></svg> Editar no Notion</a>`;

      tr.innerHTML = `
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04);">${dateStr}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); font-weight:600; color:var(--ink-mid);">${m.contaNome || '-'}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); font-weight:500;" title="${m.descricao || ''}">${m.descricao || '-'}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); color:var(--crimson); font-weight:500;">${clientName}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04);">${colabName}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); text-align:right; font-weight:600; font-family:var(--ff-num); color:${window.currentResumoMensalTipo === 'entrada' ? '#2ecc71' : '#e74c3c'};">${valorOrigStr}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); text-align:right; font-weight:600; font-family:var(--ff-num); color:${window.currentResumoMensalTipo === 'entrada' ? '#2ecc71' : '#e74c3c'};">${valorJPYStr}</td>
        <td style="padding: 10px 12px; font-size: 12px; border-bottom:1px solid rgba(0,0,0,0.04); text-align:center;">${btnAcao}</td>
      `;
      tbody.appendChild(tr);
    });
  }
};
