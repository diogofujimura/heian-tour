// GitHub Actions FTP Auto-Deploy Configured - Build 2026-06-19-02
require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

const NOTION_TOKEN = process.env.NOTION_API_KEY;
const NOTION_CLIENTS_DB_ID = process.env.NOTION_CLIENTS_DB_ID;

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

const nodemailer = require('nodemailer');

// Configuração do transporter do Gmail
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASS
  }
});

// Helper para converter string de data/hora do serviço em objeto Date
function obterDataHoraServico(dataStr, horaStr) {
  if (!dataStr) return new Date();
  const [ano, mes, dia] = dataStr.split('-').map(Number);
  let hora = 9;
  let min = 0;
  if (horaStr && typeof horaStr === 'string' && horaStr.includes(':')) {
    const parts = horaStr.split(':');
    hora = parseInt(parts[0], 10) || 9;
    min = parseInt(parts[1], 10) || 0;
  }
  return new Date(ano, mes - 1, dia, hora, min, 0, 0);
}

// Função para obter emails de colaboradores no Notion
async function obterColaboradoresEmails() {
  const colaboradoresMap = {};
  if (!NOTION_TOKEN) return colaboradoresMap;
  try {
    const DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';
    const response = await fetch(`https://api.notion.com/v1/databases/${DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      }
    });
    if (response.ok) {
      const data = await response.json();
      (data.results || []).forEach(item => {
        const nameProp = item.properties.Name || item.properties.Nome;
        const name = nameProp?.title?.[0]?.plain_text || 'Sem Nome';
        const email = item.properties.Email?.email || '';
        if (email) {
          colaboradoresMap[item.id] = { name, email: email.trim() };
        }
      });
    }
  } catch (e) {
    console.error('[Email Init] Erro ao carregar colaboradores do Notion:', e);
  }
  return colaboradoresMap;
}

// Helper para gerar o link do Google Agenda convertendo horário JST para UTC
function gerarLinkGoogleAgenda(evento, horaStr) {
  try {
    const dataStr = evento.dataServico; // YYYY-MM-DD
    if (!dataStr) return '';
    const [ano, mes, dia] = dataStr.split('-').map(Number);
    let hora = 9;
    let min = 0;
    if (horaStr && typeof horaStr === 'string' && horaStr.includes(':')) {
      const parts = horaStr.split(':');
      hora = parseInt(parts[0], 10) || 9;
      min = parseInt(parts[1], 10) || 0;
    }

    // Converter para UTC sabendo que a hora do evento é JST (UTC+9)
    const dataInicioUTC = new Date(Date.UTC(ano, mes - 1, dia, hora - 9, min, 0));
    
    // Determinar a duração padrão (em milissegundos)
    let duracaoMs = 8 * 60 * 60 * 1000; // 8 horas padrão para Roteiro
    if (evento.tipoServico === 'Experiência' || evento.expInfo) {
      duracaoMs = 2 * 60 * 60 * 1000; // 2 horas
    } else if (evento.tipoServico === 'Transporte' || evento.transportInfo) {
      if (evento.transportInfo && evento.transportInfo.tempo) {
        const tempoStr = evento.transportInfo.tempo.toLowerCase();
        const matchHoras = tempoStr.match(/(\d+)\s*(?:hora|h)/);
        if (matchHoras) {
          const h = parseInt(matchHoras[1], 10);
          duracaoMs = h * 60 * 60 * 1000;
        } else {
          duracaoMs = 2 * 60 * 60 * 1000; // 2h fallback
        }
      } else {
        duracaoMs = 2 * 60 * 60 * 1000; // 2h fallback
      }
    } else if (evento.tipoServico === 'Roteiro') {
      if (evento.duracaoTour) {
        const duracaoStr = evento.duracaoTour.toLowerCase();
        const matchHoras = duracaoStr.match(/(\d+)\s*(?:hora|h)/);
        if (matchHoras) {
          const h = parseInt(matchHoras[1], 10);
          duracaoMs = h * 60 * 60 * 1000;
        }
      }
    }

    const dataFimUTC = new Date(dataInicioUTC.getTime() + duracaoMs);

    const formatarDataGoogle = (date) => {
      return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    };

    const datesParam = `${formatarDataGoogle(dataInicioUTC)}/${formatarDataGoogle(dataFimUTC)}`;
    const textParam = encodeURIComponent(`[Heian Tour] ${evento.titulo}`);
    
    // Montar descrição detalhada
    let desc = `Tipo de Serviço: ${evento.tipoServico}\n`;
    desc += `Horário de Encontro JST: ${horaStr}\n`;
    desc += `Ponto de Encontro: ${evento.localEncontro || 'Não informado'}\n`;
    if (evento.clienteNome) {
      desc += `Cliente: ${evento.clienteNome}\n`;
    }
    
    if (evento.transportInfo) {
      const t = evento.transportInfo;
      desc += `\nRota: ${t.origem || '-'} ➔ ${t.destino || '-'}\n`;
      desc += `Tipo de Transporte: ${t.tipoTransporte || '-'}\n`;
      if (t.linha) desc += `Linha: ${t.linha}\n`;
      if (t.categoria) desc += `Assento/Categoria: ${t.categoria}\n`;
      if (t.tempo) desc += `Duração: ${t.tempo}\n`;
    } else if (evento.expInfo) {
      const e = evento.expInfo;
      desc += `\nExperiência: ${e.nomeExp || evento.titulo}\n`;
      if (e.horaPartida) desc += `Horário de Entrada: ${e.horaPartida}\n`;
    } else if (evento.tipoServico === 'Roteiro') {
      desc += `\nDuração: ${evento.duracaoTour || 'Dia inteiro'}\n`;
    }

    desc += `\nGerado automaticamente por Heian Tour. Tenha um excelente trabalho!`;
    const detailsParam = encodeURIComponent(desc);
    const locationParam = encodeURIComponent(evento.localEncontro || '');

    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${textParam}&dates=${datesParam}&details=${detailsParam}&location=${locationParam}`;
  } catch (error) {
    console.error('[Google Calendar] Erro ao gerar link:', error);
    return '';
  }
}

// Helper para formatar data YYYY-MM-DD para DD/MM
function formatarDataAssunto(dataStr) {
  if (!dataStr || !dataStr.includes('-')) return '';
  const parts = dataStr.split('-');
  if (parts.length < 3) return '';
  return `${parts[2]}/${parts[1]}`;
}

// Helper para formatar data YYYY-MM-DD para formato extenso PT-BR (ex: 14 de Junho de 2026)
function formatarDataExtenso(dataStr) {
  if (!dataStr || !dataStr.includes('-')) return dataStr || '';
  const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  const parts = dataStr.split('-');
  if (parts.length < 3) return dataStr;
  const dia = parseInt(parts[2], 10);
  const mesIndex = parseInt(parts[1], 10) - 1;
  const ano = parts[0];
  const nomeMes = meses[mesIndex] || '';
  // Adicionar dia da semana
  const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
  const dateObj = new Date(parseInt(ano), mesIndex, dia);
  const nomeDia = diasSemana[dateObj.getDay()] || '';
  return `${nomeDia}, ${dia} de ${nomeMes} de ${ano}`;
}

// Helper para buscar o hotel do cliente com base na data do serviço
async function buscarHotelPorData(evento) {
  try {
    // 1. Tentar buscar via roteiroNome (aceita ID imutável ou nome de exibição)
    if (evento.roteiroNome) {
      const linhaRot = await acharRoteiroPorChaveOuNome(evento.roteiroNome);
      if (linhaRot && linhaRot.data) {
        const roteiro = linhaRot.data;
        const estadias = roteiro.estadias || [];
        if (estadias.length > 0 && evento.dataServico) {
          // Encontrar a estadia que cobre a data do serviço
          for (const est of estadias) {
            if (est.dataInicio && est.dataFim && est.hotel) {
              if (evento.dataServico >= est.dataInicio && evento.dataServico <= est.dataFim) {
                return { hotel: est.hotel, cidade: est.cidade || '' };
              }
            }
          }
          // Fallback: retornar a primeira estadia que tenha hotel
          const comHotel = estadias.find(e => e.hotel);
          if (comHotel) return { hotel: comHotel.hotel, cidade: comHotel.cidade || '' };
        }
      }
    }

    // 2. Tentar buscar via clienteId nos dados locais do cliente
    if (evento.clienteId && evento.clienteId !== 'cliente_desconhecido') {
      const { data: localData } = await supabase.from('clientes_locais').select('data').eq('id', evento.clienteId).single();
      if (localData && localData.data) {
        const estadias = localData.data.estadias || [];
        if (estadias.length > 0 && evento.dataServico) {
          for (const est of estadias) {
            if (est.dataInicio && est.dataFim && est.hotel) {
              if (evento.dataServico >= est.dataInicio && evento.dataServico <= est.dataFim) {
                return { hotel: est.hotel, cidade: est.cidade || '' };
              }
            }
          }
          const comHotel = estadias.find(e => e.hotel);
          if (comHotel) return { hotel: comHotel.hotel, cidade: comHotel.cidade || '' };
        }
      }
    }

    return null;
  } catch (err) {
    console.error('[Hotel Lookup] Erro ao buscar hotel:', err.message);
    return null;
  }
}

// Função para disparar os e-mails
async function enviarEmailColaborador({ email, nomeColaborador, evento, tipo }) {
  if (process.env.ENABLE_EMAIL_NOTIFICATIONS !== 'true') {
    console.log(`[Email] Envio de notificação [${tipo}] para ${email} ignorado (Desativado no .env)`);
    return false;
  }
  let assunto = '';
  let tituloEmail = '';
  let subtituloEmail = '';
  let corDestaque = '#89232D'; // Vermelho Heian Oficial (Exato da Logo)

  const dataFormatada = formatarDataAssunto(evento.dataServico);
  const dataPrefixo = dataFormatada ? `${dataFormatada} - ` : '';

  if (tipo === 'cadastro') {
    assunto = `[Heian Tour] Nova atividade designada: ${dataPrefixo}${evento.titulo}`;
    tituloEmail = 'Nova Atividade Designada';
    subtituloEmail = `Olá <strong>${nomeColaborador}</strong>, você foi designado para uma nova atividade no calendário da Heian Tour.`;
  } else if (tipo === '24h') {
    assunto = `[Heian Tour] Lembrete 24h: ${dataPrefixo}${evento.titulo}`;
    tituloEmail = 'Lembrete de Atividade (24 horas)';
    subtituloEmail = `Olá <strong>${nomeColaborador}</strong>, este é um lembrete automático de que você tem uma atividade amanhã.`;
  } else if (tipo === '1h') {
    assunto = `[Heian Tour] Lembrete 1h: ${dataPrefixo}${evento.titulo}`;
    tituloEmail = 'Lembrete de Atividade (1 hora)';
    subtituloEmail = `Olá <strong>${nomeColaborador}</strong>, sua atividade inicia em aproximadamente 1 hora!`;
    corDestaque = '#d35400'; // Laranja para urgência
  }

  let hora = evento.horaEncontro || '09:00';
  if (evento.tipoServico === 'Roteiro') {
    hora = evento.horaEncontro || '09:00';
  } else if (evento.tipoServico === 'Experiência' || evento.expInfo) {
    hora = evento.expInfo?.horaPartida || evento.horaEncontro || 'Padrão';
  } else if (evento.tipoServico === 'Transporte' || evento.transportInfo) {
    hora = evento.transportInfo?.horario || evento.horaEncontro || 'Padrão';
  }

  let pontoEncontro = evento.localEncontro || 'Não informado';

  let detalhesExtras = '';
  if (evento.transportInfo) {
    const t = evento.transportInfo;
    detalhesExtras = `
      <p style="margin: 5px 0;"><strong>Rota:</strong> ${t.origem || '-'} ➔ ${t.destino || '-'}</p>
      <p style="margin: 5px 0;"><strong>Tipo de Transporte:</strong> ${t.tipoTransporte || '-'}</p>
      ${t.linha ? `<p style="margin: 5px 0;"><strong>Linha:</strong> ${t.linha}</p>` : ''}
      ${t.categoria ? `<p style="margin: 5px 0;"><strong>Assento/Categoria:</strong> ${t.categoria}</p>` : ''}
      ${t.tempo ? `<p style="margin: 5px 0;"><strong>Duração da viagem:</strong> ${t.tempo}</p>` : ''}
    `;
  } else if (evento.expInfo) {
    const e = evento.expInfo;
    detalhesExtras = `
      <p style="margin: 5px 0;"><strong>Experiência:</strong> ${e.nomeExp || evento.titulo}</p>
      <p style="margin: 5px 0;"><strong>Horário de Entrada:</strong> ${e.horaPartida || '-'}</p>
    `;
  } else if (evento.tipoServico === 'Roteiro') {
    detalhesExtras = `
      <p style="margin: 5px 0;"><strong>Duração Estimada:</strong> ${evento.duracaoTour || 'Dia inteiro'}</p>
    `;
  }

  // Gerar o link do Google Agenda
  const linkGoogleAgenda = gerarLinkGoogleAgenda(evento, hora);

  // Formatar data por extenso
  const dataExtenso = formatarDataExtenso(evento.dataServico);

  // Buscar hotel do cliente para a data do serviço
  let hotelInfo = null;
  let googleMapsUrl = '';
  try {
    hotelInfo = await buscarHotelPorData(evento);
    if (hotelInfo && hotelInfo.hotel) {
      // Buscar se existe esse hotel cadastrado no Supabase na tabela config com id: hoteis
      const { data: cfgHoteis } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
      const hoteis = cfgHoteis && cfgHoteis.data ? cfgHoteis.data : [];
      const hotelNomePlanilha = hotelInfo.hotel.trim().toLowerCase();
      const hotelRico = hoteis.find(h => {
        const hNome = (h['Nome do Hotel'] || '').trim().toLowerCase();
        return hNome === hotelNomePlanilha || hotelNomePlanilha.includes(hNome) || hNome.includes(hotelNomePlanilha);
      });
      if (hotelRico && hotelRico['Link do Google Maps']) {
        googleMapsUrl = hotelRico['Link do Google Maps'];
      }
    }
  } catch (e) {
    console.error('[Email] Erro ao buscar hotel na base:', e.message);
  }

  // Fallback se não encontrou link específico cadastrado na base de dados
  if (hotelInfo && hotelInfo.hotel && !googleMapsUrl) {
    googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hotelInfo.hotel + (hotelInfo.cidade ? ', ' + hotelInfo.cidade + ', Japan' : ', Japan'))}`;
  }

  // Montar linha do hotel com link do Google Maps
  let hotelHtml = '';
  if (hotelInfo && hotelInfo.hotel) {
    hotelHtml = `
            <tr>
              <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; vertical-align: top;">Hotel:</td>
              <td class="value-text" style="padding: 6px 0; font-size: 14px;">
                <a class="hotel-link" href="${googleMapsUrl}" target="_blank" style="color: #89232D; text-decoration: underline; font-weight: 500;">${hotelInfo.hotel}</a>
                ${hotelInfo.cidade ? `<span style="color: #888; font-size: 12px;"> (${hotelInfo.cidade})</span>` : ''}
              </td>
            </tr>
    `;
  }

  const html = `
<!DOCTYPE html>
<html lang="pt-BR" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="color-scheme" content="light dark">
  <meta name="supported-color-schemes" content="light dark">
  <title>${assunto}</title>
  <style>
    :root {
      color-scheme: light dark;
      supported-color-schemes: light dark;
    }
    /* Estilos nativos para clientes de e-mail que suportam media queries de tema */
    @media (prefers-color-scheme: dark) {
      .email-body {
        background-color: #121212 !important;
        color: #ffffff !important;
      }
      .email-card {
        background-color: #1e1e1e !important;
        color: #e0e0e0 !important;
        border-color: #333333 !important;
      }
      .card-details {
        background-color: #2a2a2a !important;
        border-color: #444444 !important;
      }
      .anti-dark-bg {
        background-color: #89232D !important;
        background-image: linear-gradient(#89232D, #89232D) !important;
      }
      .anti-dark-text {
        color: #ffffff !important;
      }
      .hotel-link {
        color: #ff6b7a !important;
      }
      .label-text {
        color: #aaaaaa !important;
      }
      .value-text {
        color: #ffffff !important;
      }
      /* Forçar cores de parágrafo e cabeçalhos no modo escuro */
      p, td, h3, h4, span {
        color: #e0e0e0 !important;
      }
      a {
        color: #ff6b7a !important;
      }
    }
  </style>
</head>
<body class="email-body" style="margin: 0; padding: 0; background-color: #f9f9f9; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%;">
  <div class="email-card" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 30px auto; border: 1px solid #e0e0e0; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05); background-color: #ffffff; color: #333333;">
    <!-- Cabeçalho com Barra Premium (anti-dark-mode) -->
    <table cellpadding="0" cellspacing="0" role="presentation" width="100%" style="width: 100%; border-collapse: collapse; border: 0;">
      <tr>
        <td class="anti-dark-bg" bgcolor="#89232D" style="background-color: #89232D !important; background-image: linear-gradient(#89232D, #89232D) !important; padding: 0;">
          <table cellpadding="0" cellspacing="0" role="presentation" width="100%" style="width: 100%; border-collapse: collapse;">
            <tr>
              <td class="anti-dark-bg" style="padding: 10px 0 10px 25px; text-align: left; vertical-align: middle; width: 55%; background-color: #89232D !important; background-image: linear-gradient(#89232D, #89232D) !important;">
                <img src="cid:logo_heian" alt="Heian Tour" style="height: 72px; width: auto; max-width: 100%; display: block; object-fit: contain;">
              </td>
              <td class="anti-dark-bg" style="padding: 10px 25px 10px 0; text-align: right; vertical-align: middle; width: 45%; background-color: #89232D !important; background-image: linear-gradient(#89232D, #89232D) !important;">
                <p class="anti-dark-text" style="margin: 0; font-size: 13px; color: #f0f0f0; opacity: 0.9; text-transform: uppercase; letter-spacing: 1px; font-weight: bold;">${tituloEmail}</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    
    <!-- Conteúdo Principal -->
    <div style="padding: 30px 35px; color: #333333; line-height: 1.6;">
      <p style="font-size: 15px; margin-top: 0; color: #444444;">${subtituloEmail}</p>
      
      <div class="card-details" style="background-color: #fafafa; border-left: 4px solid ${corDestaque}; padding: 18px; border-radius: 4px; margin: 20px 0; border-top: 1px solid #f0f0f0; border-right: 1px solid #f0f0f0; border-bottom: 1px solid #f0f0f0;">
        <h3 style="margin-top: 0; color: #1a1a1a; font-size: 16px; border-bottom: 1px solid #eef0f2; padding-bottom: 8px;">Detalhes do Serviço</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; width: 130px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">Atividade:</td>
            <td class="value-text" style="padding: 6px 0; font-weight: 500; font-size: 14px; color: #1a1a1a;">${evento.titulo}</td>
          </tr>
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">Tipo:</td>
            <td class="value-text" style="padding: 6px 0; font-size: 14px;">${evento.tipoServico}</td>
          </tr>
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">📅 Data:</td>
            <td class="value-text" style="padding: 6px 0; font-weight: bold; color: #1a1a1a; font-size: 15px;">${dataExtenso}</td>
          </tr>
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">⏰ Hora:</td>
            <td class="value-text" style="padding: 6px 0; font-weight: bold; color: ${corDestaque}; font-size: 15px;">${hora}</td>
          </tr>
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">Encontro:</td>
            <td class="value-text" style="padding: 6px 0; font-size: 14px;">${pontoEncontro}</td>
          </tr>
          ${hotelHtml}
          ${evento.clienteNome ? `
          <tr>
            <td class="label-text" style="padding: 6px 0; padding-right: 12px; font-weight: 600; color: #666; font-size: 14px; white-space: nowrap;">Cliente:</td>
            <td class="value-text" style="padding: 6px 0; font-size: 14px;">${evento.clienteNome}</td>
          </tr>
          ` : ''}
        </table>
      </div>
      
      ${detalhesExtras ? `
      <div style="margin: 20px 0; border-top: 1px solid #eee; padding-top: 15px;">
        <h4 class="value-text" style="margin: 0 0 10px 0; color: #1a1a1a; font-size: 15px;">Informações Complementares</h4>
        <div style="font-size: 14px; color: #444;">
          ${detalhesExtras}
        </div>
      </div>
      ` : ''}
      
      ${linkGoogleAgenda ? `
      <!-- Botão Adicionar ao Google Agenda -->
      <div style="margin: 30px 0 25px 0; text-align: center;">
        <a href="${linkGoogleAgenda}" target="_blank" style="background-color: #89232D; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 14px; display: inline-block; box-shadow: 0 2px 5px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.05);">
          📅 Adicionar ao Google Agenda
        </a>
      </div>
      ` : ''}
      
      <p style="margin-top: 25px; font-size: 14px;">Por favor, confirme a visualização desta atividade acessando o calendário no painel administrativo.</p>
      <p style="margin-bottom: 0; font-size: 14px;">Desejamos um excelente serviço!</p>
    </div>
    
    <!-- Rodapé -->
    <div style="background-color: #f5f5f5; padding: 20px; text-align: center; font-size: 11px; color: #777777; border-top: 1px solid #eef0f2;">
      <p style="margin: 0 0 5px 0;"><strong>Heian Tour Operadora de Turismo Japão</strong></p>
      <p style="margin: 0;">Este é um e-mail de notificação automática. Por favor, não responda diretamente a esta mensagem.</p>
    </div>
  </div>
</body>
</html>
  `;

  const mailOptions = {
    from: `"Heian Tour" <${process.env.GMAIL_USER}>`,
    to: email,
    subject: assunto,
    html: html,
    attachments: [
      {
        filename: 'logo.png',
        path: 'c:/Users/User/Documents/heian-quote/public/assets/logo.png',
        cid: 'logo_heian'
      }
    ]
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`[Email] Notificação [${tipo}] enviada com sucesso para ${email}. MsgID: ${info.messageId}`);
    return true;
  } catch (error) {
    console.error(`[Email] Falha ao enviar notificação [${tipo}] para ${email}:`, error);
    return false;
  }
}

// Função unificada para processar todas as notificações pendentes
async function processarNotificacoesEmail() {
  console.log('[Email Job] Iniciando verificação de notificações de eventos...');
  try {
    const colabs = await obterColaboradoresEmails();
    if (Object.keys(colabs).length === 0) {
      console.log('[Email Job] Nenhum colaborador com e-mail cadastrado ou Notion indisponível.');
      return;
    }

    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    if (calErr) {
      console.error('[Email Job] Erro ao buscar eventos do Supabase:', calErr);
      return;
    }

    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    if (eventos.length === 0) {
      console.log('[Email Job] Nenhum evento encontrado.');
      return;
    }

    let houveAlteracao = false;
    const agora = Date.now();
    const hojeStr = new Date().toISOString().substring(0, 10);

    for (let evento of eventos) {
      if (!evento.assignee || !Array.isArray(evento.assignee) || evento.assignee.length === 0) {
        continue;
      }

      // 1. Evitar e-mails retroativos para datas que já passaram
      if (!evento.dataServico || evento.dataServico < hojeStr) {
        continue;
      }

      // 2. Evitar e-mails retroativos de cadastro para eventos futuros que já existiam no calendário.
      // Se a chave emails_cadastro_enviados não existe, inicializamos como array vazia
      // para permitir o envio para novos eventos.
      if (!evento.emails_cadastro_enviados) {
        evento.emails_cadastro_enviados = [];
        evento.emails_24h_enviados = [];
        evento.emails_1h_enviados = [];
        houveAlteracao = true;
      }

      // Garantir existência das arrays de controle
      if (!evento.emails_24h_enviados) evento.emails_24h_enviados = [];
      if (!evento.emails_1h_enviados) evento.emails_1h_enviados = [];

      // Calcular horário do serviço
      let horaEncontroStr = evento.horaEncontro || '09:00';
      if (evento.tipoServico === 'Roteiro') {
        horaEncontroStr = evento.horaEncontro || '09:00';
      } else if (evento.tipoServico === 'Experiência' || evento.expInfo) {
        horaEncontroStr = evento.expInfo?.horaPartida || evento.horaEncontro || '09:00';
      } else if (evento.tipoServico === 'Transporte' || evento.transportInfo) {
        horaEncontroStr = evento.transportInfo?.horario || evento.horaEncontro || '09:00';
      }

      const dataHoraServico = obterDataHoraServico(evento.dataServico, horaEncontroStr);
      const tempoAteServicoMs = dataHoraServico.getTime() - agora;

      for (let colab of evento.assignee) {
        const colabInfo = colabs[colab.id];
        if (!colabInfo || !colabInfo.email) {
          continue;
        }

        // 1. Enviar e-mail de nova designação (Cadastro)
        if (!evento.emails_cadastro_enviados.includes(colab.id)) {
          const enviado = await enviarEmailColaborador({
            email: colabInfo.email,
            nomeColaborador: colabInfo.name,
            evento: evento,
            tipo: 'cadastro'
          });
          if (enviado) {
            evento.emails_cadastro_enviados.push(colab.id);
            houveAlteracao = true;
          }
        }

        // 2. Enviar e-mail lembrete de 24h
        if (tempoAteServicoMs > 0 && tempoAteServicoMs <= 24 * 60 * 60 * 1000) {
          if (!evento.emails_24h_enviados.includes(colab.id)) {
            const enviado = await enviarEmailColaborador({
              email: colabInfo.email,
              nomeColaborador: colabInfo.name,
              evento: evento,
              tipo: '24h'
            });
            if (enviado) {
              evento.emails_24h_enviados.push(colab.id);
              houveAlteracao = true;
            }
          }
        }

        // 3. Enviar e-mail lembrete de 1h
        if (tempoAteServicoMs > 0 && tempoAteServicoMs <= 1 * 60 * 60 * 1000) {
          if (!evento.emails_1h_enviados.includes(colab.id)) {
            const enviado = await enviarEmailColaborador({
              email: colabInfo.email,
              nomeColaborador: colabInfo.name,
              evento: evento,
              tipo: '1h'
            });
            if (enviado) {
              evento.emails_1h_enviados.push(colab.id);
              houveAlteracao = true;
            }
          }
        }
      }
    }

    if (houveAlteracao) {
      console.log('[Email Job] Salvando novo histórico de envios no Supabase...');
      const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: eventos });
      if (upsertErr) {
        console.error('[Email Job] Erro ao salvar alterações no Supabase:', upsertErr);
      } else {
        console.log('[Email Job] Histórico atualizado com sucesso.');
      }
    } else {
      console.log('[Email Job] Nenhuma notificação enviada.');
    }

  } catch (error) {
    console.error('[Email Job] Erro no processamento de e-mails:', error);
  }
}

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'database.json');
const defaultData = { config: {}, transportes: [], experiencias: [], atracoes: [], rotas: {}, orcamentosDB: [], clientesDB: [] };

// --- PUBLIC ROUTES (No Auth Required) ---
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));
app.use('/css', express.static(path.join(__dirname, 'public', 'css')));

app.post('/api/public/cadastro', async (req, res) => {
  try {
    const {
      nome,
      email,
      viajantes,
      adultos,
      criancas,
      dataInicio,
      dataFim,
      vooChegada,
      vooPartida,
      hotel,
      observacoes,
      // novos campos de preferências
      profissoes,
      necessidadesEspeciais,
      cidadesPretendeVisitar,
      prioridades,
      ritmo,
      templos,
      caminhada,
      refeicoes,
      interessesTour,
      experienciasSazonais,
      primeiraVez,
      ocasiaoEspecial,
      experienciasImperdiveis
    } = req.body;
    
    if (!nome) return res.status(400).json({ error: 'Nome é obrigatório' });

    // Prepare proper date object
    let dateObj = undefined;
    if (dataInicio && dataFim && dataInicio !== dataFim) {
      dateObj = { date: { start: dataInicio, end: dataFim } };
    } else if (dataInicio) {
      dateObj = { date: { start: dataInicio } };
    }

    const properties = {
      "Nome do Cliente": { title: [{ text: { content: nome } }] },
      "Status do Cliente": { select: { name: "Novo" } },
      "Qtd Adultos": { number: parseInt(adultos) || 0 },
      "Qtd Crianças": { number: parseInt(criancas) || 0 }
    };
    
    if (vooChegada) properties["Voo de Chegada"] = { rich_text: [{ text: { content: vooChegada } }] };
    if (vooPartida) properties["Voo de Partida"] = { rich_text: [{ text: { content: vooPartida } }] };
    if (hotel) properties["Hotel"] = { rich_text: [{ text: { content: hotel } }] };
    if (dateObj) properties["Período da Viagem"] = dateObj;
    
    if (email) {
      const firstEmail = email.split('\n')[0].trim();
      if (firstEmail) properties['Email'] = { email: firstEmail };
    }
    if (viajantes) properties['Nome dos Viajantes'] = { rich_text: [{ text: { content: viajantes } }] };
    if (observacoes) properties['Observações'] = { rich_text: [{ text: { content: observacoes } }] };

    // Adiciona as 3 colunas estruturadas novas no Notion se fornecidas
    if (profissoes) properties["Profissão dos Viajantes"] = { rich_text: [{ text: { content: profissoes } }] };
    if (ocasiaoEspecial) properties["Ocasião Especial"] = { rich_text: [{ text: { content: ocasiaoEspecial } }] };
    if (necessidadesEspeciais) properties["Necessidades Especiais"] = { rich_text: [{ text: { content: necessidadesEspeciais } }] };

    // Construção dos blocos do Notion (children) para o relatório estruturado no corpo do card
    const childrenBlocks = [];
    
    childrenBlocks.push({
      object: "block",
      type: "heading_2",
      heading_2: {
        rich_text: [{ type: "text", text: { content: "⛩️ Perfil de Viagem & Preferências" } }]
      }
    });

    if (cidadesPretendeVisitar) {
      childrenBlocks.push({
        object: "block",
        type: "paragraph",
        paragraph: {
          rich_text: [
            { type: "text", text: { content: "Cidades que pretende visitar: " }, annotations: { bold: true } },
            { type: "text", text: { content: cidadesPretendeVisitar } }
          ]
        }
      });
    }

    childrenBlocks.push({
      object: "block",
      type: "heading_3",
      heading_3: {
        rich_text: [{ type: "text", text: { content: "🏃 Estilo e Ritmo" } }]
      }
    });

    if (ritmo) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Ritmo de Viagem: " }, annotations: { bold: true } },
            { type: "text", text: { content: ritmo } }
          ]
        }
      });
    }

    if (templos) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Visita a Templos: " }, annotations: { bold: true } },
            { type: "text", text: { content: templos } }
          ]
        }
      });
    }

    if (caminhada) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Ritmo de Caminhada: " }, annotations: { bold: true } },
            { type: "text", text: { content: caminhada } }
          ]
        }
      });
    }

    if (refeicoes) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Estilo de Refeições: " }, annotations: { bold: true } },
            { type: "text", text: { content: refeicoes } }
          ]
        }
      });
    }

    childrenBlocks.push({
      object: "block",
      type: "heading_3",
      heading_3: {
        rich_text: [{ type: "text", text: { content: "🎯 Interesses & Prioridades" } }]
      }
    });

    if (prioridades) {
      const prioText = Array.isArray(prioridades) ? prioridades.join(', ') : prioridades;
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Prioridades de Viagem: " }, annotations: { bold: true } },
            { type: "text", text: { content: prioText } }
          ]
        }
      });
    }

    if (interessesTour) {
      const intText = Array.isArray(interessesTour) ? interessesTour.join(', ') : interessesTour;
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Foco dos Tours Guiados: " }, annotations: { bold: true } },
            { type: "text", text: { content: intText } }
          ]
        }
      });
    }

    if (primeiraVez) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Primeira vez no Japão? " }, annotations: { bold: true } },
            { type: "text", text: { content: primeiraVez } }
          ]
        }
      });
    }

    if (experienciasSazonais) {
      childrenBlocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: {
          rich_text: [
            { type: "text", text: { content: "Interesse em experiências sazonais? " }, annotations: { bold: true } },
            { type: "text", text: { content: experienciasSazonais } }
          ]
        }
      });
    }

    if (experienciasImperdiveis) {
      childrenBlocks.push({
        object: "block",
        type: "heading_3",
        heading_3: {
          rich_text: [{ type: "text", text: { content: "🌸 Experiências Imperdíveis & Desejos" } }]
        }
      });

      childrenBlocks.push({
        object: "block",
        type: "paragraph",
        paragraph: {
          rich_text: [{ type: "text", text: { content: experienciasImperdiveis } }]
        }
      });
    }

    const payloadNotion = {
      parent: { database_id: NOTION_CLIENTS_DB_ID },
      properties: properties
    };

    if (childrenBlocks.length > 0) {
      payloadNotion.children = childrenBlocks;
    }

    const response = await fetch(`https://api.notion.com/v1/pages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payloadNotion)
    });

    const result = await response.json();
    if (!response.ok) {
      console.error('Notion API Error:', result);
      return res.status(500).json({ error: 'Erro ao criar cliente no Notion', details: result });
    }

    // Gravar no Supabase a estrutura local correspondente (incluindo fotoPerfil)
    const cliId = result.id;
    const currentEditingViajantes = [];
    if (viajantes) {
      viajantes.split('\n').filter(l => l.trim()).forEach(line => {
        const text = line.trim();
        const ageMatch = text.match(/\((\d+)\)$/);
        let idade = '';
        let namePart = text;
        if (ageMatch) {
          idade = ageMatch[1];
          namePart = text.substring(0, ageMatch.index).trim();
        }
        const parts = namePart.split(/\s+/);
        const sobrenome = parts.length > 1 ? parts.pop() : '';
        currentEditingViajantes.push({ id: Date.now() + Math.random(), nome: parts.join(' '), sobrenome, idade });
      });
    }

    const currentEditingEstadias = [];
    if (hotel) {
      hotel.split('\n').filter(l => l.trim()).forEach(line => {
        let cidade = ''; let hotelName = line.trim(); let dataInicioEst = ''; let dataFimEst = '';
        const dateMatch = line.match(/\((\d{2}\/\d{2}\/\d{4})\s*(?:a|-|até)\s*(\d{2}\/\d{2}\/\d{4})\)/);
        if (dateMatch) {
          const parseDate = d => { const p = d.split('/'); return p[2]+'-'+p[1]+'-'+p[0]; };
          dataInicioEst = parseDate(dateMatch[1]); dataFimEst = parseDate(dateMatch[2]);
          hotelName = line.substring(0, dateMatch.index).trim();
        }
        const dashIndex = hotelName.indexOf(' - ');
        if (dashIndex > -1) {
          cidade = hotelName.substring(0, dashIndex).trim();
          hotelName = hotelName.substring(dashIndex + 3).trim();
        }
        currentEditingEstadias.push({ id: Date.now() + Math.random(), cidade, dataInicio: dataInicioEst, dataFim: dataFimEst, hotel: hotelName });
      });
    }

    const currentEditingEmails = [];
    if (email) {
      email.split('\n').filter(l => l.trim()).forEach(line => {
        currentEditingEmails.push({ id: Date.now() + Math.random(), email: line.trim() });
      });
    }

    try {
      await supabase.from('clientes_locais').upsert({
        id: String(cliId),
        data: {
          id: cliId,
          estadias: currentEditingEstadias,
          viajantes: currentEditingViajantes,
          emails: currentEditingEmails,
          fotoPerfil: req.body.fotoPerfil || "",
          preferencias: {
            profissoes,
            necessidadesEspeciais,
            cidadesPretendeVisitar,
            prioridades,
            ritmo,
            templos,
            caminhada,
            refeicoes,
            interessesTour,
            experienciasSazonais,
            primeiraVez,
            ocasiaoEspecial,
            experienciasImperdiveis
          }
        }
      });
    } catch (dbErr) {
      console.error('Erro ao gravar dados locais do cliente no Supabase via cadastro:', dbErr);
    }

    res.json({ success: true, client: result });
  } catch (error) {
    console.error('Erro na rota /api/public/cadastro:', error);
    res.status(500).json({ error: error.message });
  }
});
// ----------------------------------------

const basicAuth = require('express-basic-auth');

// -------- ROTAS PÚBLICAS (sem senha) --------
// Deve ser registrado ANTES do middleware de autenticação global

// Página de cadastro do cliente — sempre pública
app.get('/cadastro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cadastro.html'));
});

// (A API POST /api/public/cadastro já está registrada acima, antes deste bloco.)

// -------- AUTENTICAÇÃO GLOBAL --------
// Protege tudo com senha, exceto as rotas públicas (cadastro e área do cliente)
if (process.env.APP_PASS) {
  const users = {};
  users[process.env.APP_USER || 'admin'] = process.env.APP_PASS;

  app.use((req, res, next) => {
    // Libera: página de cadastro, área do cliente, APIs de cadastro e dados públicos do cliente
    // Usa prefixos com "/" no fim (ou igualdade exata) para não liberar caminhos parecidos por engano
    const rotasPublicas = [
      '/cadastro',
      '/api/public/cadastro',
      '/cliente',
      '/cliente.html',
      '/api/public/client-data'
    ];
    if (rotasPublicas.some(r => req.path === r || req.path.startsWith(r + '/'))) {
      return next();
    }
    return basicAuth({ users, challenge: true, realm: 'HeianTour' })(req, res, next);
  });
}

// Página principal (portal): protegida globalmente caso APP_PASS esteja configurado
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'portal.html'));
});

// Área admin: serve app.html (painel completo)
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

app.post('/api/admin/enviar-roteiro-email', express.json({ limit: '50mb' }), async (req, res) => {
  try {
    const { sender, to, subject, body, attachment } = req.body;
    
    console.log('Requisicao de Envio de Email recebida:', {
      to,
      subject,
      sender,
      hasAttachment: !!attachment,
      attachmentName: attachment ? attachment.filename : null,
      attachmentLength: attachment && attachment.content ? attachment.content.length : 0
    });

    if (!to || !subject || !body) {
      return res.status(400).json({ success: false, error: 'Campos obrigatórios ausentes' });
    }

    // A conta que faz o login (SMTP Auth) é heiantour@gmail.com
    const smtpAuthUser = process.env.GMAIL_USER || 'heiantour@gmail.com';
    const smtpAuthPass = process.env.GMAIL_APP_PASS;

    if (!smtpAuthPass) {
      return res.status(500).json({ success: false, error: 'Senha de aplicativo do Gmail não configurada no servidor (.env)' });
    }

    // Definir o alias de e-mail e o nome com base no remetente selecionado
    const isDiogo = sender === 'diogo';
    const fromEmail = isDiogo ? 'diogo@heiantour.com' : 'deborah@heiantour.com';
    const senderName = isDiogo ? 'Diogo' : 'Deborah';

    // Converter quebras de linha em parágrafos do e-mail pessoal
    let htmlContent = body
      .split('\n\n')
      .map(p => `<p style="margin: 0 0 16px 0; line-height: 1.6; color: #333333; font-size: 15px;">${p.replace(/\n/g, '<br>')}</p>`)
      .join('');

    // Detectar link do roteiro e substituir por link limpo
    const linkRegex = /(https?:\/\/heiantour[^\s]+|https?:\/\/localhost[^\s]+)/gi;
    const match = body.match(linkRegex);
    if (match && match[0]) {
      const linkUrl = match[0];
      // Criar um botão discreto de link (estilo transacional pessoal, evita caixa de promoções)
      const btnHtml = `
        <div style="margin: 24px 0;">
          <a href="${linkUrl}" target="_blank" style="display: inline-block; background-color: #8e1c1c; color: #ffffff; text-decoration: none; padding: 12px 28px; border-radius: 6px; font-weight: bold; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px;">
            Acessar Roteiro Interativo
          </a>
        </div>
      `;
      // Remover a URL em texto do HTML e adicionar o botão
      htmlContent = htmlContent.replace(linkUrl, '').replace('<br>' + linkUrl, '').replace(linkUrl + '<br>', '');
      htmlContent += btnHtml;
    }

    // Layout de e-mail pessoal e limpo (evita a aba "Promoções" e vai para a Principal)
    const mailHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 15px; color: #333333; line-height: 1.6; max-width: 600px; padding: 10px 0;">
        ${htmlContent}
        <br>
        <hr style="border: 0; border-top: 1px solid #eeeeee; margin: 24px 0;">
        <p style="font-size: 12px; color: #888888; line-height: 1.4; margin: 0;">
          Atenciosamente,<br>
          <strong>${senderName}</strong><br>
          Heian Tour &mdash; Curadoria de Viagens ao Japão<br>
          <a href="mailto:${fromEmail}" style="color: #8e1c1c; text-decoration: none;">${fromEmail}</a>
        </p>
      </div>
    `;

    // Processar o anexo se existir
    const attachments = [];
    if (attachment && attachment.content) {
      // Extração robusta do conteúdo Base64 (remove cabeçalho Data URI se houver)
      let base64Data = attachment.content;
      if (base64Data.includes(';base64,')) {
        base64Data = base64Data.substring(base64Data.indexOf(';base64,') + 8);
      } else if (base64Data.includes(',')) {
        base64Data = base64Data.substring(base64Data.indexOf(',') + 1);
      }

      const buffer = Buffer.from(base64Data, 'base64');
      attachments.push({
        filename: attachment.filename || 'roteiro.pdf',
        content: buffer,
        contentType: 'application/pdf'
      });

      console.log('Anexo PDF processado e adicionado:', {
        filename: attachment.filename,
        originalLength: attachment.content.length,
        base64Length: base64Data.length,
        bufferLength: buffer.length
      });
    } else {
      console.log('Nenhum anexo encontrado ou recebido no body.');
    }

    // Enviar e-mail usando o transporter global (autenticado com heiantour@gmail.com)
    // O Google aceita desde que fromEmail esteja configurado como alias em heiantour@gmail.com
    await transporter.sendMail({
      from: `"${senderName} | Heian Tour" <${fromEmail}>`,
      replyTo: fromEmail,
      to,
      subject,
      html: mailHtml,
      attachments
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Erro ao enviar e-mail do roteiro:', error);
    res.status(500).json({ success: false, error: 'Falha ao enviar e-mail', details: error.message });
  }
});

app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: (res, filePath) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }
}));

// Helpers
async function readDB() {
  try {
    const defaultData = { config: {}, transportes: [], experiencias: [], atracoes: [], rotas: {}, orcamentosDB: [], clientesDB: [] };
    
    const [cfgRes, transpRes, expRes, atrRes, orcsRes, clisRes, rotsRes, baseRes] = await Promise.all([
      supabase.from('config').select('data').eq('id', 'app_config').single(),
      supabase.from('config').select('data').eq('id', 'transportes').single(),
      supabase.from('config').select('data').eq('id', 'experiencias').single(),
      supabase.from('config').select('data').eq('id', 'atracoes').single(),
      supabase.from('orcamentos').select('data'),
      supabase.from('clientes_locais').select('data'),
      supabase.from('roteiros').select('*'),
      supabase.from('rotas_base').select('data').eq('id', 'base').single()
    ]);

    if (cfgRes.data && cfgRes.data.data) defaultData.config = cfgRes.data.data;
    if (transpRes.data && transpRes.data.data) defaultData.transportes = transpRes.data.data;
    if (expRes.data && expRes.data.data) defaultData.experiencias = expRes.data.data;
    if (atrRes.data && atrRes.data.data) defaultData.atracoes = atrRes.data.data;
    
    if (orcsRes.data) defaultData.orcamentosDB = orcsRes.data.map(r => r.data);
    if (clisRes.data) defaultData.clientesDB = clisRes.data.map(r => r.data);
    
    if (rotsRes.data) {
      rotsRes.data.forEach(r => {
        defaultData.rotas[r.nome] = r.data;
      });
    }
    
    if (baseRes.data && baseRes.data.data) {
      defaultData.rotas['[PLANILHA] Base de Rotas'] = { dias: baseRes.data.data };
    }

    return defaultData;
  } catch(e) {
    console.error('Erro no readDB do Supabase:', e);
    return { config: {}, transportes: [], experiencias: [], atracoes: [], rotas: {}, orcamentosDB: [], clientesDB: [] };
  }
}

async function writeDB(db) {
  try {
    // Para simplificar essa transição imediata 1:1, gravamos as tabelas chaves
    const resCfg = await supabase.from('config').upsert({ id: 'app_config', data: db.config || {} });
    if (resCfg.error) throw new Error('Error upsert app_config: ' + resCfg.error.message);
    const resTransp = await supabase.from('config').upsert({ id: 'transportes', data: db.transportes || [] });
    if (resTransp.error) throw new Error('Error upsert transportes: ' + resTransp.error.message);
    const resExp = await supabase.from('config').upsert({ id: 'experiencias', data: db.experiencias || [] });
    if (resExp.error) throw new Error('Error upsert experiencias: ' + resExp.error.message);
    const resAtr = await supabase.from('config').upsert({ id: 'atracoes', data: db.atracoes || [] });
    if (resAtr.error) throw new Error('Error upsert atracoes: ' + resAtr.error.message);

    for (let o of db.orcamentosDB || []) {
      const resOrc = await supabase.from('orcamentos').upsert({ id: String(o.id), data: o });
      if (resOrc.error) throw new Error('Error upsert orcamento ' + o.id + ': ' + resOrc.error.message);
    }
    for (let c of db.clientesDB || []) {
      const resCli = await supabase.from('clientes_locais').upsert({ id: String(c.id), data: c });
      if (resCli.error) throw new Error('Error upsert cliente_local ' + c.id + ': ' + resCli.error.message);
    }

    // Deleta rotas velhas e insere novas
    for (let [nome, dados] of Object.entries(db.rotas || {})) {
      if (nome === '[PLANILHA] Base de Rotas') {
        const resBase = await supabase.from('rotas_base').upsert({ id: 'base', data: dados.dias });
        if (resBase.error) throw new Error('Error upsert rotas_base: ' + resBase.error.message);
      } else {
        const resRoteiro = await supabase.from('roteiros').upsert({ nome, data: dados });
        if (resRoteiro.error) throw new Error('Error upsert roteiro ' + nome + ': ' + resRoteiro.error.message);
      }
    }
  } catch(e) {
    console.error('Erro no writeDB:', e);
    throw e;
  }
}

const globalErrorLogs = [];
const originalConsoleError = console.error;
console.error = function(...args) {
  globalErrorLogs.unshift({ time: new Date().toISOString(), args: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)) });
  if (globalErrorLogs.length > 50) globalErrorLogs.pop();
  originalConsoleError.apply(console, args);
};

// Auxiliar para sincronização em duas vias com o Google Sheets via Apps Script Web App
async function syncToGoogleSheets(type, action, data, oldData = null) {
  const db = await readDB();
  const { sheets_script_url, sheets_aba_transportes, sheets_aba_experiencias, sheets_aba_atracoes, sheets_aba_rotas, sheets_aba_hoteis } = db.config;
  if (!sheets_script_url) return; // Se não houver URL configurada, ignora silenciosamente

  let sheetName = '';
  if (type === 'transportes') sheetName = sheets_aba_transportes || 'Base';
  else if (type === 'experiencias') sheetName = sheets_aba_experiencias || 'BaseEX';
  else if (type === 'atracoes') sheetName = sheets_aba_atracoes || 'Atracoes';
  else if (type === 'rotas') sheetName = sheets_aba_rotas || 'Rotas';
  else if (type === 'hoteis') sheetName = sheets_aba_hoteis || 'Hotéis';

  try {
    const payload = { action, type, sheetName, data, oldData };
    // Dispara em background de forma assíncrona sem travar a resposta HTTP local
    fetch(sheets_script_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(async r => {
      const resVal = await r.json();
      console.log(`[Google Sheets Sync] ${action.toUpperCase()} ${type}:`, resVal);
    }).catch(err => {
      console.error(`[Google Sheets Sync Error] Falha ao enviar para o Sheets:`, err.message);
    });
  } catch (err) {
    console.error(`[Google Sheets Sync Error] Erro ao preparar requisição:`, err.message);
  }
}

// ── API: Config / Câmbio ────────────────────────────────────────────────────
app.get('/api/config', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'app_config').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : {});
  } catch(e) {
    console.error('Error getting config:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/config', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'app_config').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const existing = data && data.data ? data.data : {};
    const updated = { ...existing, ...req.body };
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'app_config', data: updated });
    if (upsertErr) throw upsertErr;
    res.json({ ok: true });
  } catch(e) {
    console.error('Error saving config:', e);
    res.status(500).json({error: e.message});
  }
});

// Endpoints /api/debug e /api/debug-logs removidos por segurança:
// expunham a configuração completa (inclusive URLs internas) e logs de erro.

// ── API: Transportes ────────────────────────────────────────────────────────
app.get('/api/orcamentos', async (req, res) => {
  try {
    const { data, error } = await supabase.from('orcamentos').select('data');
    if (error) throw error;
    // Filtra para retornar apenas os orçamentos ativos (não deletados)
    const ativos = data ? data.map(r => r.data).filter(item => item && !item.deletado) : [];
    res.json(ativos);
  } catch(e) {
    console.error('Error getting orcamentos:', e);
    res.status(500).json({error: e.message});
  }
});
app.post('/api/orcamentos', async (req, res) => {
  try {
    const corpo = { ...req.body };
    const baseVersao = corpo._baseVersao;
    delete corpo._baseVersao;

    // Guarda de versão: não deixa uma sessão gravar por cima de outra sem saber
    const { data: linha } = await supabase.from('orcamentos').select('data').eq('id', String(corpo.id)).maybeSingle();
    const armazenado = linha ? linha.data : null;
    if (conflitoDeVersao(baseVersao, armazenado)) {
      return res.status(409).json({
        success: false,
        error: 'conflict_version',
        message: 'Esta cotação foi alterada em outra sessão (outra aba ou outro usuário). Recarregue-a antes de continuar editando.',
        atualizadoEm: armazenado.atualizadoEm
      });
    }

    const dados = aplicarHistorico(corpo, armazenado);
    const { error } = await supabase.from('orcamentos').upsert({ id: String(dados.id), data: dados });
    if (error) throw error;
    res.json({ success: true, atualizadoEm: dados.atualizadoEm });
  } catch(e) {
    res.status(500).json({error: e.message});
  }
});
app.delete('/api/orcamentos/:id', async (req, res) => {
  try {
    const id = req.params.id;
    // Soft Delete: carrega o orçamento atual, marca como deletado no JSON e atualiza
    const { data, error: fetchErr } = await supabase.from('orcamentos').select('data').eq('id', String(id)).single();
    if (fetchErr) throw fetchErr;
    
    const orc = data.data || {};
    orc.deletado = true;
    orc.deletadoEm = new Date().toISOString();
    
    const { error } = await supabase.from('orcamentos').upsert({ id: String(id), data: orc });
    if (error) throw error;
    res.json({success:true});
  } catch(e) {
    console.error('Error deleting orcamento:', e);
    res.status(500).json({error: e.message});
  }
});

// Clientes Local (Dados estruturados atrelados ao Notion)
app.get('/api/clientes/local/:id', async (req, res) => {
  try {
    const { data, error } = await supabase.from('clientes_locais').select('data').eq('id', String(req.params.id)).single();
    if (error && error.code !== 'PGRST116') {
      throw error;
    }
    res.json(data && data.data ? data.data : { id: req.params.id, estadias: [] });
  } catch(e) {
    console.error('Error getting local client:', e);
    res.status(500).json({error: e.message});
  }
});
app.post('/api/clientes/local', async (req, res) => {
  try {
    const { error } = await supabase.from('clientes_locais').upsert({ id: String(req.body.id), data: req.body });
    if (error) throw error;
    res.json({success:true});
  } catch(e) {
    console.error('Error saving local client:', e);
    res.status(500).json({error: e.message});
  }
});
app.delete('/api/clientes/local/:id', async (req, res) => {
  try {
    const { error } = await supabase.from('clientes_locais').delete().eq('id', String(req.params.id));
    if (error) throw error;
    res.json({success:true});
  } catch(e) {
    console.error('Error deleting local client:', e);
    res.status(500).json({error: e.message});
  }
});

app.get('/api/transportes', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'transportes').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : []);
  } catch(e) {
    console.error('Error getting transportes:', e);
    res.status(500).json({error: e.message});
  }
});

// Rotas genéricas de Config
app.get('/api/config/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase.from('config').select('data').eq('id', id).single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : {});
  } catch(e) {
    console.error(`Error getting config ${req.params.id}:`, e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/config/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { error } = await supabase.from('config').upsert({ id, data: req.body });
    if (error) throw error;
    res.json({success:true});
  } catch(e) {
    console.error(`Error saving config ${req.params.id}:`, e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/transportes', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'transportes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const novo = { ...req.body, id: Date.now() };
    list.push(novo);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'transportes', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('transportes', 'insert', novo);
    
    res.json(novo);
  } catch(e) {
    console.error('Error saving transporte:', e);
    res.status(500).json({error: e.message});
  }
});

app.put('/api/transportes/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'transportes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const idx = list.findIndex(t => t.id == req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Não encontrado' });
    const oldItem = list[idx];
    list[idx] = { ...list[idx], ...req.body };
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'transportes', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('transportes', 'update', list[idx], oldItem);
    
    res.json(list[idx]);
  } catch(e) {
    console.error('Error updating transporte:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/transportes/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'transportes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    let list = data && data.data ? data.data : [];
    list = list.filter(t => t.id != req.params.id);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'transportes', data: list });
    if (upsertErr) throw upsertErr;
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting transporte:', e);
    res.status(500).json({error: e.message});
  }
});

// ── API: Experiências ───────────────────────────────────────────────────────
app.get('/api/experiencias', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'experiencias').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : []);
  } catch(e) {
    console.error('Error getting experiencias:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/experiencias', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'experiencias').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const novo = { ...req.body, id: Date.now() };
    list.push(novo);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'experiencias', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('experiencias', 'insert', novo);
    
    res.json(novo);
  } catch(e) {
    console.error('Error saving experiencia:', e);
    res.status(500).json({error: e.message});
  }
});

app.put('/api/experiencias/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'experiencias').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const idx = list.findIndex(e => e.id == req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Não encontrado' });
    const oldItem = list[idx];
    list[idx] = { ...list[idx], ...req.body };
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'experiencias', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('experiencias', 'update', list[idx], oldItem);
    
    res.json(list[idx]);
  } catch(e) {
    console.error('Error updating experiencia:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/experiencias/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'experiencias').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    let list = data && data.data ? data.data : [];
    list = list.filter(e => e.id != req.params.id);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'experiencias', data: list });
    if (upsertErr) throw upsertErr;
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting experiencia:', e);
    res.status(500).json({error: e.message});
  }
});

// ── API: Roteiros & Atrações ────────────────────────────────────────────────
app.post('/api/roteiros/gerar-ia', async (req, res) => {
  try {
    const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
    if (!GEMINI_API_KEY) {
      return res.status(400).json({ error: 'Configuração da API do Gemini incompleta no arquivo .env (chave GEMINI_API_KEY ausente).' });
    }

    const { clienteId, promptAdicional, datas, clienteData } = req.body;
    let briefingCliente = '';
    let clienteNome = 'Cliente';

    // 1. Opcional: Buscar dados do cliente no Notion se houver clienteId
    if (clienteId && clienteId !== 'cliente_desconhecido' && process.env.NOTION_API_KEY) {
      try {
        const notionRes = await fetch(`https://api.notion.com/v1/pages/${clienteId}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${process.env.NOTION_API_KEY || NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28'
          }
        });
        if (notionRes.ok) {
          const page = await notionRes.json();
          const p = page.properties;
          clienteNome = p['Nome do Cliente']?.title?.map(t => t.plain_text).join('') || 
                        p['Name']?.title?.map(t => t.plain_text).join('') || 
                        p['Nome']?.title?.map(t => t.plain_text).join('') || 'Cliente';
          
          // Tentar ler alguma propriedade de briefing/observações
          const briefingProp = p['Briefing'] || p['Preferências'] || p['Observações'] || p['Descrição'];
          if (briefingProp) {
            briefingCliente = briefingProp.rich_text?.map(t => t.plain_text).join('') || '';
          }
        }
      } catch (err) {
        console.error('Erro ao ler briefing do cliente no Notion:', err.message);
      }
    }

    // 2. Buscar atrações da base de dados local (Supabase)
    const { data: cfgAtr } = await supabase.from('config').select('data').eq('id', 'atracoes').single();
    const listaAtracoes = cfgAtr && cfgAtr.data ? cfgAtr.data : [];
    
    // Condensar as atrações para enviar no prompt para não estourar limite e economizar tempo
    const atracoesFormatadas = {};
    listaAtracoes.forEach(a => {
      const cidade = (a.Cidade || 'Geral').trim();
      const nome = a['Nome da Atração'];
      if (nome) {
        if (!atracoesFormatadas[cidade]) atracoesFormatadas[cidade] = [];
        atracoesFormatadas[cidade].push(nome);
      }
    });

    const contextAtracoes = Object.entries(atracoesFormatadas)
      .map(([cidade, nomes]) => `- ${cidade}: ${nomes.slice(0, 50).join(', ')}`)
      .join('\n');

    // 3. Montar o prompt do Gemini
    const systemPrompt = `Você é um agente de viagens especialista em turismo de luxo no Japão para a operadora premium "Heian Tour".
Seu objetivo é planejar e estruturar um itinerário dia-a-dia de excelência, otimizado geograficamente e adequado aos interesses do viajante.

Você receberá um Briefing do Cliente, Instruções Adicionais e uma lista de Atrações Disponíveis por cidade que pertencem à nossa base de dados.
Dê preferência absoluta em utilizar as Atrações Disponíveis da lista que combinam com o perfil do cliente, organizando-as por dia e em ordem lógica de visitação.

Instruções importantes:
1. Organize o roteiro em ordem de dias (Dia 1, Dia 2, etc.).
2. Para cada dia, adicione um elemento do tipo "sequencia" (contendo a lista de atrações daquele dia) e opcionalmente um elemento do tipo "texto" contendo dicas do dia, sugestões de restaurantes ou observações importantes de logística.
3. Responda estritamente no formato JSON fornecido abaixo. Não retorne nenhum texto extra antes ou depois do JSON.

Modelo do JSON esperado de saída:
{
  "dias": [
    {
      "data": "YYYY-MM-DD",
      "cidade": "Nome da cidade principal do dia",
      "elementos": [
        {
          "tipo": "sequencia",
          "cidade": "Nome da cidade do passeio",
          "nomeDaRota": "Título descritivo da rota do dia (ex: Quioto Histórico ou Asakusa e Ueno Tradicional)",
          "atracoesDoDia": []
        },
        {
          "tipo": "texto",
          "conteudo": "Recomendações especiais de restaurantes, logística ou dicas para este dia..."
        }
      ]
    }
  ]
}

Atrações Disponíveis no nosso banco de dados por cidade:\n${contextAtracoes}`;

    let infoClientePrompt = '';
    if (clienteData) {
      const adultos = clienteData.adultos || 2;
      const criancas = clienteData.criancas || 0;
      infoClientePrompt += `- Viajantes: ${adultos} adulto(s)${criancas > 0 ? ` e ${criancas} criança(s)` : ''}\n`;
      if (clienteData.vooChegada) infoClientePrompt += `- Voo de Chegada: ${clienteData.vooChegada}\n`;
      if (clienteData.vooPartida) infoClientePrompt += `- Voo de Partida: ${clienteData.vooPartida}\n`;
      
      if (Array.isArray(clienteData.estadias) && clienteData.estadias.length > 0) {
        infoClientePrompt += `- Cidades e Hotéis de Hospedagem (Estadias) agendadas:\n`;
        clienteData.estadias.forEach((est, idx) => {
          if (est.cidade) {
            let dataStr = '';
            if (est.dataInicio && est.dataFim) {
              const d1 = est.dataInicio.split('-').reverse().join('/');
              const d2 = est.dataFim.split('-').reverse().join('/');
              dataStr = ` de ${d1} a ${d2}`;
            }
            infoClientePrompt += `  * Estadia ${idx + 1}: ${est.cidade}${est.hotel ? ` no hotel ${est.hotel}` : ''}${dataStr}\n`;
          }
        });
      }
    }

    const userPrompt = `Briefing do Cliente (${clienteNome}):
${briefingCliente || 'Nenhum briefing específico fornecido.'}

Dados Cadastrados do Cliente no Roteiro:
${infoClientePrompt || 'Nenhum dado cadastrado.'}

Instruções Adicionais e Informações da Viagem (Datas, dias, estilo):
${promptAdicional || 'Nenhuma instrução adicional.'}
${datas ? `Data de início da viagem: ${datas}` : ''}

Por favor, gere o JSON do roteiro estruturado com base nas instruções e atrações fornecidas. Certifique-se de que os nomes de atrações colocados no array "atracoesDoDia" correspondam EXATAMENTE aos nomes presentes na lista de atrações por cidade fornecida.`;

    // 4. Chamar a API REST do Gemini com suporte dinâmico a chaves AQ. (Authorization Keys) e AIza (Legacy Keys)
    const isNewAuthKey = GEMINI_API_KEY.startsWith('AQ.');
    const geminiUrl = isNewAuthKey 
      ? `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent`
      : `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

    const headers = {
      'Content-Type': 'application/json'
    };

    if (isNewAuthKey) {
      headers['Authorization'] = `Bearer ${GEMINI_API_KEY}`;
    }

    const geminiPayload = {
      contents: [
        {
          parts: [
            { text: systemPrompt + '\n\n' + userPrompt }
          ]
        }
      ],
      generationConfig: {
        responseMimeType: "application/json"
      }
    };

    const response = await fetch(geminiUrl, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(geminiPayload)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Erro na API do Gemini: ${errText}`);
    }

    const geminiData = await response.json();
    const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!responseText) {
      throw new Error('A API do Gemini retornou uma resposta vazia ou em formato inesperado.');
    }

    // Fazer parse da resposta JSON da IA
    const roteiroGerado = JSON.parse(responseText.trim());
    res.json({ success: true, data: roteiroGerado });

  } catch (error) {
    console.error('Erro na geração do roteiro com IA:', error);
    res.status(500).json({ error: 'Erro ao gerar roteiro com IA', details: error.message });
  }
});

app.get('/api/atracoes', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'atracoes').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : []);
  } catch(e) {
    console.error('Error getting atracoes:', e);
    res.status(500).json({error: e.message});
  }
});

app.get('/api/hoteis', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : []);
  } catch(e) {
    console.error('Error getting hoteis:', e);
    res.status(500).json({error: e.message});
  }
});

app.get('/api/templates-vouchers', async (req, res) => {
  try {
    const { data, error } = await supabase.from('config').select('data').eq('id', 'templates_vouchers').single();
    if (error && error.code !== 'PGRST116') throw error;
    res.json(data && data.data ? data.data : []);
  } catch(e) {
    console.error('Error getting templates-vouchers:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/hoteis', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    
    const novo = { ...req.body, id: String(Date.now()) };
    list.push(novo);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'hoteis', data: list });
    if (upsertErr) throw upsertErr;
    
    await syncToGoogleSheets('hoteis', 'insert', novo);
    
    res.json(novo);
  } catch(e) {
    console.error('Error saving hotel:', e);
    res.status(500).json({error: e.message});
  }
});

app.put('/api/hoteis/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
    if (fetchErr) throw fetchErr;
    const list = data && data.data ? data.data : [];
    
    const idx = list.findIndex(h => h.id == id);
    if (idx === -1) return res.status(404).json({ error: 'Hotel não encontrado' });
    
    const oldItem = { ...list[idx] };
    const updated = { ...list[idx], ...req.body, id };
    list[idx] = updated;
    
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'hoteis', data: list });
    if (upsertErr) throw upsertErr;
    
    await syncToGoogleSheets('hoteis', 'update', updated, oldItem);
    
    res.json(updated);
  } catch(e) {
    console.error('Error updating hotel:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/hoteis/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
    if (fetchErr) throw fetchErr;
    const list = data && data.data ? data.data : [];
    
    const idx = list.findIndex(h => h.id == id);
    if (idx === -1) return res.status(404).json({ error: 'Hotel não encontrado' });
    
    const oldItem = list[idx];
    const filteredList = list.filter(h => h.id != id);
    
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'hoteis', data: filteredList });
    if (upsertErr) throw upsertErr;
    
    await syncToGoogleSheets('hoteis', 'delete', oldItem);
    
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting hotel:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/atracoes', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'atracoes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    
    // Strip any HTML codes from the description
    if (req.body && req.body['Descrição Detalhada']) {
      req.body['Descrição Detalhada'] = req.body['Descrição Detalhada'].replace(/<[^>]*>?/gm, '').trim();
    }
    
    const novo = { ...req.body, id: Date.now() };
    list.push(novo);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'atracoes', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('atracoes', 'insert', novo);
    
    res.json(novo);
  } catch(e) {
    console.error('Error saving atracao:', e);
    res.status(500).json({error: e.message});
  }
});

app.put('/api/atracoes/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'atracoes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const idx = list.findIndex(a => a.id == req.params.id || a['Nome da Atração'] === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Não encontrado' });
    
    // Strip any HTML codes from the description
    if (req.body && req.body['Descrição Detalhada']) {
      req.body['Descrição Detalhada'] = req.body['Descrição Detalhada'].replace(/<[^>]*>?/gm, '').trim();
    }
    
    const oldItem = list[idx];
    list[idx] = { ...list[idx], ...req.body };
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'atracoes', data: list });
    if (upsertErr) throw upsertErr;
    
    // Sincroniza em background
    await syncToGoogleSheets('atracoes', 'update', list[idx], oldItem);
    
    res.json(list[idx]);
  } catch(e) {
    console.error('Error updating atracao:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/atracoes/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('config').select('data').eq('id', 'atracoes').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    const list = data && data.data ? data.data : [];
    const oldItem = list.find(a => a.id == req.params.id || a['Nome da Atração'] === req.params.id);
    const filteredList = list.filter(a => a.id != req.params.id && a['Nome da Atração'] !== req.params.id);
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'atracoes', data: filteredList });
    if (upsertErr) throw upsertErr;
    
    if (oldItem) await syncToGoogleSheets('atracoes', 'delete', oldItem);
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting atracao:', e);
    res.status(500).json({error: e.message});
  }
});

// ── Identidade imutável dos roteiros ────────────────────────────────────────
// A coluna "nome" da tabela roteiros passa a guardar um ID imutável (rot_...).
// O nome de exibição vive em data.nome. Renomear nunca mais quebra vínculos.
function gerarIdRoteiro() {
  return 'rot_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
}

async function buscarTodosRoteiros() {
  const { data, error } = await supabase.from('roteiros').select('*');
  if (error) throw error;
  return data || [];
}

// Aceita: ID (rot_...), chave legada (nome antigo como chave física) ou nome de exibição
async function acharRoteiroPorChaveOuNome(param) {
  if (!param) return null;
  const { data: porChave } = await supabase.from('roteiros').select('*').eq('nome', param).maybeSingle();
  if (porChave) return porChave;
  if (String(param).startsWith('rot_')) return null;
  const todos = await buscarTodosRoteiros();
  return todos.find(r => r.data && r.data.nome === param) || null;
}

// Histórico embutido: guarda as últimas 5 versões dentro do próprio registro
// (no máximo 1 snapshot a cada 10 minutos, para não inflar com autosaves).
function aplicarHistorico(dadosNovos, dadosAntigos) {
  if (!dadosAntigos) return dadosNovos;
  const historicoAnterior = Array.isArray(dadosAntigos._historico) ? dadosAntigos._historico : [];
  const ultimo = historicoAnterior[historicoAnterior.length - 1];
  const agora = Date.now();
  const ultimoTs = ultimo ? Date.parse(ultimo.em) || 0 : 0;
  let novoHistorico = historicoAnterior;
  if (!ultimo || (agora - ultimoTs) > 10 * 60 * 1000) {
    const snapshot = { ...dadosAntigos };
    delete snapshot._historico;
    novoHistorico = [...historicoAnterior, { em: dadosAntigos.atualizadoEm || new Date().toISOString(), dados: snapshot }].slice(-5);
  }
  return { ...dadosNovos, _historico: novoHistorico };
}

// Guarda de versão: se o registro no banco mudou desde que o cliente o carregou,
// recusa a gravação (evita que duas pessoas se sobrescrevam sem perceber).
function conflitoDeVersao(baseVersao, dadosArmazenados) {
  if (baseVersao === undefined || baseVersao === null) return false; // cliente legado: não valida
  if (!dadosArmazenados || !dadosArmazenados.atualizadoEm) return false;
  return String(dadosArmazenados.atualizadoEm) !== String(baseVersao);
}

// Migração única e idempotente: converte chaves legadas (nome de exibição)
// para IDs imutáveis (rot_...), preservando o nome em data.nome e gravando
// data.roteiroId nas cotações vinculadas. Segura de rodar quantas vezes for.
async function migrarRoteirosParaId() {
  const resultado = { migrados: [], jaOk: 0, erros: [] };
  const todos = await buscarTodosRoteiros();

  for (const linha of todos) {
    try {
      if (String(linha.nome).startsWith('rot_')) {
        // Já migrado: só garante id/nome dentro do data
        const d = linha.data || {};
        if (d.id !== linha.nome || !d.nome) {
          d.id = linha.nome;
          if (!d.nome) d.nome = linha.nome;
          await supabase.from('roteiros').update({ data: d }).eq('nome', linha.nome);
        }
        resultado.jaOk++;
        continue;
      }

      const nomeExibicao = linha.nome;
      const novoId = gerarIdRoteiro();
      const dados = { ...(linha.data || {}), id: novoId, nome: nomeExibicao, _chaveLegada: nomeExibicao };

      // 1. Insere a nova linha com a chave imutável (só apaga a antiga se der certo)
      const { error: insErr } = await supabase.from('roteiros').insert({ nome: novoId, data: dados });
      if (insErr) throw insErr;

      // 2. Atualiza cotações vinculadas pelo nome → grava roteiroId
      const { data: orcs } = await supabase.from('orcamentos').select('*');
      for (const orc of (orcs || [])) {
        const d = orc.data || {};
        if (d.orcRoteiroVinculado === nomeExibicao || d.roteiroVinculado === nomeExibicao) {
          d.roteiroId = novoId;
          await supabase.from('orcamentos').update({ data: d }).eq('id', orc.id);
        }
      }

      // 3. Remove a linha antiga
      const { error: delErr } = await supabase.from('roteiros').delete().eq('nome', nomeExibicao);
      if (delErr) throw delErr;

      resultado.migrados.push({ de: nomeExibicao, para: novoId });
    } catch (e) {
      resultado.erros.push({ roteiro: linha.nome, erro: e.message });
    }
  }

  if (resultado.migrados.length || resultado.erros.length) {
    console.log('[Migração Roteiros→ID]', JSON.stringify(resultado));
  }
  return resultado;
}

// Endpoint manual (admin) para conferir/reexecutar a migração
app.get('/api/admin/migrar-roteiros', async (req, res) => {
  try {
    const resultado = await migrarRoteirosParaId();
    res.json({ success: true, ...resultado });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.get('/api/roteiros', async (req, res) => {
  try {
    const [rotsRes, baseRes] = await Promise.all([
      supabase.from('roteiros').select('*'),
      supabase.from('rotas_base').select('data').eq('id', 'base').single()
    ]);
    if (rotsRes.error) throw rotsRes.error;
    
    const rotasMap = {};
    for (const r of rotsRes.data || []) {
      // Filtra os roteiros ativos (não deletados)
      if (r.data && !r.data.deletado) {
        const dados = { ...r.data, id: r.nome, nome: r.data.nome || r.nome };
        // Chave do mapa = nome de exibição (compatível com o frontend);
        // em caso de nomes duplicados, acrescenta sufixo apenas na exibição.
        let chave = dados.nome;
        let n = 2;
        while (rotasMap[chave]) { chave = `${dados.nome} (${n++})`; }
        rotasMap[chave] = dados;
      }
    }
    if (baseRes.data && baseRes.data.data) {
      rotasMap['[PLANILHA] Base de Rotas'] = { dias: baseRes.data.data };
    }
    res.json(rotasMap);
  } catch(e) {
    console.error('Error getting roteiros:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/roteiros/:name', async (req, res) => {
  try {
    const name = req.params.name;
    const corpo = req.body; // objeto completo do roteiro
    
    if (name === '[PLANILHA] Base de Rotas') {
      const { error } = await supabase.from('rotas_base').upsert({
        id: 'base',
        data: corpo.dias || corpo
      });
      if (error) throw error;
      return res.json({ ok: true, name, roteiro: corpo });
    }

    // Resolve o registro existente por ID ou nome (legado)
    const linha = await acharRoteiroPorChaveOuNome(name);

    // Proteção: salvar por NOME em cima de roteiro de OUTRO cliente é colisão,
    // não atualização (ex.: criar "Roteiro Tokyo" quando já existe um de outro cliente).
    if (linha && !String(name).startsWith('rot_')) {
      const clienteExistente = linha.data?.notionClienteId || linha.data?.cliente?.notionClienteId;
      const clienteNovo = corpo?.notionClienteId || corpo?.cliente?.notionClienteId;
      const corpoSemId = !corpo.id;
      if (corpoSemId && clienteExistente && clienteNovo && clienteExistente !== clienteNovo) {
        return res.status(409).json({
          error: 'conflict_client',
          message: `O nome "${name}" já está sendo usado por outro cliente. Por favor, escolha um nome diferente.`
        });
      }
    }

    const chave = linha ? linha.nome : (String(name).startsWith('rot_') ? name : gerarIdRoteiro());
    const armazenado = linha ? linha.data : null;

    // Guarda de versão: recusa gravar por cima de uma versão mais nova
    const baseVersao = corpo._baseVersao;
    delete corpo._baseVersao;
    if (conflitoDeVersao(baseVersao, armazenado)) {
      return res.status(409).json({
        error: 'conflict_version',
        message: 'Este roteiro foi alterado em outra sessão (outra aba ou outro usuário). Recarregue-o antes de continuar editando.',
        atualizadoEm: armazenado.atualizadoEm
      });
    }

    let dados = {
      ...corpo,
      id: chave,
      nome: corpo.nome || (armazenado && armazenado.nome) || (String(name).startsWith('rot_') ? (armazenado?.nome || 'Roteiro') : name),
      atualizadoEm: new Date().toISOString(),
      criadoEm: (armazenado && armazenado.criadoEm) || corpo.criadoEm || new Date().toISOString()
    };
    dados = aplicarHistorico(dados, armazenado);

    const { error } = await supabase.from('roteiros').upsert({
      nome: chave,
      data: dados
    }, { onConflict: 'nome' });
    if (error) throw error;
    
    res.json({ ok: true, name, id: chave, nome: dados.nome, atualizadoEm: dados.atualizadoEm, roteiro: dados });
  } catch(e) {
    console.error('Error saving roteiro:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/roteiros/:name/renomear', async (req, res) => {
  try {
    const nomeAntigo = req.params.name;
    const { novoNome, roteiroObj } = req.body;
    
    if (!novoNome) {
      return res.status(400).json({ error: 'invalid_name', message: 'O novo nome do roteiro é obrigatório.' });
    }

    // Com IDs imutáveis, renomear é só trocar o rótulo (data.nome) sob a mesma chave.
    const linha = await acharRoteiroPorChaveOuNome(nomeAntigo);
    if (!linha) {
      return res.status(404).json({ error: 'not_found', message: `Roteiro "${nomeAntigo}" não encontrado.` });
    }
    const chave = linha.nome;

    let dados = {
      ...(roteiroObj || linha.data || {}),
      id: chave,
      nome: novoNome,
      atualizadoEm: new Date().toISOString(),
      criadoEm: (linha.data && linha.data.criadoEm) || new Date().toISOString()
    };
    delete dados._baseVersao;
    dados = aplicarHistorico(dados, linha.data);

    const { error: updateErr } = await supabase
      .from('roteiros')
      .update({ data: dados })
      .eq('nome', chave);
    if (updateErr) throw updateErr;
    
    // Atualiza o rótulo nas cotações vinculadas (por ID ou por nome legado)
    const nomeExibicaoAntigo = (linha.data && linha.data.nome) || nomeAntigo;
    const { data: orcamentos, error: fetchOrcErr } = await supabase.from('orcamentos').select('*');
    if (!fetchOrcErr && orcamentos) {
      for (const orc of orcamentos) {
        const d = orc.data || {};
        const vinculadoPorId = d.roteiroId === chave;
        const vinculadoPorNome = d.orcRoteiroVinculado === nomeExibicaoAntigo || d.roteiroVinculado === nomeExibicaoAntigo
          || d.orcRoteiroVinculado === nomeAntigo || d.roteiroVinculado === nomeAntigo;
        if (vinculadoPorId || vinculadoPorNome) {
          if (d.orcRoteiroVinculado) d.orcRoteiroVinculado = novoNome;
          if (d.roteiroVinculado) d.roteiroVinculado = novoNome;
          d.roteiroId = chave; // aproveita para consolidar o vínculo por ID
          await supabase.from('orcamentos').update({ data: d }).eq('id', orc.id);
        }
      }
    }
    
    res.json({ ok: true, novoNome, id: chave, atualizadoEm: dados.atualizadoEm });
  } catch(e) {
    console.error('Error renaming roteiro:', e);
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/roteiros/:name', async (req, res) => {
  try {
    const name = req.params.name;
    if (name === '[PLANILHA] Base de Rotas') {
      const { error } = await supabase.from('rotas_base').delete().eq('id', 'base');
      if (error) throw error;
    } else {
      // Soft Delete: resolve por ID ou nome, marca como deletado no JSON e atualiza
      const linha = await acharRoteiroPorChaveOuNome(name);
      if (!linha) throw new Error(`Roteiro "${name}" não encontrado.`);
      
      const rot = linha.data || {};
      rot.deletado = true;
      rot.deletadoEm = new Date().toISOString();
      
      const { error } = await supabase.from('roteiros').upsert({
        nome: linha.nome,
        data: rot
      }, { onConflict: 'nome' });
      if (error) throw error;
    }
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting roteiro:', e);
    res.status(500).json({error: e.message});
  }
});

// ── API: Lixeira do Sistema (Soft Delete Rescues) ──────────────────────────
app.get('/api/lixeira', async (req, res) => {
  try {
    const [orcsRes, rotsRes] = await Promise.all([
      supabase.from('orcamentos').select('*'),
      supabase.from('roteiros').select('*')
    ]);
    if (orcsRes.error) throw orcsRes.error;
    if (rotsRes.error) throw rotsRes.error;
    
    const orcDeletados = (orcsRes.data || [])
      .map(r => r.data)
      .filter(item => item && item.deletado);
      
    const rotDeletados = (rotsRes.data || [])
      .map(r => ({ nome: r.nome, ...r.data }))
      .filter(item => item && item.deletado);
      
    res.json({
      orcamentos: orcDeletados,
      roteiros: rotDeletados
    });
  } catch(e) {
    console.error('Error getting trash:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/orcamentos/:id/restaurar', async (req, res) => {
  try {
    const id = req.params.id;
    const { data, error: fetchErr } = await supabase.from('orcamentos').select('data').eq('id', String(id)).single();
    if (fetchErr) throw fetchErr;
    
    const orc = data.data || {};
    delete orc.deletado;
    delete orc.deletadoEm;
    
    const { error } = await supabase.from('orcamentos').upsert({ id: String(id), data: orc });
    if (error) throw error;
    res.json({ success: true });
  } catch(e) {
    console.error('Error restoring orcamento:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/orcamentos/:id/definitivo', async (req, res) => {
  try {
    const id = req.params.id;
    const { error } = await supabase.from('orcamentos').delete().eq('id', String(id));
    if (error) throw error;
    res.json({ success: true });
  } catch(e) {
    console.error('Error hard deleting orcamento:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/roteiros/:name/restaurar', async (req, res) => {
  try {
    const name = req.params.name;
    const linha = await acharRoteiroPorChaveOuNome(name);
    if (!linha) throw new Error(`Roteiro "${name}" não encontrado.`);
    
    const rot = linha.data || {};
    delete rot.deletado;
    delete rot.deletadoEm;
    
    const { error } = await supabase.from('roteiros').upsert({ nome: linha.nome, data: rot }, { onConflict: 'nome' });
    if (error) throw error;
    res.json({ success: true });
  } catch(e) {
    console.error('Error restoring roteiro:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/roteiros/:name/definitivo', async (req, res) => {
  try {
    const name = req.params.name;
    const linha = await acharRoteiroPorChaveOuNome(name);
    const chave = linha ? linha.nome : name;
    const { error } = await supabase.from('roteiros').delete().eq('nome', chave);
    if (error) throw error;
    res.json({ success: true });
  } catch(e) {
    console.error('Error hard deleting roteiro:', e);
    res.status(500).json({error: e.message});
  }
});

// ── API: Gestão de Sequências (Aba Rotas) ───────────────────────────────────
app.get('/api/rotas-base', async (req, res) => {
  try {
    const { data, error } = await supabase.from('rotas_base').select('data').eq('id', 'base').single();
    if (error && error.code !== 'PGRST116') throw error;
    const base = data && data.data ? data.data : [];
    res.json(base);
  } catch(e) {
    console.error('Error getting rotas-base:', e);
    res.status(500).json({error: e.message});
  }
});

app.post('/api/rotas-base', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('rotas_base').select('data').eq('id', 'base').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    
    const list = data && data.data ? data.data : [];
    const novo = { id: Date.now(), ...req.body };
    list.push(novo);
    
    const { error: upsertErr } = await supabase.from('rotas_base').upsert({
      id: 'base',
      data: list
    });
    if (upsertErr) throw upsertErr;
    
    await syncToGoogleSheets('rotas', 'insert', novo);
    res.json(novo);
  } catch(e) {
    console.error('Error saving rotas-base:', e);
    res.status(500).json({error: e.message});
  }
});

app.put('/api/rotas-base/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('rotas_base').select('data').eq('id', 'base').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    
    const list = data && data.data ? data.data : [];
    const idx = list.findIndex(d => d.id == req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Não encontrado' });
    
    const oldItem = list[idx];
    list[idx] = { ...list[idx], ...req.body };
    
    const { error: upsertErr } = await supabase.from('rotas_base').upsert({
      id: 'base',
      data: list
    });
    if (upsertErr) throw upsertErr;
    
    await syncToGoogleSheets('rotas', 'update', list[idx], oldItem);
    res.json(list[idx]);
  } catch(e) {
    console.error('Error updating rotas-base:', e);
    res.status(500).json({error: e.message});
  }
});

app.delete('/api/rotas-base/:id', async (req, res) => {
  try {
    const { data, error: fetchErr } = await supabase.from('rotas_base').select('data').eq('id', 'base').single();
    if (fetchErr && fetchErr.code !== 'PGRST116') throw fetchErr;
    
    const list = data && data.data ? data.data : [];
    const oldItem = list.find(d => d.id == req.params.id);
    const filteredList = list.filter(d => d.id != req.params.id);
    
    const { error: upsertErr } = await supabase.from('rotas_base').upsert({
      id: 'base',
      data: filteredList
    });
    if (upsertErr) throw upsertErr;
    
    if (oldItem) await syncToGoogleSheets('rotas', 'delete', oldItem);
    res.json({ ok: true });
  } catch(e) {
    console.error('Error deleting rotas-base:', e);
    res.status(500).json({error: e.message});
  }
});


// ── API: Sync Google Sheets ─────────────────────────────────────────────────
app.post('/api/sync', async (req, res) => {
  try {
    const { data: cfgData, error: cfgErr } = await supabase.from('config').select('data').eq('id', 'app_config').single();
    if (cfgErr) throw cfgErr;
    const config = cfgData?.data || {};
    const { sheets_id, sheets_aba_transportes, sheets_aba_experiencias, sheets_aba_atracoes, sheets_aba_rotas, sheets_aba_hoteis } = config;

    if (!sheets_id) {
      return res.status(400).json({ error: 'ID do Google Sheets não configurado nas Configurações.' });
    }

    const abaT = sheets_aba_transportes || 'Base';
    const abaE = sheets_aba_experiencias || 'BaseEX';
    const abaA = sheets_aba_atracoes || 'Atracoes';
    const abaRotas = sheets_aba_rotas || 'Rotas';
    let abaHoteis = sheets_aba_hoteis || 'Hotéis';

    const db = {
      config,
      transportes: null,
      experiencias: null,
      atracoes: null,
      hoteis: null,
      rotas: null,
      templates_vouchers: null
    };

  // Busca uma aba via gviz usando o range completo (inclui linhas em branco)
  async function fetchAba(nomeAba) {
    const url = `https://docs.google.com/spreadsheets/d/${sheets_id}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(nomeAba)}`;
    const resp = await fetch(url);
    const text = await resp.text();
    const jsonStr = text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1);
    const json = JSON.parse(jsonStr);
    return json.table;
  }

  function cellVal(cell) {
    if (!cell) return '';
    if (cell.f != null) return String(cell.f).trim();
    if (cell.v != null) return String(cell.v).trim();
    return '';
  }

  // Para colunas de preço: usa sempre o valor numérico bruto (cell.v)
  // evitando que o formato da célula (ex: "14.17" de ¥14.170) distorça o número
  function cellNum(cell) {
    if (!cell) return 0;
    if (cell.v != null && typeof cell.v === 'number') return cell.v;
    // fallback: tenta extrair número do valor formatado
    return parsePreco(cellVal(cell));
  }

  let nTransp = 0, nExp = 0, nAtracoes = 0;

    // ── TRANSPORTES (aba "Base") ─────────────────────────────────────
    // Estrutura: cabeçalho aparece numa linha que começa com "Trecho".
    // Colunas: Trecho | Tipo | Linha | Categoria | Preço | Tempo | Observações | Comprar | TrechoCompleto
    try {
      const table = await fetchAba(abaT);
      const rows = table.rows || [];

      // Procura a linha de cabeçalho
      let headerIdx = -1;
      let headers = [];
      
      // Tenta ler dos 'cols' do gviz primeiro
      if (table.cols && table.cols.length > 0 && table.cols[0].label) {
        headers = table.cols.map(c => (c.label || '').toLowerCase().trim());
      } else {
        for (let i = 0; i < rows.length; i++) {
          const firstCell = cellVal(rows[i].c?.[0]);
          if (firstCell && firstCell.toLowerCase() === 'trecho') { 
            headerIdx = i; 
            headers = (rows[i].c || []).map(cell => (cellVal(cell) || '').toLowerCase().trim());
            break; 
          }
        }
      }
      
      const idxTrecho = headers.findIndex(h => h.includes('trecho')) > -1 ? headers.findIndex(h => h.includes('trecho')) : 0;
      const idxIdade = headers.findIndex(h => h.includes('idade') || h.includes('adulto') || h.includes('infantil'));
      const idxTipo = headers.findIndex(h => h.includes('tipo') && !h.includes('idade') && !h.includes('adulto'));
      const idxLinha = headers.findIndex(h => h.includes('linha'));
      const idxCategoria = headers.findIndex(h => h.includes('categoria'));
      const idxPreco = headers.findIndex(h => h.includes('preço') || h.includes('preco') || h.includes('unitário'));
      const idxTempo = headers.findIndex(h => h.includes('tempo'));
      const idxObs = headers.findIndex(h => h.includes('observação') || h.includes('observacao'));
      const idxLink = headers.findIndex(h => {
        const val = h.toLowerCase().trim();
        return val.includes('link') || val === 'comprar';
      });
      const idxId = headers.findIndex(h => h === 'id');
      const idxCompra = headers.findIndex(h => {
        const val = h.toLowerCase().trim();
        return val === 'compra' || val === 'instrução de compra' || val === 'instrucao de compra' || (val.includes('compra') && val !== 'comprar' && val !== 'comprado');
      });
      const idxUso = headers.findIndex(h => {
        const val = h.toLowerCase().trim();
        return val === 'uso' || val.includes('uso') || val.includes('instrução de uso') || val.includes('instrucao de uso');
      });


      const dataRows = headerIdx >= 0 ? rows.slice(headerIdx + 1) : rows;

      console.log('HEADERS:', headers); console.log('IDXs:', idxTrecho, idxIdade, idxTipo, idxLinha, idxCategoria, idxPreco, idxTempo); const transportes = dataRows
        .map((r, i) => {
          const c = r.c || [];
          const trecho = cellVal(c[idxTrecho]);
          if (!trecho) return null;
          
          // Se encontrou Idade, sabemos que todas as colunas originais andaram 1 casa
          const offset = idxIdade > -1 ? 1 : 0;
          
          return {
            id: (idxId > -1 ? cellVal(c[idxId]) : null) || cellVal(c[12]) || (i + 1),
            trecho,
            idade:      (idxIdade > -1 ? cellVal(c[idxIdade]) : ''),
            tipo:       (idxTipo > -1 ? cellVal(c[idxTipo]) : cellVal(c[1 + offset])),
            linha:      (idxLinha > -1 ? cellVal(c[idxLinha]) : cellVal(c[2 + offset])),
            categoria:  (idxCategoria > -1 ? cellVal(c[idxCategoria]) : cellVal(c[3 + offset])),
            preco_jpy:  cellNum(c[idxPreco > -1 ? idxPreco : 4 + offset]),
            tempo:      (idxTempo > -1 ? cellVal(c[idxTempo]) : cellVal(c[5 + offset])),
            observacao: (idxObs > -1 ? cellVal(c[idxObs]) : cellVal(c[6 + offset])),
            link:       (idxLink > -1 ? cellVal(c[idxLink]) : cellVal(c[7 + offset])),
            compra:     (idxCompra > -1 ? cellVal(c[idxCompra]) : ''),
            uso:        (idxUso > -1 ? cellVal(c[idxUso]) : '')
          };
        })
        .filter(Boolean);

      db.transportes = transportes;
      nTransp = transportes.length;
    } catch (e) { console.error('Erro aba transportes:', e.message); }

    // ── EXPERIÊNCIAS (aba "BaseEX") ──────────────────────────────────
    // Estrutura SEM cabeçalho. Colunas: Nome | Tipo | (vazio) | Categoria | Preço | ...
    try {
      const table = await fetchAba(abaE);
      const rows = table.rows || [];

      // Se a primeira linha for cabeçalho (primeira célula vazia ou "nome"/"experiência"), pula
      let dataRows = rows;
      const first = cellVal(rows[0]?.c?.[0]).toLowerCase();
      if (first === 'nome' || first === 'experiência' || first === 'experiencia' || first === '') {
        dataRows = rows.slice(1);
      }

      const experiencias = dataRows
        .map((r, i) => {
          const c = r.c || [];
          const nome = cellVal(c[0]);
          if (!nome) return null;
          return {
            id: cellVal(c[10]) || (i + 1),
            nome,
            tipo:       cellVal(c[1]) || 'Ingresso',
            preco_jpy:  cellNum(c[4]),  // Preço está na 5ª coluna (índice 4)
            observacao: '',
            link:       cellVal(c[7])
          };
        })
        .filter(Boolean);

      db.experiencias = experiencias;
      nExp = experiencias.length;
    } catch (e) { console.error('Erro aba experiências:', e.message); }

    // ── ATRAÇÕES (aba "Atracoes") ────────────────────────────────────
    try {
      const table = await fetchAba(abaA);
      const rows = table.rows || [];

      if (rows.length > 0) {
        // Encontra a linha de cabeçalho
        let headerIdx = -1;
        let foundHeader = false;
        let headers = [];

        // Tenta ler dos 'cols' do gviz primeiro
        if (table.cols && table.cols.length > 0 && table.cols[0].label) {
          headers = table.cols.map(c => (c.label || '').toLowerCase().trim());
          foundHeader = true;
        } else {
          for (let i = 0; i < Math.min(5, rows.length); i++) {
            const cells = rows[i].c || [];
            const rowVals = cells.map(cellVal).map(v => v.toLowerCase());
            if (rowVals.some(v => v.includes('atração') || v.includes('atracao') || v.includes('atrações') || v.includes('atracoes') || v.includes('nome'))) {
              headerIdx = i;
              foundHeader = true;
              headers = rowVals;
              break;
            }
          }
        }

        const headerVals = headers;

        const getIdx = (keywords, defaultVal) => {
          let idx = headerVals.findIndex(h => keywords.some(k => h === k));
          if (idx >= 0) return idx;
          idx = headerVals.findIndex(h => keywords.some(k => h.includes(k)));
          return idx >= 0 ? idx : defaultVal;
        };

        const idxCidade = getIdx(['cidade', 'city', 'local'], 0);
        const idxBairro = getIdx(['bairro', 'neighborhood', 'região', 'regiao', 'zona'], 1);
        const idxNome = getIdx(['nome da atração', 'nome da atracao', 'nome', 'atração', 'atracao', 'name', 'título', 'titulo'], 2);
        const idxDescricao = getIdx(['descrição detalhada', 'descricao detalhada', 'descrição', 'descricao', 'detalhes', 'description', 'sobre'], 3);
        const idxPreco = getIdx(['preço (ingresso)', 'preco (ingresso)', 'preço', 'preco', 'ingresso', 'valor', 'price', 'custo'], 4);
        const idxOrigem = getIdx(['origem', 'source', 'casal'], 5);
        const idxDiasFechados = getIdx(['diasfechados', 'dias fechados', 'fechados', 'fechado'], 5);
        const idxId = getIdx(['id', 'id_atracao', 'idatracao'], 6);
        const idxManutencaoInicio = getIdx(['manutencaoinicio', 'manutencao_inicio', 'manutenção início', 'manutencao inicio'], 7);
        const idxManutencaoFim = getIdx(['manutencaofim', 'manutencao_fim', 'manutenção fim', 'manutencao fim'], 8);
        const idxManutencaoMotivo = getIdx(['manutencaomotivo', 'manutencao_motivo', 'motivo', 'manutencao motivo'], 9);
        const idxFoto = getIdx(['foto (url)', 'foto', 'foto_url', 'imagem', 'image'], 10);

        const dataRows = (foundHeader && headerIdx >= 0) ? rows.slice(headerIdx + 1) : rows;

        const atracoes = dataRows
          .map((r, i) => {
            const c = r.c || [];
            const nome = cellVal(c[idxNome]);
            if (!nome) return null;
            
            let diasFechados = [];
            const rawDias = cellVal(c[idxDiasFechados]);
            if (rawDias) {
              try {
                const parsed = JSON.parse(rawDias);
                if (Array.isArray(parsed)) {
                  diasFechados = parsed.map(Number).filter(n => !isNaN(n));
                } else {
                  const parsedNum = Number(parsed);
                  if (!isNaN(parsedNum) && rawDias.trim() !== '') {
                    diasFechados = [parsedNum];
                  }
                }
              } catch (e) {
                if (rawDias.includes(',')) {
                  diasFechados = rawDias.split(',').map(n => parseInt(n.trim(), 10)).filter(n => !isNaN(n));
                } else {
                  const valNum = parseInt(rawDias.trim(), 10);
                  if (!isNaN(valNum)) {
                    diasFechados = [valNum];
                  }
                }
              }
            }

            return {
              id: cellVal(c[idxId]) || cellVal(c[6]) || String(i + 1),
              Cidade: cellVal(c[idxCidade]) || 'Geral',
              Bairro: cellVal(c[idxBairro]) || '',
              'Nome da Atração': nome,
              'Descrição Detalhada': (cellVal(c[idxDescricao]) || '').replace(/<[^>]*>?/gm, '').trim(),
              'Preço (Ingresso)': cellVal(c[idxPreco]) || 'Gratuito',
              diasFechados: diasFechados,
              manutencaoInicio: cellVal(c[idxManutencaoInicio]) || '',
              manutencaoFim: cellVal(c[idxManutencaoFim]) || '',
              manutencaoMotivo: cellVal(c[idxManutencaoMotivo]) || '',
              'Foto (URL)': cellVal(c[idxFoto]) || '',
              Origem: cellVal(c[idxOrigem]) || 'Google Sheets'
            };
          })
          .filter(Boolean);

        db.atracoes = atracoes;
        nAtracoes = atracoes.length;
      }
    } catch (e) { console.error('Erro aba atrações:', e.message); }

    // ── ROTAS (aba "Rotas") ──────────────────────────────────────────
    try {
      const table = await fetchAba(abaRotas);
      const rows = table.rows || [];
      let diasImportados = [];
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || !row.c) continue;
        
        const cidade = cellVal(row.c[0]);
        const nomeDaRota = cellVal(row.c[1]);
        const atracoesRaw = cellVal(row.c[2]);
        const idStr = cellVal(row.c[3]); // Lę ID da coluna D
        const id = idStr ? idStr : i; // Fallback para i se estiver vazio
        
        if (cidade && nomeDaRota) {
          diasImportados.push({ 
            id: id,
            cidade, 
            nomeDaRota, 
            atracoesDoDia: atracoesRaw ? atracoesRaw.split(',').map(s => s.trim()).filter(Boolean) : [] 
          });
        }
      }
      if (diasImportados.length > 0) {
        db.rotas = { '[PLANILHA] Base de Rotas': { dias: diasImportados } };
      } else {
        db.rotas = { '[PLANILHA] Base de Rotas': { dias: [] } };
      }
    } catch (e) { console.error('Erro aba Rotas:', e.message); }

    // ── HOTÉIS (aba "Hotéis") ────────────────────────────────────────
    let nHoteis = 0;
    try {
      let table;
      try {
        table = await fetchAba(abaHoteis);
      } catch (err) {
        if (!sheets_aba_hoteis && abaHoteis === 'Hotéis') {
          abaHoteis = 'hoteis';
          table = await fetchAba(abaHoteis);
        } else {
          throw err;
        }
      }
      const rows = table.rows || [];

      if (rows.length > 0) {
        // Encontra a linha de cabeçalho
        let headerIdx = -1;
        let foundHeader = false;
        let headers = [];

        // Tenta ler dos 'cols' do gviz primeiro
        if (table.cols && table.cols.length > 0 && table.cols[0].label) {
          headers = table.cols.map(c => (c.label || '').toLowerCase().trim());
          foundHeader = true;
        } else {
          for (let i = 0; i < Math.min(5, rows.length); i++) {
            const cells = rows[i].c || [];
            const rowVals = cells.map(cellVal).map(v => v.toLowerCase());
            if (rowVals.some(v => v.includes('hotel') || v.includes('hotéis') || v.includes('hoteis') || v.includes('nome'))) {
              headerIdx = i;
              foundHeader = true;
              headers = rowVals;
              break;
            }
          }
        }

        const headerVals = headers;

        const getIdx = (keywords, defaultVal) => {
          let idx = headerVals.findIndex(h => keywords.some(k => h === k));
          if (idx >= 0) return idx;
          idx = headerVals.findIndex(h => keywords.some(k => h.includes(k)));
          return idx >= 0 ? idx : defaultVal;
        };

        const idxNome = getIdx(['nome do hotel', 'hotel', 'nome', 'name'], 0);
        const idxCidade = getIdx(['cidade', 'city', 'local'], 1);
        const idxDescricao = getIdx(['descrição', 'descricao', 'description', 'sobre'], 2);
        const idxFoto = getIdx(['foto (url)', 'foto', 'imagem', 'image', 'foto_url'], 3);
        const idxLinkMaps = getIdx(['link do google maps', 'link maps', 'maps', 'google maps', 'link'], 4);
        const idxComodidades = getIdx(['comodidades', 'tags', 'facilidades', 'comodidade'], 5);
        const idxId = getIdx(['id'], 6);

        const dataRows = (foundHeader && headerIdx >= 0) ? rows.slice(headerIdx + 1) : rows;

        const hoteis = dataRows
          .map((r, i) => {
            const c = r.c || [];
            const nome = cellVal(c[idxNome]);
            if (!nome) return null;

            return {
              id: cellVal(c[idxId]) || String(i + 1),
              'Nome do Hotel': nome,
              Cidade: cellVal(c[idxCidade]) || '',
              'Descrição': cellVal(c[idxDescricao]) || '',
              'Foto (URL)': cellVal(c[idxFoto]) || '',
              'Link do Google Maps': cellVal(c[idxLinkMaps]) || '',
              Comodidades: cellVal(c[idxComodidades]) || ''
            };
          })
          .filter(Boolean);

        db.hoteis = hoteis;
        nHoteis = hoteis.length;
      }
    } catch (e) { console.error('Erro aba hotéis:', e.message); }

    // ── MODELOS DE INSTRUÇÕES DE VOUCHERS (aba "ModelosVouchers") ─────────
    let nTemplatesVouchers = 0;
    try {
      const abaV = config.sheets_aba_instrucoes_vouchers || 'ModelosVouchers';
      const table = await fetchAba(abaV);
      const rows = table.rows || [];

      if (rows.length > 0) {
        // Encontra a linha de cabeçalho
        let headerIdx = -1;
        let foundHeader = false;
        let headers = [];

        // Tenta ler dos 'cols' do gviz primeiro
        if (table.cols && table.cols.length > 0 && table.cols[0].label) {
          headers = table.cols.map(c => (c.label || '').toLowerCase().trim());
          foundHeader = true;
        } else {
          for (let i = 0; i < Math.min(5, rows.length); i++) {
            const cells = rows[i].c || [];
            const rowVals = cells.map(cellVal).map(v => v.toLowerCase());
            if (rowVals.some(v => v.includes('modelo') || v.includes('titulo') || v.includes('título') || v.includes('chave') || v.includes('item'))) {
              headerIdx = i;
              foundHeader = true;
              headers = rowVals;
              break;
            }
          }
        }

        const headerVals = headers;

        const getIdx = (keywords, defaultVal) => {
          let idx = headerVals.findIndex(h => keywords.some(k => h === k));
          if (idx >= 0) return idx;
          idx = headerVals.findIndex(h => keywords.some(k => h.includes(k)));
          return idx >= 0 ? idx : defaultVal;
        };

        const idxTitulo = getIdx(['título do modelo', 'titulo do modelo', 'modelo', 'titulo', 'título', 'chave', 'item'], 0);
        const idxInstrucoes = getIdx(['instruções padrão', 'instrucoes padrao', 'instruções', 'instrucoes', 'texto', 'descritivo', 'descrição', 'descricao'], 1);

        const dataRows = (foundHeader && headerIdx >= 0) ? rows.slice(headerIdx + 1) : rows;

        const templatesVouchers = dataRows
          .map((r, i) => {
            const c = r.c || [];
            const titulo = cellVal(c[idxTitulo]);
            if (!titulo) return null;

            return {
              id: String(i + 1),
              titulo,
              instrucoes: cellVal(c[idxInstrucoes]) || ''
            };
          })
          .filter(Boolean);

        db.templates_vouchers = templatesVouchers;
        nTemplatesVouchers = templatesVouchers.length;
      }
    } catch (e) {
      console.warn('Aba de Modelos de Vouchers não encontrada ou vazia:', e.message);
    }


    db.config.ultima_sincronizacao = new Date().toISOString();
    
    // Grava apenas as tabelas alteradas em paralelo (apenas as que foram lidas sem erros)
    const syncPromises = [
      supabase.from('config').upsert({ id: 'app_config', data: db.config || {} }).then(r => { if (r.error) throw r.error; })
    ];

    if (db.transportes !== null) {
      syncPromises.push(supabase.from('config').upsert({ id: 'transportes', data: db.transportes }).then(r => { if (r.error) throw r.error; }));
    }
    if (db.experiencias !== null) {
      syncPromises.push(supabase.from('config').upsert({ id: 'experiencias', data: db.experiencias }).then(r => { if (r.error) throw r.error; }));
    }
    if (db.atracoes !== null) {
      syncPromises.push(supabase.from('config').upsert({ id: 'atracoes', data: db.atracoes }).then(r => { if (r.error) throw r.error; }));
    }
    if (db.hoteis !== null) {
      syncPromises.push(supabase.from('config').upsert({ id: 'hoteis', data: db.hoteis }).then(r => { if (r.error) throw r.error; }));
    }
    if (db.templates_vouchers !== null) {
      syncPromises.push(supabase.from('config').upsert({ id: 'templates_vouchers', data: db.templates_vouchers }).then(r => { if (r.error) throw r.error; }));
    }
    if (db.rotas !== null && db.rotas['[PLANILHA] Base de Rotas']?.dias) {
      syncPromises.push(supabase.from('rotas_base').upsert({ id: 'base', data: db.rotas['[PLANILHA] Base de Rotas'].dias }).then(r => { if (r.error) throw r.error; }));
    }
    
    await Promise.all(syncPromises);

    res.json({ ok: true, ultima_sincronizacao: db.config.ultima_sincronizacao, nTransp, nExp, nAtracoes, nHoteis, nTemplatesVouchers });

  } catch (err) {
    console.error('Erro no sync:', err);
    res.status(500).json({ error: 'Erro ao sincronizar. Verifique se a planilha está pública e se os nomes das abas estão corretos.' });
  }
});

app.get('/api/cambio', async (req, res) => {
  try {
    // API gratuita de câmbio, sem necessidade de chave
    const resp = await fetch('https://open.er-api.com/v6/latest/JPY');
    const data = await resp.json();
    if (data && data.rates) {
      const usd = data.rates.USD;
      const brl = data.rates.BRL;
      res.json({ ok: true, cambio_jpy_usd: usd, cambio_jpy_brl: brl, data: data.time_last_update_utc });
    } else {
      res.status(500).json({ error: 'Resposta inesperada da API de câmbio.' });
    }
  } catch (err) {
    console.error('Erro câmbio:', err);
    res.status(500).json({ error: 'Erro ao buscar câmbio. Verifique sua conexão.' });
  }
});

function parsePreco(v) {
  if (!v) return 0;
  // Remove símbolo ¥ e espaços
  let s = String(v).replace(/[¥\s]/g, '');
  // Se tiver ponto E vírgula: formato europeu/BR (ex: 14.170,00) → remove ponto, troca vírgula por ponto
  if (s.includes(',') && s.includes('.')) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.includes(',') && !s.includes('.')) {
    // Só vírgula: pode ser decimal (1.200,50) ou milhar (1,200)
    // Se tiver mais de 3 dígitos após a vírgula, é separador de milhar
    const partes = s.split(',');
    if (partes[partes.length - 1].length !== 2 && partes[partes.length - 1].length !== 1) {
      s = s.replace(/,/g, '');
    } else {
      s = s.replace(/,/g, '.');
    }
  } else {
    // Remove vírgulas (separador de milhar estilo inglês: 14,170)
    s = s.replace(/,/g, '');
  }
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}

// ── Integração Notion ───────────────────────────────────────────────────────
app.get('/api/notion/clientes', async (req, res) => {
  let clientesMapeados = [];
  
  try {
    const response = await fetch(`https://api.notion.com/v1/databases/${NOTION_CLIENTS_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        sorts: [
          { timestamp: 'created_time', direction: 'descending' }
        ]
      })
    });

    if (response.ok) {
      const data = await response.json();
      
      clientesMapeados = (data.results || []).map(page => {
        const p = page.properties;
        
        const getTitle = (prop) => prop?.title?.map(t => t.plain_text).join('') || '';
        const getRichText = (prop) => prop?.rich_text?.map(t => t.plain_text).join('') || '';
        const getNumber = (prop) => prop?.number || 0;
        const getSelect = (prop) => prop?.select?.name || '';
        const getDateStart = (prop) => prop?.date?.start || '';
        const getDateEnd = (prop) => prop?.date?.end || '';
        const getFormulaNumber = (prop) => prop?.formula?.number || 0;
        const getFormulaString = (prop) => prop?.formula?.string || '';
        const getRollupNumber = (prop) => prop?.rollup?.number || 0;

        return {
          id: page.id,
          nome: getTitle(p['Nome do Cliente'] || p['Name'] || p['Nome']),
          status: getSelect(p['Status do Cliente'] || p['Status']),
          adultos: getNumber(p['Qtd Adultos']),
          criancas: getNumber(p['Qtd Crianças']),
          vooChegada: getRichText(p['Voo de Chegada']),
          vooPartida: getRichText(p['Voo de Partida']),
          vooChegadaNum: '',
          vooChegadaHora: '',
          vooPartidaNum: '',
          vooPartidaHora: '',
          dataInicio: getDateStart(p['Período da Viagem']),
          dataFim: getDateEnd(p['Período da Viagem']),
          hotel: getRichText(p['Hotel']),
          email: p['Email']?.email || '',
          viajantes: getRichText(p['Nome dos Viajantes'] || p['Viajantes']),
          valorTotal: getNumber(p['Valor Total']),
          totalPago: getRollupNumber(p['Total Pago']),
          saldoPagar: getFormulaNumber(p['Saldo a Pagar']),
          statusPagamento: getFormulaString(p['Status de pagamento'])
        };
      });

      // Parse voo fields into components
      clientesMapeados.forEach(c => {
        if (c.vooChegada && c.vooChegada.includes('|')) {
          const parts = c.vooChegada.split('|').map(s => s.trim());
          c.vooChegadaNum = parts[0] || '';
          c.vooChegadaHora = parts[1] || '';
        } else {
          c.vooChegadaNum = c.vooChegada || '';
          c.vooChegadaHora = '';
        }
        if (c.vooPartida && c.vooPartida.includes('|')) {
          const parts = c.vooPartida.split('|').map(s => s.trim());
          c.vooPartidaNum = parts[0] || '';
          c.vooPartidaHora = parts[1] || '';
        } else {
          c.vooPartidaNum = c.vooPartida || '';
          c.vooPartidaHora = '';
        }
      });
    } else {
      const errorData = await response.json().catch(() => ({}));
      console.error('Notion API response error (Handled gracefully):', errorData);
    }
  } catch (error) {
    console.error('Erro na conexão do Notion API (Mantendo clientes locais):', error.message);
  }

  // Filtrar apenas registros válidos
  const clientesValidos = clientesMapeados.filter(c => c.nome && c.nome.trim() !== '');

  // Sempre injetar o cliente de teste Lucas e Sofia localmente
  clientesValidos.push({
    id: 'mock-uuid-lucas-sofia',
    nome: 'Lucas e Sofia (Lua de Mel - 15 Dias)',
    status: 'Roteiro em Edição',
    adultos: 2,
    criancas: 0,
    vooChegada: 'JL048 | 15:30',
    vooPartida: 'JL047 | 19:00',
    vooChegadaNum: 'JL048',
    vooChegadaHora: '15:30',
    vooPartidaNum: 'JL047',
    vooPartidaHora: '19:00',
    dataInicio: '2026-10-10',
    dataFim: '2026-10-25',
    hotel: 'Hotel Gracery Shinjuku',
    email: 'lucas_sofia_test@gmail.com',
    viajantes: 'Lucas, Sofia',
    valorTotal: 450000,
    totalPago: 0,
    saldoPagar: 450000,
    statusPagamento: 'Pendente'
  });

  res.json(clientesValidos);
});

// ── ENDPOINTS UNIFICADOS DE CLIENTES (NOTION + SUPABASE LOCAL) ────────────────
// --- Sincronia do Perfil & Preferencias com o Notion (camada nova) ---
const cadastroEngine = require('./public/js/cadastro-engine.js');
async function _notionApi(method, pathUrl, body) {
  return fetch('https://api.notion.com/v1' + pathUrl, {
    method,
    headers: { 'Authorization': `Bearer ${NOTION_TOKEN}`, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
}
function _blocoTexto(b) {
  const t = b && b[b.type];
  if (t && Array.isArray(t.rich_text)) return t.rich_text.map(x => (x.plain_text || (x.text && x.text.content) || '')).join('');
  return '';
}
function planejarSyncPerfil(blocks, preferencias) {
  const built = cadastroEngine.construirPayloadNotion(null, preferencias || {});
  const TITULO = '⛩️ Perfil de Viagem & Preferências';
  const idx = (blocks || []).findIndex(b => b.type === 'heading_2' && _blocoTexto(b) === TITULO);
  const aDeletar = idx >= 0 ? blocks.slice(idx) : [];
  return { aDeletar, children: built.children };
}
async function sincronizarPerfilNotion(pageId, preferencias) {
  try {
    if (!pageId || !preferencias) return;
    const r = await _notionApi('GET', `/blocks/${pageId}/children?page_size=100`);
    if (!r.ok) return;
    const data = await r.json();
    const plano = planejarSyncPerfil(data.results || [], preferencias);
    for (const b of plano.aDeletar) { try { await _notionApi('DELETE', `/blocks/${b.id}`); } catch (e) {} }
    if (plano.children && plano.children.length) await _notionApi('PATCH', `/blocks/${pageId}/children`, { children: plano.children });
  } catch (e) { console.error('Falha ao sincronizar perfil no Notion:', e.message); }
}

app.post('/api/clientes', async (req, res) => {
  try {
    const { notionPayload, localPayload } = req.body;
    
    // 1. Criar no Notion
    const properties = {
      'Nome do Cliente': { title: [{ text: { content: notionPayload.nome || 'Novo Cliente' } }] }
    };
    if (notionPayload.status) properties['Status do Cliente'] = { select: { name: notionPayload.status } };
    if (notionPayload.adultos !== undefined) properties['Qtd Adultos'] = { number: parseInt(notionPayload.adultos) || 0 };
    if (notionPayload.criancas !== undefined) properties['Qtd Crianças'] = { number: parseInt(notionPayload.criancas) || 0 };
    const vooChegadaCombined = [notionPayload.vooChegadaNum, notionPayload.vooChegadaHora].filter(Boolean).join(' | ');
    const vooPartidaCombined = [notionPayload.vooPartidaNum, notionPayload.vooPartidaHora].filter(Boolean).join(' | ');
    if (vooChegadaCombined || notionPayload.vooChegada) properties['Voo de Chegada'] = { rich_text: [{ text: { content: vooChegadaCombined || notionPayload.vooChegada } }] };
    if (vooPartidaCombined || notionPayload.vooPartida) properties['Voo de Partida'] = { rich_text: [{ text: { content: vooPartidaCombined || notionPayload.vooPartida } }] };
    if (notionPayload.hotel) properties['Hotel'] = { rich_text: [{ text: { content: notionPayload.hotel } }] };
    if (notionPayload.email) {
      const firstEmail = notionPayload.email.split('\n')[0].trim();
      if (firstEmail) properties['Email'] = { email: firstEmail };
    }
    if (notionPayload.viajantes) properties['Nome dos Viajantes'] = { rich_text: [{ text: { content: notionPayload.viajantes } }] };
    if (notionPayload.dataInicio) {
      properties['Período da Viagem'] = { date: { start: notionPayload.dataInicio, end: notionPayload.dataFim || null } };
    }
    if (notionPayload.profissoes) properties['Profissão dos Viajantes'] = { rich_text: [{ text: { content: notionPayload.profissoes } }] };
    if (notionPayload.ocasiaoEspecial) properties['Ocasião Especial'] = { rich_text: [{ text: { content: notionPayload.ocasiaoEspecial } }] };
    if (notionPayload.necessidadesEspeciais) properties['Necessidades Especiais'] = { rich_text: [{ text: { content: notionPayload.necessidadesEspeciais } }] };
    if (notionPayload.observacoes) properties['Observações'] = { rich_text: [{ text: { content: notionPayload.observacoes } }] };

    const response = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        parent: { database_id: NOTION_CLIENTS_DB_ID },
        properties
      })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json(err);
    }
    const data = await response.json();
    const cliId = data.id;

    // 2. Criar localmente no Supabase
    if (localPayload) {
      localPayload.id = cliId; // Garante o ID correto gerado pelo Notion
      const { error: localErr } = await supabase.from('clientes_locais').upsert({ id: cliId, data: localPayload });
      if (localErr) throw localErr;
    }

    if (localPayload && localPayload.preferencias) { await sincronizarPerfilNotion(cliId, localPayload.preferencias); }

    res.json({ success: true, id: cliId });
  } catch (error) {
    console.error('Erro unificado ao criar cliente:', error);
    res.status(500).json({ error: error.message });
  }
});

app.patch('/api/clientes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { notionPayload, localPayload } = req.body;
    
    // 1. Atualizar no Notion
    const properties = {};
    if (notionPayload.nome) properties['Nome do Cliente'] = { title: [{ text: { content: notionPayload.nome } }] };
    if (notionPayload.status) properties['Status do Cliente'] = { select: { name: notionPayload.status } };
    if (notionPayload.adultos !== undefined) properties['Qtd Adultos'] = { number: parseInt(notionPayload.adultos) || 0 };
    if (notionPayload.criancas !== undefined) properties['Qtd Crianças'] = { number: parseInt(notionPayload.criancas) || 0 };
    if (notionPayload.email !== undefined) {
      if (notionPayload.email) {
        const firstEmail = notionPayload.email.split('\n')[0].trim();
        properties['Email'] = { email: firstEmail || null };
      } else {
        properties['Email'] = { email: null };
      }
    }
    if (notionPayload.viajantes !== undefined) properties['Nome dos Viajantes'] = { rich_text: notionPayload.viajantes ? [{ text: { content: notionPayload.viajantes } }] : [] };
    const vooChegadaCombined = [notionPayload.vooChegadaNum, notionPayload.vooChegadaHora].filter(Boolean).join(' | ');
    const vooPartidaCombined = [notionPayload.vooPartidaNum, notionPayload.vooPartidaHora].filter(Boolean).join(' | ');
    
    const finalVooChegada = vooChegadaCombined || notionPayload.vooChegada || '';
    if (notionPayload.vooChegada !== undefined || vooChegadaCombined) properties['Voo de Chegada'] = { rich_text: finalVooChegada ? [{ text: { content: finalVooChegada } }] : [] };
    
    const finalVooPartida = vooPartidaCombined || notionPayload.vooPartida || '';
    if (notionPayload.vooPartida !== undefined || vooPartidaCombined) properties['Voo de Partida'] = { rich_text: finalVooPartida ? [{ text: { content: finalVooPartida } }] : [] };
    
    if (notionPayload.hotel !== undefined) properties['Hotel'] = { rich_text: notionPayload.hotel ? [{ text: { content: notionPayload.hotel } }] : [] };
    if (notionPayload.profissoes !== undefined) properties['Profissão dos Viajantes'] = { rich_text: notionPayload.profissoes ? [{ text: { content: notionPayload.profissoes } }] : [] };
    if (notionPayload.ocasiaoEspecial !== undefined) properties['Ocasião Especial'] = { rich_text: notionPayload.ocasiaoEspecial ? [{ text: { content: notionPayload.ocasiaoEspecial } }] : [] };
    if (notionPayload.necessidadesEspeciais !== undefined) properties['Necessidades Especiais'] = { rich_text: notionPayload.necessidadesEspeciais ? [{ text: { content: notionPayload.necessidadesEspeciais } }] : [] };
    if (notionPayload.observacoes !== undefined) properties['Observações'] = { rich_text: notionPayload.observacoes ? [{ text: { content: notionPayload.observacoes } }] : [] };
    
    if (notionPayload.dataInicio !== undefined) {
      if (notionPayload.dataInicio) {
        properties['Período da Viagem'] = { date: { start: notionPayload.dataInicio, end: notionPayload.dataFim || null } };
      } else {
        properties['Período da Viagem'] = { date: null };
      }
    }

    const response = await fetch(`https://api.notion.com/v1/pages/${id}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ properties })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json(err);
    }

    // 2. Atualizar localmente no Supabase
    if (localPayload) {
      localPayload.id = id;
      const { error: localErr } = await supabase.from('clientes_locais').upsert({ id, data: localPayload });
      if (localErr) throw localErr;
    }

    if (localPayload && localPayload.preferencias) { await sincronizarPerfilNotion(id, localPayload.preferencias); }

    res.json({ success: true, id });
  } catch (error) {
    console.error('Erro unificado ao atualizar cliente:', error);
    res.status(500).json({ error: error.message });
  }
});

// Criar cliente no Notion
app.post('/api/notion/clientes', async (req, res) => {
  try {
    const { nome, status, adultos, criancas, vooChegada, vooPartida, vooChegadaNum, vooChegadaHora, vooPartidaNum, vooPartidaHora, dataInicio, dataFim, hotel, email, viajantes } = req.body;
    
    const properties = {
      'Nome do Cliente': { title: [{ text: { content: nome || 'Novo Cliente' } }] }
    };
    if (status) properties['Status do Cliente'] = { select: { name: status } };
    if (adultos !== undefined) properties['Qtd Adultos'] = { number: parseInt(adultos) || 0 };
    if (criancas !== undefined) properties['Qtd Crianças'] = { number: parseInt(criancas) || 0 };
    const vooChegadaCombined = [vooChegadaNum, vooChegadaHora].filter(Boolean).join(' | ');
    const vooPartidaCombined = [vooPartidaNum, vooPartidaHora].filter(Boolean).join(' | ');
    if (vooChegadaCombined || vooChegada) properties['Voo de Chegada'] = { rich_text: [{ text: { content: vooChegadaCombined || vooChegada } }] };
    if (vooPartidaCombined || vooPartida) properties['Voo de Partida'] = { rich_text: [{ text: { content: vooPartidaCombined || vooPartida } }] };
    if (hotel) properties['Hotel'] = { rich_text: [{ text: { content: hotel } }] };
    if (email) {
      const firstEmail = email.split('\n')[0].trim();
      if (firstEmail) properties['Email'] = { email: firstEmail };
    }
    if (viajantes) properties['Nome dos Viajantes'] = { rich_text: [{ text: { content: viajantes } }] };
    
    if (dataInicio) {
      properties['Período da Viagem'] = { date: { start: dataInicio, end: dataFim || null } };
    }

    const response = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        parent: { database_id: NOTION_CLIENTS_DB_ID },
        properties
      })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json(err);
    }
    const data = await response.json();
    res.json({ success: true, id: data.id });
  } catch (error) {
    console.error('Erro ao criar no Notion:', error);
    res.status(500).json({ error: error.message });
  }
});

// Atualizar cliente no Notion
app.patch('/api/notion/clientes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, status, adultos, criancas, vooChegada, vooPartida, vooChegadaNum, vooChegadaHora, vooPartidaNum, vooPartidaHora, dataInicio, dataFim, hotel, email, viajantes } = req.body;
    
    const properties = {};
    if (nome) properties['Nome do Cliente'] = { title: [{ text: { content: nome } }] };
    if (status) properties['Status do Cliente'] = { select: { name: status } };
    if (adultos !== undefined) properties['Qtd Adultos'] = { number: parseInt(adultos) || 0 };
    if (criancas !== undefined) properties['Qtd Crianças'] = { number: parseInt(criancas) || 0 };
    if (email !== undefined) {
      if (email) {
        const firstEmail = email.split('\n')[0].trim();
        properties['Email'] = { email: firstEmail || null };
      } else {
        properties['Email'] = { email: null };
      }
    }
    if (viajantes !== undefined) properties['Nome dos Viajantes'] = { rich_text: viajantes ? [{ text: { content: viajantes } }] : [] };
    const vooChegadaCombined = [vooChegadaNum, vooChegadaHora].filter(Boolean).join(' | ');
    const vooPartidaCombined = [vooPartidaNum, vooPartidaHora].filter(Boolean).join(' | ');
    
    const finalVooChegada = vooChegadaCombined || vooChegada || '';
    if (vooChegada !== undefined || vooChegadaCombined) properties['Voo de Chegada'] = { rich_text: finalVooChegada ? [{ text: { content: finalVooChegada } }] : [] };
    
    const finalVooPartida = vooPartidaCombined || vooPartida || '';
    if (vooPartida !== undefined || vooPartidaCombined) properties['Voo de Partida'] = { rich_text: finalVooPartida ? [{ text: { content: finalVooPartida } }] : [] };
    
    if (hotel !== undefined) properties['Hotel'] = { rich_text: hotel ? [{ text: { content: hotel } }] : [] };
    
    if (dataInicio !== undefined) {
      if (dataInicio) {
        properties['Período da Viagem'] = { date: { start: dataInicio, end: dataFim || null } };
      } else {
        properties['Período da Viagem'] = { date: null };
      }
    }

    const response = await fetch(`https://api.notion.com/v1/pages/${id}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ properties })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json(err);
    }
    const data = await response.json();
    res.json({ success: true, id: data.id });
  } catch (error) {
    console.error('Erro ao atualizar no Notion:', error);
    res.status(500).json({ error: error.message });
  }
});

// ── APIs DO CALENDÁRIO & COLABORADORES NOTION ────────────────────────────────
app.get('/api/notion/colaboradores', async (req, res) => {
  try {
    const DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';
    const response = await fetch(`https://api.notion.com/v1/databases/${DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      }
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Erro ao consultar banco de colaboradores: ${errText}`);
    }
    const data = await response.json();
    const colaboradores = (data.results || []).map(item => {
      const nameProp = item.properties.Name || item.properties.Nome;
      const name = nameProp?.title?.[0]?.plain_text || 'Sem Nome';
      const email = item.properties.Email?.email || '';
      const whatsapp = item.properties.Whatsapp?.phone_number || '';
      const rate = item.properties.Rate?.number || 35000;
      const locais = (item.properties.Locais?.multi_select || []).map(x => x.name);
      const residencia = (item.properties.Residência?.multi_select || []).map(x => x.name);
      return {
        id: item.id,
        name: name,
        email: email,
        whatsapp: whatsapp,
        rate: rate,
        locais: locais,
        residencia: residencia,
        avatar: null
      };
    }).sort((a, b) => a.name.localeCompare(b.name));
    res.json(colaboradores);
  } catch (error) {
    console.error('Erro ao buscar colaboradores no Notion:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/calendario/eventos', async (req, res) => {
  try {
    const { data_inicio, data_fim, cliente_id } = req.query;
    
    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    // Aplicar filtros se fornecidos
    if (data_inicio) {
      eventos = eventos.filter(ev => ev.dataServico >= data_inicio);
    }
    if (data_fim) {
      eventos = eventos.filter(ev => ev.dataServico <= data_fim);
    }
    if (cliente_id) {
      eventos = eventos.filter(ev => ev.clienteId === cliente_id || (ev.clientes && ev.clientes.includes(cliente_id)));
    }

    res.json(eventos);
  } catch (error) {
    console.error('Erro ao buscar eventos do calendário local:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/calendario/eventos', async (req, res) => {
  try {
    const {
      titulo, tipoServico, dataServico, clienteId, cidade, valorDiaria, assigneeIds, observacoes, richData,
      lancarFinanceiro, contaFinanceiraId, valorCusto
    } = req.body;

    if (!titulo || !tipoServico || !dataServico) {
      return res.status(400).json({ error: 'Campos obrigatórios: titulo, tipoServico e dataServico.' });
    }

    const NOTION_AGENDA_DB_ID = process.env.NOTION_AGENDA_DB_ID;

    // 1. Obter nome do cliente no Notion
    let clienteNome = '';
    if (NOTION_TOKEN && clienteId && clienteId !== 'cliente_desconhecido') {
      try {
        const response = await fetch(`https://api.notion.com/v1/pages/${clienteId}`, {
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28'
          }
        });
        if (response.ok) {
          const pageData = await response.json();
          const p = pageData.properties;
          const nameProp = p?.['Nome do Cliente'] || p?.['Name'] || p?.['Nome'];
          clienteNome = nameProp?.title?.[0]?.plain_text || '';
        }
      } catch (e) {
        console.error('Erro ao buscar nome do cliente no Notion para inserção:', e);
      }
    }

    // 2. Mapear colaboradores designados
    let assignee = [];
    let colaboradoresMap = {};
    if (NOTION_TOKEN && assigneeIds && assigneeIds.length > 0) {
      try {
        const DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';
        const response = await fetch(`https://api.notion.com/v1/databases/${DB_ID}/query`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          }
        });
        if (response.ok) {
          const data = await response.json();
          (data.results || []).forEach(item => {
            const p = item.properties;
            const nameProp = p.Name || p.Nome;
            colaboradoresMap[item.id] = nameProp?.title?.[0]?.plain_text || 'Sem Nome';
          });
          assignee = assigneeIds.map(uid => ({
            id: uid,
            name: colaboradoresMap[uid] || uid
          }));
        }
      } catch (e) {
        console.error('Erro ao mapear colaboradores no Notion:', e);
      }
    }

    // 3. Montar descrição rica/observações para o Notion
    let richTextObs = '';
    if (observacoes) richTextObs += `${observacoes}\n\n`;

    if (tipoServico === 'Transporte' && richData) {
      richTextObs += `--- DETALHES DO TRANSPORTE ---\n`;
      richTextObs += `Tipo: ${richData.tipoTransporte || '-'}\n`;
      richTextObs += `Rota: ${richData.origem || '-'} ➔ ${richData.destino || '-'}\n`;
      richTextObs += `Horário: ${richData.horario || '-'}\n`;
      if (richData.linha) richTextObs += `Linha: ${richData.linha}\n`;
      if (richData.categoria) richTextObs += `Assento/Categoria: ${richData.categoria}\n`;
      if (richData.tempo) richTextObs += `Tempo/Duração: ${richData.tempo}\n`;
      if (richData.adultos) richTextObs += `Passageiros: ${richData.adultos} Adultos\n`;
      richTextObs += `Comprado por Heian: ${richData.compradoHeian ? 'Sim' : 'Não'}\n`;
    } else if (tipoServico === 'Experiência' && richData) {
      richTextObs += `--- DETALHES DA EXPERIÊNCIA ---\n`;
      richTextObs += `Atração: ${richData.nomeExp || titulo}\n`;
      richTextObs += `Horário Entrada: ${richData.horaPartida || '-'}\n`;
      if (richData.adultos) richTextObs += `Passageiros: ${richData.adultos} Adultos\n`;
      if (richData.localEncontro) richTextObs += `Ponto de Encontro: ${richData.localEncontro}\n`;
      richTextObs += `Comprado por Heian: ${richData.compradoHeian ? 'Sim' : 'Não'}\n`;
      if (richData.observacoes) richTextObs += `Notas: ${richData.observacoes}\n`;
    } else if (tipoServico === 'Roteiro' && richData) {
      richTextObs += `--- DETALHES DO ROTEIRO ---\n`;
      if (richData.horaEncontro) richTextObs += `Hora de Encontro: ${richData.horaEncontro}\n`;
      if (richData.localEncontro) richTextObs += `Local de Encontro: ${richData.localEncontro}\n`;
      if (richData.duracaoTour) richTextObs += `Duração: ${richData.duracaoTour}\n`;
    }

    // 4. Cadastrar no Notion se configurado
    let notionPageId = null;
    if (NOTION_TOKEN && NOTION_AGENDA_DB_ID) {
      try {
        const properties = {
          'Nome': {
            title: [{ text: { content: titulo } }]
          },
          'Data do Tour': {
            date: { start: dataServico }
          }
        };

        if (clienteId && clienteId !== 'cliente_desconhecido') {
          properties['🎀 Clientes'] = {
            relation: [{ id: clienteId }]
          };
        }

        if (cidade) {
          properties['Cidade'] = {
            select: { name: cidade }
          };
        }

        if (tipoServico === 'Roteiro' && typeof valorDiaria === 'number') {
          properties['Valor diária do Guia'] = {
            number: valorDiaria
          };
        }

        if (assigneeIds && assigneeIds.length > 0) {
          properties['Responsável'] = {
            relation: assigneeIds.map(uid => ({ id: uid }))
          };
        }

        if (richTextObs) {
          const cleanText = richTextObs.substring(0, 2000);
          properties['Observações'] = {
            rich_text: [{ text: { content: cleanText } }]
          };
        }

        const response = await fetch('https://api.notion.com/v1/pages', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            parent: { database_id: NOTION_AGENDA_DB_ID },
            properties
          })
        });

        if (response.ok) {
          const pageData = await response.json();
          notionPageId = pageData.id;
          console.log(`[Nova OS] Criada com sucesso no Notion: ${notionPageId}`);
        } else {
          const errText = await response.text();
          console.error('Erro na API do Notion ao cadastrar evento:', errText);
        }
      } catch (e) {
        console.error('Erro na chamada da API do Notion ao cadastrar evento:', e);
      }
    }

    // 4.1 Lançar despesa na contabilidade (Notion Saídas) se solicitado
    let notionSaidaPageId = null;
    if (lancarFinanceiro && valorCusto && Number(valorCusto) > 0 && NOTION_TOKEN) {
      const NOTION_SAIDAS_DB_ID = process.env.NOTION_SAIDAS_DB_ID;
      if (NOTION_SAIDAS_DB_ID) {
        try {
          const descricaoSaida = `Custo Emissão: ${titulo}`;
          const propertiesSaida = {
            'Descrição': { title: [{ text: { content: descricaoSaida } }] },
            'Valor (JPY)': { number: Number(valorCusto) },
            'Data de pagamento': { date: { start: dataServico || new Date().toISOString().substring(0, 10) } }
          };

          if (contaFinanceiraId) {
            propertiesSaida['💳 Contas'] = { relation: [{ id: contaFinanceiraId }] };
          }

          if (clienteId && clienteId !== 'cliente_desconhecido' && clienteId !== 'Sem Nome' && clienteId !== 'Geral') {
            propertiesSaida['🎀 Clientes'] = { relation: [{ id: clienteId }] };
          }

          if (tipoServico === 'Transporte') {
            propertiesSaida['Categoria'] = { select: { name: 'Transporte' } };
            propertiesSaida['Tipo de serviço'] = { select: { name: 'transporte' } };
          } else if (tipoServico === 'Experiência') {
            propertiesSaida['Categoria'] = { select: { name: 'Experiência' } };
            propertiesSaida['Tipo de serviço'] = { select: { name: 'experiência' } };
          }

          console.log(`[Nova Saída] Criando página de custo no Notion para ${tipoServico}...`);
          const responseSaida = await fetch('https://api.notion.com/v1/pages', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${NOTION_TOKEN}`,
              'Notion-Version': '2022-06-28',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              parent: { database_id: NOTION_SAIDAS_DB_ID },
              properties: propertiesSaida
            })
          });

          if (responseSaida.ok) {
            const pageDataSaida = await responseSaida.json();
            notionSaidaPageId = pageDataSaida.id;
            console.log(`[Nova Saída] Criada com sucesso no Notion: ${notionSaidaPageId}`);
          } else {
            const errText = await responseSaida.text();
            console.error('Erro na API do Notion ao cadastrar saída:', errText);
          }
        } catch (e) {
          console.error('Erro na chamada da API do Notion ao cadastrar saída:', e);
        }
      }
    }

    // 5. Salvar na base local do Supabase
    const newEventId = notionPageId || `cal_manual_${Date.now()}`;
    const valorDiariaColab = {};
    const pagoColab = {};
    
    if (assigneeIds && assigneeIds.length > 0) {
      assigneeIds.forEach(uid => {
        valorDiariaColab[uid] = tipoServico === 'Roteiro' ? (valorDiaria || 35000) : 0;
        pagoColab[uid] = false;
      });
    }

    const novoEvento = {
      id: newEventId,
      titulo,
      tipoServico,
      dataServico,
      clienteId,
      clientes: [clienteId],
      clienteNome,
      cidade,
      assignee,
      valorDiaria: tipoServico === 'Roteiro' ? (valorDiaria || null) : null,
      pago: false,
      valorDiariaColab,
      pagoColab,
      horaEncontro: tipoServico === 'Roteiro' ? (richData?.horaEncontro || null) : null,
      localEncontro: tipoServico === 'Roteiro' ? (richData?.localEncontro || null) : (tipoServico === 'Experiência' ? (richData?.localEncontro || null) : null),
      duracaoTour: tipoServico === 'Roteiro' ? (richData?.duracaoTour || null) : null,
      rotas: [],
      atracoes: [],
      textos: observacoes ? [observacoes] : [],
      transportInfo: tipoServico === 'Transporte' ? {
        origem: richData?.origem || '',
        destino: richData?.destino || '',
        horario: richData?.horario || '',
        tipoTransporte: richData?.tipoTransporte || '',
        linha: richData?.linha || '',
        categoria: richData?.categoria || '',
        tempo: richData?.tempo || '',
        adultos: richData?.adultos ? Number(richData.adultos) : null,
        compradoHeian: richData?.compradoHeian !== false,
        observacoes: observacoes || '',
        custoValor: valorCusto ? Number(valorCusto) : null,
        lancarFinanceiro: !!lancarFinanceiro,
        contaFinanceiraId: contaFinanceiraId || null,
        notionSaidaPageId: notionSaidaPageId || null
      } : null,
      expInfo: tipoServico === 'Experiência' ? {
        nomeExp: richData?.nomeExp || titulo,
        horaPartida: richData?.horaPartida || '',
        adultos: richData?.adultos ? Number(richData.adultos) : null,
        compradoHeian: richData?.compradoHeian !== false,
        observacoes: observacoes || '',
        custoValor: valorCusto ? Number(valorCusto) : null,
        lancarFinanceiro: !!lancarFinanceiro,
        contaFinanceiraId: contaFinanceiraId || null,
        notionSaidaPageId: notionSaidaPageId || null
      } : null
    };

    // Obter dados locais do Supabase
    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    eventos.push(novoEvento);

    const { error: updateErr } = await supabase.from('config').update({ data: eventos }).eq('id', 'calendario_eventos');
    if (updateErr) {
      throw new Error(`Erro ao atualizar Supabase: ${updateErr.message}`);
    }

    console.log(`[Nova OS] Evento adicionado localmente: ${newEventId}`);
    res.json({ success: true, event: novoEvento });

    // Disparar envio de e-mails em background
    processarNotificacoesEmail().catch(err => console.error('[Email Trigger] Erro ao processar e-mails pós-cadastro:', err));

  } catch (error) {
    console.error('Erro ao cadastrar evento manualmente:', error);
    res.status(500).json({ error: error.message });
  }
});

app.patch('/api/calendario/eventos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { assigneeIds, dataServico, valorDiaria, pago, colaboradorId, valorDiariaColab, pagoColab } = req.body;

    // Buscar colaboradores do Notion (somente leitura) para preencher nome/avatar
    let collaborators = [];
    if (NOTION_TOKEN) {
      try {
        const DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';
        const response = await fetch(`https://api.notion.com/v1/databases/${DB_ID}/query`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          }
        });
        if (response.ok) {
          const data = await response.json();
          collaborators = (data.results || []).map(item => {
            const nameProp = item.properties.Name || item.properties.Nome;
            const rateProp = item.properties.Rate;
            return {
              id: item.id,
              name: nameProp?.title?.[0]?.plain_text || 'Sem Nome',
              avatar: null,
              rate: rateProp && typeof rateProp.number === 'number' ? rateProp.number : 35000
            };
          });
        }
      } catch (e) {
        console.error('Erro ao buscar colaboradores no Notion para o PATCH:', e);
      }
    }

    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    let updated = false;
    eventos = eventos.map(ev => {
      if (ev.id === id) {
        updated = true;
        const newEv = { ...ev };

        // Inicializar objetos individuais caso não existam
        if (!newEv.valorDiariaColab) newEv.valorDiariaColab = {};
        if (!newEv.pagoColab) newEv.pagoColab = {};

        // Caso 1: Atualização individualizada de faturamento vinda do dashboard
        if (colaboradorId) {
          if (valorDiariaColab !== undefined) {
            newEv.valorDiariaColab[colaboradorId] = valorDiariaColab === null ? null : Number(valorDiariaColab);
          }
          if (pagoColab !== undefined) {
            newEv.pagoColab[colaboradorId] = !!pagoColab;
          }

          // Compatibilidade global: Se for o colaborador principal (primeiro da lista), atualiza o campo global
          const primaryId = newEv.assignee && newEv.assignee.length > 0 ? newEv.assignee[0].id : null;
          if (colaboradorId === primaryId || !primaryId) {
            if (valorDiariaColab !== undefined) {
              newEv.valorDiaria = valorDiariaColab === null ? null : Number(valorDiariaColab);
            }
            if (pagoColab !== undefined) {
              newEv.pago = !!pagoColab;
            }
          }
        }

        // Caso 2: Atualização de atribuição (designação de guias) vinda do modal ou do card
        if (assigneeIds !== undefined) {
          newEv.assignee = assigneeIds.map(userId => {
            const found = collaborators.find(c => c.id === userId);
            return found ? { id: found.id, name: found.name, avatar: found.avatar } : { id: userId, name: userId };
          });

          // Limpar diárias de colaboradores desmarcados
          Object.keys(newEv.valorDiariaColab).forEach(uid => {
            if (!assigneeIds.includes(uid)) {
              delete newEv.valorDiariaColab[uid];
              delete newEv.pagoColab[uid];
            }
          });

          // Inicializar diárias de novos colaboradores marcados
          assigneeIds.forEach(uid => {
            if (newEv.valorDiariaColab[uid] === undefined || newEv.valorDiariaColab[uid] === null) {
              const isRoteiro = newEv.tipoServico && newEv.tipoServico.toLowerCase() === 'roteiro';
              const colFound = collaborators.find(c => c.id === uid);
              const defaultRate = colFound ? colFound.rate : 35000;
              
              // Se já houver um valorDiaria global definido no evento e for maior que zero, usa ele; senão, usa a taxa do guia
              if (typeof valorDiaria === 'number' && valorDiaria > 0) {
                newEv.valorDiariaColab[uid] = valorDiaria;
              } else if (typeof newEv.valorDiaria === 'number' && newEv.valorDiaria > 0) {
                newEv.valorDiariaColab[uid] = newEv.valorDiaria;
              } else {
                newEv.valorDiariaColab[uid] = isRoteiro ? defaultRate : 0;
              }
            }
            if (newEv.pagoColab[uid] === undefined) {
              newEv.pagoColab[uid] = pago !== undefined ? !!pago : (newEv.pago || false);
            }
          });

          // Compatibilidade global: Sincroniza campos globais com o primeiro colaborador
          if (assigneeIds.length > 0) {
            const primaryId = assigneeIds[0];
            newEv.valorDiaria = newEv.valorDiariaColab[primaryId];
            newEv.pago = newEv.pagoColab[primaryId];
          } else {
            newEv.valorDiaria = null;
            newEv.pago = false;
          }
        }

        // Limpar histórico de envios de e-mails para colaboradores removidos
        if (assigneeIds !== undefined) {
          if (newEv.emails_cadastro_enviados) {
            newEv.emails_cadastro_enviados = newEv.emails_cadastro_enviados.filter(uid => assigneeIds.includes(uid));
          }
          if (newEv.emails_24h_enviados) {
            newEv.emails_24h_enviados = newEv.emails_24h_enviados.filter(uid => assigneeIds.includes(uid));
          }
          if (newEv.emails_1h_enviados) {
            newEv.emails_1h_enviados = newEv.emails_1h_enviados.filter(uid => assigneeIds.includes(uid));
          }
        }

        // Outros campos globais
        if (dataServico !== undefined) {
          if (dataServico !== newEv.dataServico) {
            newEv.dataServico = dataServico;
            // Se a data mudou, resetar envio dos lembretes de 24h e 1h para disparar novamente de acordo com a nova data
            newEv.emails_24h_enviados = [];
            newEv.emails_1h_enviados = [];
          }
        }
        if (valorDiaria !== undefined && assigneeIds === undefined && !colaboradorId) {
          newEv.valorDiaria = valorDiaria === null ? null : Number(valorDiaria);
          // Atualiza também para o primeiro colaborador se houver
          if (newEv.assignee && newEv.assignee.length > 0) {
            newEv.valorDiariaColab[newEv.assignee[0].id] = newEv.valorDiaria;
          }
        }
        if (pago !== undefined && assigneeIds === undefined && !colaboradorId) {
          newEv.pago = !!pago;
          // Atualiza também para o primeiro colaborador se houver
          if (newEv.assignee && newEv.assignee.length > 0) {
            newEv.pagoColab[newEv.assignee[0].id] = newEv.pago;
          }
        }

        return newEv;
      }
      return ev;
    });

    if (updated) {
      const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: eventos });
      if (upsertErr) throw upsertErr;

      // Espelhar alteração na Agenda do Notion (se for um ID válido e o Token/DB existirem)
      const NOTION_AGENDA_DB_ID = process.env.NOTION_AGENDA_DB_ID;
      if (NOTION_TOKEN && NOTION_AGENDA_DB_ID && id && !id.startsWith('cal_')) {
        try {
          const properties = {};
          const evUpdated = eventos.find(e => e.id === id);
          if (evUpdated) {
            if (assigneeIds !== undefined) {
              properties['Responsável'] = {
                relation: assigneeIds.map(uid => ({ id: uid }))
              };
            }
            if (dataServico !== undefined) {
              properties['Data do Tour'] = dataServico ? { date: { start: dataServico } } : null;
            }
            
            // Gravar diária global no Notion (que representa o guia principal do card)
            if (evUpdated.valorDiaria !== undefined) {
              properties['Valor diária do Guia'] = evUpdated.valorDiaria === null ? null : { number: Number(evUpdated.valorDiaria) };
            }
            if (evUpdated.pago !== undefined) {
              properties['Pagamento concluído '] = {
                status: { name: evUpdated.pago ? "Concluído" : "Não iniciado" }
              };
            }
            
            console.log(`Espelhando alteração do evento ${id} na Agenda do Notion...`);
            const response = await fetch(`https://api.notion.com/v1/pages/${id}`, {
              method: 'PATCH',
              headers: {
                'Authorization': `Bearer ${NOTION_TOKEN}`,
                'Notion-Version': '2022-06-28',
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ properties })
            });
            if (!response.ok) {
              const errText = await response.text();
              console.error('Erro na resposta do PATCH no Notion:', errText);
            }
          }
        } catch (notionErr) {
          console.error('Erro ao espelhar alteração na Agenda do Notion:', notionErr);
        }
      }

      res.json({ success: true, id });

      // Disparar envio de e-mails em background para novas atribuições ou alterações
      processarNotificacoesEmail().catch(err => console.error('[Email Trigger] Erro ao processar e-mails pós-PATCH:', err));
    } else {
      res.status(404).json({ error: 'Evento não encontrado' });
    }
  } catch (error) {
    console.error('Erro ao atualizar evento do calendário local:', error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/calendario/eventos/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    const eventIndex = eventos.findIndex(ev => ev.id === id);
    if (eventIndex !== -1) {
      // 1. Arquivar card correspondente na Agenda do Notion (se for um ID real do Notion e as chaves existirem)
      const NOTION_AGENDA_DB_ID = process.env.NOTION_AGENDA_DB_ID;
      if (NOTION_TOKEN && NOTION_AGENDA_DB_ID && id && !id.startsWith('cal_')) {
        try {
          console.log(`Arquivando evento ${id} na Agenda do Notion via DELETE...`);
          const response = await fetch(`https://api.notion.com/v1/pages/${id}`, {
            method: 'PATCH',
            headers: {
              'Authorization': `Bearer ${NOTION_TOKEN}`,
              'Notion-Version': '2022-06-28',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ archived: true })
          });
          if (!response.ok) {
            const errText = await response.text();
            console.error('Erro ao arquivar card no Notion:', errText);
          }
        } catch (notionErr) {
          console.error('Erro ao arquivar card na Agenda do Notion no DELETE:', notionErr);
        }
      }

      // 2. Remover do array local
      eventos.splice(eventIndex, 1);

      // 3. Gravar a lista atualizada de volta no Supabase
      const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: eventos });
      if (upsertErr) throw upsertErr;

      res.json({ success: true, id });
    } else {
      res.status(404).json({ error: 'Evento não encontrado no banco local.' });
    }
  } catch (error) {
    console.error('Erro ao excluir evento do calendário local:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/calendario/sincronizar-do-notion', async (req, res) => {
  try {
    const NOTION_AGENDA_DB_ID = process.env.NOTION_AGENDA_DB_ID;
    const NOTION_COLABORADORES_DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';

    if (!NOTION_TOKEN || !NOTION_AGENDA_DB_ID) {
      return res.status(400).json({ error: 'Configuração do Notion incompleta no .env.' });
    }

    // Função genérica para buscar todas as páginas de uma base do Notion (paginação)
    const queryAllNotion = async (dbId) => {
      let results = [];
      let hasMore = true;
      let startCursor = undefined;

      while (hasMore) {
        const body = {};
        if (startCursor) {
          body.start_cursor = startCursor;
        }

        const response = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(body)
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Erro ao consultar base ${dbId} do Notion: ${errText}`);
        }

        const data = await response.json();
        results = results.concat(data.results || []);
        hasMore = data.has_more;
        startCursor = data.next_cursor;
      }

      return { results };
    };

    // 1. Buscar todos os colaboradores do Notion para mapear os IDs para nomes
    const colaboradoresData = await queryAllNotion(NOTION_COLABORADORES_DB_ID);
    const colaboradoresMap = {};
    (colaboradoresData.results || []).forEach(item => {
      const p = item.properties;
      const nameProp = p.Name || p.Nome;
      const nome = nameProp?.title?.[0]?.plain_text || 'Sem Nome';
      colaboradoresMap[item.id] = nome;
    });

    // 1b. Buscar todos os clientes do Notion para mapear os IDs para nomes
    const clientesMap = {};
    if (NOTION_CLIENTS_DB_ID) {
      const clientesData = await queryAllNotion(NOTION_CLIENTS_DB_ID);
      (clientesData.results || []).forEach(item => {
        const p = item.properties;
        const nameProp = p['Nome do Cliente'] || p['Name'] || p['Nome'];
        const nome = nameProp?.title?.[0]?.plain_text || '';
        if (nome) clientesMap[item.id] = nome;
      });
      console.log(`[Sync Agenda] Mapeados ${Object.keys(clientesMap).length} clientes do Notion.`);
    }

    // 2. Buscar todos os eventos da Agenda do Notion (ativos/não arquivados)
    const agendaData = await queryAllNotion(NOTION_AGENDA_DB_ID);
    const notionEvents = agendaData.results || [];

    // 3. Buscar os eventos locais do calendário no Supabase
    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventosLocais = [];
    if (calCfg && calCfg.data) {
      eventosLocais = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    // Criar um conjunto de IDs ativos no Notion para saber quais deletar localmente
    const notionActiveIds = new Set(notionEvents.map(e => e.id));

    // Filtrar eventos locais: manter os locais temporários (cal_...) e os que continuam ativos no Notion
    let novosEventosLocais = eventosLocais.filter(ev => {
      if (!ev.id) return false;
      if (ev.id.startsWith('cal_')) return true; // Mantém eventos criados apenas localmente
      return notionActiveIds.has(ev.id); // Mantém se ainda estiver no Notion
    });

    // 4. Mapear e atualizar/inserir eventos vindos do Notion
    notionEvents.forEach(item => {
      const p = item.properties;
      const id = item.id;
      
      const titulo = p['Nome']?.title?.map(t => t.plain_text).join('') || 'Serviço sem nome';
      const dataServico = p['Data do Tour']?.date?.start || '';
      
      const clientesRel = p['🎀 Clientes']?.relation || [];
      const clienteId = clientesRel[0]?.id || 'cliente_desconhecido';
      const clienteNome = clientesMap[clienteId] || '';

      const cidade = p['Cidade']?.select?.name || '';
      const valorDiariaNotion = p['Valor diária do Guia']?.number || 0;

      // Mapear responsáveis (colaboradores)
      const responsaveisRel = p['Responsável']?.relation || [];
      const assignee = responsaveisRel.map(r => ({
        id: r.id,
        name: colaboradoresMap[r.id] || 'Desconhecido'
      }));

      // Determinar o tipo de serviço baseado no título ou observações
      let tipoServico = 'Roteiro';
      const tLower = titulo.toLowerCase();
      if (tLower.includes('transporte') || tLower.includes('transfer') || tLower.includes('carro')) {
        tipoServico = 'Transporte';
      } else if (tLower.includes('experiencia') || tLower.includes('experiência')) {
        tipoServico = 'Experiência';
      }

      // Procurar se já existe o evento localmente
      let evLocal = novosEventosLocais.find(ev => ev.id === id);

      if (evLocal) {
        // Se a data do serviço mudou no Notion, resetar os históricos de lembretes
        if (evLocal.dataServico !== dataServico) {
          evLocal.emails_24h_enviados = [];
          evLocal.emails_1h_enviados = [];
        }

        // Limpar do histórico de envios os colaboradores que foram removidos
        const activeIds = assignee.map(a => a.id);
        if (evLocal.emails_cadastro_enviados) {
          evLocal.emails_cadastro_enviados = evLocal.emails_cadastro_enviados.filter(uid => activeIds.includes(uid));
        }
        if (evLocal.emails_24h_enviados) {
          evLocal.emails_24h_enviados = evLocal.emails_24h_enviados.filter(uid => activeIds.includes(uid));
        }
        if (evLocal.emails_1h_enviados) {
          evLocal.emails_1h_enviados = evLocal.emails_1h_enviados.filter(uid => activeIds.includes(uid));
        }

        // Atualiza campos
        evLocal.titulo = titulo;
        evLocal.dataServico = dataServico;
        evLocal.clienteId = clienteId;
        evLocal.clientes = [clienteId];
        evLocal.clienteNome = clienteNome;
        evLocal.cidade = cidade;
        evLocal.assignee = assignee;
        
        // Atualizar diária local se houver guias
        if (!evLocal.valorDiariaColab) evLocal.valorDiariaColab = {};
        if (!evLocal.pagoColab) evLocal.pagoColab = {};

        assignee.forEach(a => {
          if (evLocal.valorDiariaColab[a.id] === undefined) {
            evLocal.valorDiariaColab[a.id] = valorDiariaNotion;
          }
        });
      } else {
        // Criar novo evento vindo do Notion
        const valorDiariaColab = {};
        const pagoColab = {};
        assignee.forEach(a => {
          valorDiariaColab[a.id] = valorDiariaNotion;
          pagoColab[a.id] = false;
        });

        novosEventosLocais.push({
          id,
          titulo,
          dataServico,
          clienteId,
          clientes: [clienteId],
          clienteNome,
          tipoServico,
          cidade,
          assignee,
          valorDiariaColab,
          pagoColab,
          compradoHeian: true,
          observacoes: p['Observações']?.rich_text?.map(t => t.plain_text).join('') || ''
        });
      }
    });

    // 5. Salvar de volta no Supabase
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: novosEventosLocais });
    if (upsertErr) throw upsertErr;

    res.json({ success: true, count: notionEvents.length });

    // Disparar envio de e-mails em background para novas designações sincronizadas do Notion
    processarNotificacoesEmail().catch(err => console.error('[Email Trigger] Erro ao processar e-mails pós-sincronismo Notion:', err));
  } catch (error) {
    console.error('Erro ao sincronizar do Notion para o calendário local:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/calendario/sincronizar-roteiro', async (req, res) => {
  try {
    const { roteiroNome } = req.body;
    if (!roteiroNome) return res.status(400).json({ error: 'Parâmetro roteiroNome é obrigatório' });

    // Buscar roteiro no Supabase (aceita ID imutável ou nome)
    const linhaRot = await acharRoteiroPorChaveOuNome(roteiroNome);
    if (!linhaRot || !linhaRot.data) {
      return res.status(404).json({ error: `Roteiro "${roteiroNome}" não encontrado no banco local.` });
    }

    const roteiro = linhaRot.data;
    
    // Obter clienteId (relaxado: sem obrigação de estar no Notion)
    const clienteId = roteiro.notionClienteId || roteiro.cliente?.notionClienteId || roteiro.cliente?.nome || roteiro.nome || 'cliente_desconhecido';
    const clienteNome = roteiro.cliente?.nome || roteiro.nome || 'Cliente';

    const dataInicio = roteiro.cliente?.dataInicio;
    if (!dataInicio) {
      return res.status(400).json({ error: 'Defina uma data de início no roteiro antes de sincronizar com o calendário.' });
    }

    // Função auxiliar para somar dias a data string YYYY-MM-DD
    const somarDias = (dataStr, diasParaSomar) => {
      const [year, month, day] = dataStr.split('-').map(Number);
      const date = new Date(year, month - 1, day);
      date.setDate(date.getDate() + diasParaSomar);
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, '0');
      const d = String(date.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    };

    const novasTarefas = [];

    (roteiro.dias || []).forEach((dia, index) => {
      const dataServico = somarDias(dataInicio, index);

      // A) Roteiro (Passeios/Atrações do Dia) - Apenas se dia.tourGuiado === true
      const sequencias = (dia.elementos || []).filter(el => el.tipo === 'sequencia');
      const infos = (dia.elementos || []).filter(el => el.tipo === 'info');
      const textos = (dia.elementos || []).filter(el => el.tipo === 'texto');

      let cidade = '';
      const nomesAtracoes = [];
      const rotasNomes = [];
      sequencias.forEach(seq => {
        if (seq.cidade) cidade = seq.cidade;
        if (seq.nomeDaRota) rotasNomes.push(seq.nomeDaRota);
        if (seq.atracoesDoDia) {
          seq.atracoesDoDia.forEach(atr => {
            if (atr.nome) nomesAtracoes.push(atr.nome);
          });
        }
      });

      if (dia.tourGuiado === true) {
        let tituloRoteiro = `Dia ${index + 1} - Tour`;
        if (cidade) tituloRoteiro += ` em ${cidade}`;

        let horaEncontro = '';
        let localEncontro = '';
        let duracaoTour = '';
        if (infos.length > 0) {
          horaEncontro = infos[0].horarioEncontro || '';
          localEncontro = infos[0].localEncontro || '';
          duracaoTour = infos[0].duracaoTour || '';
        }

        novasTarefas.push({
          id: `cal_rot_${Date.now()}_${index}_${Math.random().toString(36).substr(2, 9)}`,
          titulo: tituloRoteiro,
          dataServico,
          tipoServico: 'Roteiro',
          clienteId,
          clientes: [clienteId],
          clienteNome,
          cidade: cidade || 'Japão',
          horaEncontro,
          localEncontro,
          duracaoTour,
          atracoes: nomesAtracoes,
          rotas: rotasNomes,
          textos: textos.map(t => t.conteudo).filter(Boolean),
          assignee: []
        });
      }

      // B) Transportes - Adiciona sempre que existirem no dia
      const transportes = (dia.elementos || []).filter(el => el.tipo === 'transporte');
      transportes.forEach((t, tIdx) => {
        const orig = t.cidadeOrigem || 'Origem';
        const dest = t.cidadeDestino || 'Destino';
        const hora = t.horario || '';
        const nomeTr = t.tipoTransporte || 'Deslocamento';
        const tituloTr = `Transporte: ${orig} ➔ ${dest} (${nomeTr})`;

        novasTarefas.push({
          id: `cal_tr_${Date.now()}_${index}_${tIdx}_${Math.random().toString(36).substr(2, 9)}`,
          titulo: tituloTr,
          dataServico,
          tipoServico: nomeTr,
          clienteId,
          clientes: [clienteId],
          clienteNome,
          cidade: `${orig} ➔ ${dest}`,
          horaEncontro: hora,
          localEncontro: t.cidadeOrigem ? `Estação/Aeroporto de ${t.cidadeOrigem}` : '',
          transportInfo: {
            origem: orig,
            destino: dest,
            tipoTransporte: nomeTr,
            horario: hora,
            linha: t.linha || '',
            categoria: t.categoria || '',
            tempo: t.tempo || '',
            adultos: t.adultos || '',
            compradoHeian: t.compradoHeian !== false,
            observacoes: t.observacoes || ''
          },
          assignee: []
        });
      });

      // C) Experiências / Tickets - Adiciona sempre que existirem no dia
      const experiencias = (dia.elementos || []).filter(el => el.tipo === 'experiencia');
      experiencias.forEach((e, eIdx) => {
        const hora = e.horaPartida || '';
        const nome = e.nomeExp || 'Experiência';
        const tituloExp = `${nome}`;

        novasTarefas.push({
          id: `cal_exp_${Date.now()}_${index}_${eIdx}_${Math.random().toString(36).substr(2, 9)}`,
          titulo: tituloExp,
          dataServico,
          tipoServico: 'Experiência',
          clienteId,
          clientes: [clienteId],
          clienteNome,
          cidade: cidade || 'Japão',
          horaEncontro: hora,
          localEncontro: e.localEncontro || e.observacoes || '',
          expInfo: {
            nomeExp: nome,
            horaPartida: hora,
            adultos: e.adultos || '',
            compradoHeian: e.compradoHeian !== false,
            observacoes: e.observacoes || ''
          },
          assignee: []
        });
      });
    });

    // Buscar eventos existentes para outras cotações/clientes
    const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventosExistentes = [];
    if (calCfg && calCfg.data) {
      eventosExistentes = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    // Filtrar eventos antigos deste roteiro para removê-los
    const eventosFiltrados = eventosExistentes.filter(ev => {
      const matchCliente = ev.clienteId && ev.clienteId === clienteId;
      const matchRoteiro = ev.roteiroNome && ev.roteiroNome === roteiroNome;
      return !matchCliente && !matchRoteiro;
    });

    // Mapear guias que já estavam atribuídos para preservá-los
    const encontrarGuiaExistente = (tipo, data) => {
      const match = eventosExistentes.find(ev => 
        ev.dataServico === data && 
        (ev.clienteId === clienteId || ev.roteiroNome === roteiroNome) &&
        (ev.tipoServico === tipo || (tipo !== 'Roteiro' && tipo !== 'Experiência' && ev.tipoServico !== 'Roteiro' && ev.tipoServico !== 'Experiência'))
      );
      return match ? match.assignee : [];
    };

    // Aplicar a busca de guias e roteiroNome nos novos eventos
    novasTarefas.forEach(ev => {
      ev.assignee = encontrarGuiaExistente(ev.tipoServico, ev.dataServico);
      ev.roteiroNome = roteiroNome;
    });

    // ── CONFIGURAÇÃO DE SINCRONIZAÇÃO COM A AGENDA DO NOTION ──
    const NOTION_AGENDA_DB_ID = process.env.NOTION_AGENDA_DB_ID;
    
    if (NOTION_TOKEN && NOTION_AGENDA_DB_ID && clienteId && clienteId !== 'cliente_desconhecido') {
      try {
        console.log(`Buscando eventos antigos na Agenda do Notion para o cliente ${clienteId}...`);
        const queryResponse = await fetch(`https://api.notion.com/v1/databases/${NOTION_AGENDA_DB_ID}/query`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            filter: {
              property: '🎀 Clientes',
              relation: { contains: clienteId }
            }
          })
        });

        if (queryResponse.ok) {
          const queryData = await queryResponse.json();
          const oldEvents = queryData.results || [];
          console.log(`Arquivando ${oldEvents.length} eventos antigos na Agenda do Notion...`);
          
          for (const evPage of oldEvents) {
            try {
              await fetch(`https://api.notion.com/v1/pages/${evPage.id}`, {
                method: 'PATCH',
                headers: {
                  'Authorization': `Bearer ${NOTION_TOKEN}`,
                  'Notion-Version': '2022-06-28',
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ archived: true })
              });
            } catch (err) {
              console.error(`Erro ao arquivar card ${evPage.id} na Agenda do Notion:`, err);
            }
          }
        }
      } catch (notionQueryErr) {
        console.error('Erro ao limpar eventos na Agenda do Notion:', notionQueryErr);
      }
    }

    // Criar as novas tarefas na Agenda do Notion e associar os IDs retornados
    for (const tf of novasTarefas) {
      if (NOTION_TOKEN && NOTION_AGENDA_DB_ID && clienteId && clienteId !== 'cliente_desconhecido') {
        try {
          let valorDiariaPadrao = 0;
          const isRoteiro = tf.tipoServico && tf.tipoServico.toLowerCase() === 'roteiro';
          
          if (isRoteiro) {
            valorDiariaPadrao = 35000; // Valor de fallback padrão
          }

          // Montar o descritivo rico e estruturado para a coluna de Observações
          let obsTexto = '';
          const parts = [];
          
          if (isRoteiro) {
            if (tf.horaEncontro) parts.push(`🕒 Horário de Encontro: ${tf.horaEncontro}`);
            if (tf.localEncontro) parts.push(`📍 Local de Encontro: ${tf.localEncontro}`);
            if (tf.duracaoTour) parts.push(`⏳ Duração: Tour de ${tf.duracaoTour}`);
            if (tf.rotas && tf.rotas.length > 0) parts.push(`🗺️ Rota:\n${tf.rotas.join(' ➔ ')}`);
            if (tf.atracoes && tf.atracoes.length > 0) parts.push(`⭐ Atrações:\n${tf.atracoes.join(', ')}`);
            if (tf.textos && tf.textos.length > 0) parts.push(`📝 Detalhes:\n${tf.textos.join('\n')}`);
          } else if (tf.transportInfo) {
            if (tf.transportInfo.tipoTransporte) parts.push(`Transporte: ${tf.transportInfo.tipoTransporte}`);
            if (tf.transportInfo.origem && tf.transportInfo.destino) parts.push(`Trajeto: ${tf.transportInfo.origem} ➔ ${tf.transportInfo.destino}`);
            if (tf.transportInfo.horario) parts.push(`Horário Encontro: ${tf.transportInfo.horario}`);
            if (tf.transportInfo.observacoes) parts.push(`Detalhes: ${tf.transportInfo.observacoes}`);
          } else if (tf.expInfo) {
            if (tf.expInfo.nomeExp) parts.push(`Experiência: ${tf.expInfo.nomeExp}`);
            if (tf.expInfo.horaPartida) parts.push(`Horário Encontro: ${tf.expInfo.horaPartida}`);
            if (tf.expInfo.observacoes) parts.push(`Detalhes: ${tf.expInfo.observacoes}`);
          }
          
          obsTexto = parts.join('\n\n').trim();

          const properties = {
            'Nome': {
              title: [{ text: { content: tf.titulo } }]
            },
            'Data do Tour': {
              date: { start: tf.dataServico }
            },
            '🎀 Clientes': {
              relation: [{ id: clienteId }]
            }
          };

          if (tf.cidade) {
            const cidadeClean = tf.cidade.substring(0, 50).trim();
            properties['Cidade'] = {
              select: { name: cidadeClean }
            };
          }

          if (tf.assignee && tf.assignee.length > 0) {
            properties['Responsável'] = {
              relation: tf.assignee.map(a => ({ id: a.id }))
            };
          }

          properties['Valor diária do Guia'] = {
            number: isRoteiro ? valorDiariaPadrao : 0
          };

          if (obsTexto) {
            properties['Observações'] = {
              rich_text: [{ text: { content: obsTexto.substring(0, 2000) } }]
            };
          }

          const response = await fetch('https://api.notion.com/v1/pages', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${NOTION_TOKEN}`,
              'Notion-Version': '2022-06-28',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              parent: { database_id: NOTION_AGENDA_DB_ID },
              properties
            })
          });

          if (response.ok) {
            const pageData = await response.json();
            tf.id = pageData.id; // Substitui o ID pseudo-aleatório pelo ID real do Notion!
            tf.valorDiaria = isRoteiro ? valorDiariaPadrao : 0;
            tf.pago = false;
          } else {
            const errText = await response.text();
            console.error('Erro ao cadastrar evento na Agenda do Notion:', errText);
          }
        } catch (err) {
          console.error('Erro ao cadastrar card na Agenda do Notion:', err);
        }
      }
    }

    const todosEventos = [...eventosFiltrados, ...novasTarefas];

    // Gravar localmente no Supabase
    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: todosEventos });
    if (upsertErr) throw upsertErr;

    res.json({ success: true, count: novasTarefas.length });

    // Disparar envio de e-mails em background para novas atividades criadas a partir do roteiro
    processarNotificacoesEmail().catch(err => console.error('[Email Trigger] Erro ao processar e-mails pós-sincronismo Roteiro:', err));
  } catch (error) {
    console.error('Erro ao sincronizar roteiro com calendário local:', error);
    res.status(500).json({ error: error.message });
  }
});

// ── API: Dashboard Financeiro e Contas do Notion ─────────────────────────────

app.get('/api/notion/contas', async (req, res) => {
  try {
    const NOTION_CONTAS_DB_ID = process.env.NOTION_CONTAS_DB_ID || '2bab6e48f954803bae65d962d2b529f5';
    const response = await fetch(`https://api.notion.com/v1/databases/${NOTION_CONTAS_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Erro ao consultar base de contas: ${errText}`);
    }

    const data = await response.json();
    const contas = (data.results || [])
      .map(item => {
        const p = item.properties;
        return {
          id: item.id,
          nome: p['Nome']?.title?.map(t => t.plain_text).join('') || 'Sem Nome'
        };
      })
      .filter(c => !c.nome.toLowerCase().includes('wise da mocreia') && !c.nome.toLowerCase().includes('wise da mocréia'));

    res.json(contas);
  } catch (error) {
    console.error('Erro ao buscar contas no Notion:', error);
    res.status(500).json({ error: 'Erro ao buscar contas no Notion', details: error.message });
  }
});

app.post('/api/calendario/pagar-guia', async (req, res) => {
  try {
    const { eventoId, colaboradorId, clienteId, contaId, moeda, valorMoedaOriginal } = req.body;
    if (!eventoId || !colaboradorId || !clienteId || !contaId || !moeda || !valorMoedaOriginal) {
      return res.status(400).json({ error: 'Parâmetros obrigatórios ausentes: eventoId, colaboradorId, clienteId, contaId, moeda, valorMoedaOriginal.' });
    }

    // 1. Obter evento local
    const { data: calCfg } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data.data) ? calCfg.data.data : (Array.isArray(calCfg.data) ? calCfg.data : []);
    }

    const evIndex = eventos.findIndex(e => e.id === eventoId);
    if (evIndex === -1) {
      return res.status(404).json({ error: 'Evento não encontrado no calendário.' });
    }

    const ev = eventos[evIndex];

    // Obter as taxas de câmbio da config do Supabase
    const { data: appConfig } = await supabase.from('config').select('data').eq('id', 'app_config').single();
    let rateBRL = 0.031670;
    let rateUSD = 0.006280;
    if (appConfig && appConfig.data) {
      rateBRL = parseFloat(appConfig.data.cambio_jpy_brl) || rateBRL;
      rateUSD = parseFloat(appConfig.data.cambio_jpy_usd) || rateUSD;
    }

    // 2. Calcular valor em JPY
    const valorOriginalNum = Number(valorMoedaOriginal) || 0;
    let valorJPY = valorOriginalNum;
    let descCambioText = '';

    if (moeda === 'BRL') {
      valorJPY = Math.round(valorOriginalNum / rateBRL);
      descCambioText = ` [Original: R$ ${valorOriginalNum.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/BRL: ${rateBRL.toFixed(6)}]`;
    } else if (moeda === 'USD') {
      valorJPY = Math.round(valorOriginalNum / rateUSD);
      descCambioText = ` [Original: $ ${valorOriginalNum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/USD: ${rateUSD.toFixed(6)}]`;
    } else {
      descCambioText = ` [Original: ¥ ${valorOriginalNum.toLocaleString('en-US')} JPY]`;
    }

    // 3. Criar registro de Saída no Notion
    const NOTION_SAIDAS_DB_ID = process.env.NOTION_SAIDAS_DB_ID;
    
    const colabObj = ev.assignee ? ev.assignee.find(a => a.id === colaboradorId) : null;
    const colabName = colabObj ? colabObj.name : 'Colaborador';
    
    const descricaoSaida = `Pagamento Guia: ${colabName} - ${ev.titulo || 'Serviço'}${descCambioText}`;

    const properties = {
      'Descrição': { title: [{ text: { content: descricaoSaida } }] },
      'Valor (JPY)': { number: valorJPY },
      'Data de pagamento': { date: { start: ev.dataServico || new Date().toISOString().substring(0, 10) } },
      'Categoria': { select: { name: 'Pagamento Guia' } },
      'Tipo de serviço': { select: { name: 'guia' } },
      '🎀 Clientes': { relation: [{ id: clienteId }] },
      '🫂 Colaboradores': { relation: [{ id: colaboradorId }] },
      '💳 Contas': { relation: [{ id: contaId }] }
    };

    const notionRes = await fetch(`https://api.notion.com/v1/pages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        parent: { database_id: NOTION_SAIDAS_DB_ID },
        properties
      })
    });

    if (!notionRes.ok) {
      const errTxt = await notionRes.text();
      throw new Error(`Erro ao criar Saída no Notion: ${errTxt}`);
    }

    const notionData = await notionRes.json();

    // 4. Atualizar evento local no Supabase
    if (!ev.pagoColab) ev.pagoColab = {};
    if (!ev.valorDiariaColab) ev.valorDiariaColab = {};

    ev.pagoColab[colaboradorId] = true;
    
    // Sempre mantemos a diária local em JPY (convertida se necessário)
    ev.valorDiariaColab[colaboradorId] = valorJPY;
    
    const primaryId = ev.assignee && ev.assignee.length > 0 ? ev.assignee[0].id : null;
    if (colaboradorId === primaryId) {
      ev.pago = true;
      ev.valorDiaria = valorJPY;
    }

    const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: eventos });
    if (upsertErr) throw upsertErr;

    res.json({ success: true, notionPageId: notionData.id, valorJPY });
  } catch (error) {
    console.error('Erro ao processar pagamento do guia no backend:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/notion/registrar-entrada', async (req, res) => {
  try {
    const { clienteId, descricao, valorOriginal, moeda, contaId, data } = req.body;

    if (!clienteId || !descricao || !valorOriginal || !moeda || !contaId) {
      return res.status(400).json({ error: 'Parâmetros incompletos.' });
    }

    // 1. Obter taxas de câmbio
    const appConfig = await supabase.from('config').select('data').eq('id', 'app_config').single();
    let rateBRL = 0.031670;
    let rateUSD = 0.006280;
    if (appConfig && appConfig.data) {
      rateBRL = parseFloat(appConfig.data.cambio_jpy_brl) || rateBRL;
      rateUSD = parseFloat(appConfig.data.cambio_jpy_usd) || rateUSD;
    }

    const valorOriginalNum = Number(valorOriginal) || 0;
    let valorJPY = valorOriginalNum;
    let descCambioText = '';

    if (moeda === 'BRL') {
      valorJPY = Math.round(valorOriginalNum / rateBRL);
      descCambioText = ` [Original: R$ ${valorOriginalNum.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/BRL: ${rateBRL.toFixed(6)}]`;
    } else if (moeda === 'USD') {
      valorJPY = Math.round(valorOriginalNum / rateUSD);
      descCambioText = ` [Original: $ ${valorOriginalNum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/USD: ${rateUSD.toFixed(6)}]`;
    } else {
      descCambioText = ` [Original: ¥ ${valorOriginalNum.toLocaleString('en-US')} JPY]`;
    }

    const descricaoCompleta = `${descricao}${descCambioText}`;

    // 2. Criar página na base de Entradas do Notion
    const NOTION_ENTRADAS_DB_ID = process.env.NOTION_ENTRADAS_DB_ID;
    
    const properties = {
      'Descrição da Entrada': { title: [{ text: { content: descricaoCompleta } }] },
      'Valor (JPY)': { number: valorJPY },
      'Data do pagamento': { date: { start: data || new Date().toISOString().substring(0, 10) } },
      'Moeda Original': { select: { name: moeda } },
      'Cliente (Relação)': { relation: [{ id: clienteId }] },
      '💳 Contas': { relation: [{ id: contaId }] }
    };

    const notionRes = await fetch(`https://api.notion.com/v1/pages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        parent: { database_id: NOTION_ENTRADAS_DB_ID },
        properties
      })
    });

    if (!notionRes.ok) {
      const errTxt = await notionRes.text();
      throw new Error(`Erro ao criar entrada no Notion: ${errTxt}`);
    }

    const notionData = await notionRes.json();
    res.json({ success: true, notionPageId: notionData.id, valorJPY });
  } catch (error) {
    console.error('Erro ao registrar entrada de pagamento:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/notion/registrar-saida', async (req, res) => {
  try {
    const { clienteId, colaboradorId, eventoId, descricao, valorOriginal, moeda, contaId, data, taskId } = req.body;

    if (!descricao || !valorOriginal || !moeda || !contaId) {
      return res.status(400).json({ error: 'Parâmetros incompletos.' });
    }

    // 1. Obter taxas de câmbio
    const appConfig = await supabase.from('config').select('data').eq('id', 'app_config').single();
    let rateBRL = 0.031670;
    let rateUSD = 0.006280;
    if (appConfig && appConfig.data) {
      rateBRL = parseFloat(appConfig.data.cambio_jpy_brl) || rateBRL;
      rateUSD = parseFloat(appConfig.data.cambio_jpy_usd) || rateUSD;
    }

    const valorOriginalNum = Number(valorOriginal) || 0;
    let valorJPY = valorOriginalNum;
    let descCambioText = '';

    if (moeda === 'BRL') {
      valorJPY = Math.round(valorOriginalNum / rateBRL);
      descCambioText = ` [Original: R$ ${valorOriginalNum.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/BRL: ${rateBRL.toFixed(6)}]`;
    } else if (moeda === 'USD') {
      valorJPY = Math.round(valorOriginalNum / rateUSD);
      descCambioText = ` [Original: $ ${valorOriginalNum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} | Câmbio JPY/USD: ${rateUSD.toFixed(6)}]`;
    } else {
      descCambioText = ` [Original: ¥ ${valorOriginalNum.toLocaleString('en-US')} JPY]`;
    }

    const descricaoCompleta = `${descricao}${descCambioText}`;

    // 2. Criar página na base de Saídas do Notion
    const NOTION_SAIDAS_DB_ID = process.env.NOTION_SAIDAS_DB_ID;
    
    const properties = {
      'Descrição': { title: [{ text: { content: descricaoCompleta } }] },
      'Valor (JPY)': { number: valorJPY },
      'Data de pagamento': { date: { start: data || new Date().toISOString().substring(0, 10) } },
      '💳 Contas': { relation: [{ id: contaId }] }
    };

    if (clienteId && clienteId !== 'cliente_desconhecido' && clienteId !== 'Sem Nome' && clienteId !== 'Geral') {
      properties['🎀 Clientes'] = { relation: [{ id: clienteId }] };
    }

    if (colaboradorId) {
      properties['🫂 Colaboradores'] = { relation: [{ id: colaboradorId }] };
    }

    if (taskId) {
      properties['Saída financeira'] = { relation: [{ id: taskId }] };
    }

    const notionRes = await fetch(`https://api.notion.com/v1/pages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        parent: { database_id: NOTION_SAIDAS_DB_ID },
        properties
      })
    });

    if (!notionRes.ok) {
      const errTxt = await notionRes.text();
      throw new Error(`Erro ao criar saída no Notion: ${errTxt}`);
    }

    const notionData = await notionRes.json();

    // 3. Se houver eventoId e colaboradorId, marcar o colaborador como pago no Supabase
    let localUpdated = false;
    if (eventoId && colaboradorId) {
      const { data: calCfg, error: calErr } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
      if (calCfg && calCfg.data) {
        let eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
        eventos = eventos.map(ev => {
          if (ev.id === eventoId) {
            localUpdated = true;
            const newEv = { ...ev };
            if (!newEv.pagoColab) newEv.pagoColab = {};
            newEv.pagoColab[colaboradorId] = true;

            // Se for o colaborador principal, atualizar o campo global "pago"
            const primaryId = newEv.assignee && newEv.assignee.length > 0 ? newEv.assignee[0].id : null;
            if (colaboradorId === primaryId || !primaryId) {
              newEv.pago = true;
            }
            return newEv;
          }
          return ev;
        });

        if (localUpdated) {
          const { error: upsertErr } = await supabase.from('config').upsert({ id: 'calendario_eventos', data: eventos });
          if (upsertErr) {
            console.error('Erro ao atualizar status de pagamento do evento no Supabase:', upsertErr);
          }
        }
      }
    }

    res.json({ success: true, notionPageId: notionData.id, valorJPY, localUpdated });
  } catch (error) {
    console.error('Erro ao registrar saída de pagamento:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/notion/tasks-cliente/:clientId', async (req, res) => {
  try {
    const { clientId } = req.params;
    const NOTION_TASKS_DB_ID = process.env.NOTION_TASKS_DB_ID;

    if (!NOTION_TOKEN || !NOTION_TASKS_DB_ID) {
      return res.status(400).json({ error: 'Configuração do Notion incompleta.' });
    }

    console.log(`[Tasks Cliente] Buscando tasks do cliente ${clientId} no Notion...`);
    const response = await fetch(`https://api.notion.com/v1/databases/${NOTION_TASKS_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        filter: {
          property: '🎀 Clientes',
          relation: {
            contains: clientId
          }
        }
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Erro ao consultar tasks: ${errText}`);
    }

    const data = await response.json();
    const tasks = (data.results || []).map(item => {
      const p = item.properties;
      const nome = p['Task name']?.title?.map(t => t.plain_text).join('') || 'Sem nome';
      return {
        id: item.id,
        nome
      };
    });

    res.json({ success: true, tasks });
  } catch (error) {
    console.error('Erro ao buscar tasks do cliente:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/financeiro/diarias-pendentes', async (req, res) => {
  try {
    const { data: calCfg } = await supabase.from('config').select('data').eq('id', 'calendario_eventos').single();
    let eventos = [];
    if (calCfg && calCfg.data) {
      eventos = Array.isArray(calCfg.data) ? calCfg.data : [];
    }

    const diariasPendentes = [];

    eventos.forEach(ev => {
      if (ev.assignee && ev.assignee.length > 0) {
        ev.assignee.forEach(a => {
          const colabId = a.id;
          const colabName = a.name;
          const valor = ev.valorDiariaColab ? ev.valorDiariaColab[colabId] : 0;
          const pago = ev.pagoColab ? ev.pagoColab[colabId] : false;

          // Se tiver valor de diária configurado e não estiver pago
          if (valor > 0 && !pago) {
            diariasPendentes.push({
              eventoId: ev.id,
              eventoTitulo: ev.titulo,
              dataServico: ev.dataServico,
              clienteId: ev.clienteId,
              clienteNome: ev.clienteNome || 'Geral',
              colaboradorId: colabId,
              colaboradorNome: colabName,
              valorDiaria: valor
            });
          }
        });
      }
    });

    // Ordenar por data (mais antigas primeiro, para priorizar o pagamento)
    diariasPendentes.sort((a, b) => (a.dataServico || '').localeCompare(b.dataServico || ''));

    res.json(diariasPendentes);
  } catch (error) {
    console.error('Erro ao buscar diárias pendentes:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/dashboard/saldos-contas', async (req, res) => {
  try {
    const NOTION_CONTAS_DB_ID = process.env.NOTION_CONTAS_DB_ID || '2bab6e48f954803bae65d962d2b529f5';
    const NOTION_ENTRADAS_DB_ID = process.env.NOTION_ENTRADAS_DB_ID;
    const NOTION_SAIDAS_DB_ID = process.env.NOTION_SAIDAS_DB_ID;

    // Função genérica para buscar todas as páginas de uma base do Notion (paginação)
    const queryAllNotion = async (dbId) => {
      let results = [];
      let hasMore = true;
      let startCursor = undefined;

      while (hasMore) {
        const body = {};
        if (startCursor) {
          body.start_cursor = startCursor;
        }

        const response = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${NOTION_TOKEN}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(body)
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Erro ao consultar base ${dbId} do Notion: ${errText}`);
        }

        const data = await response.json();
        results = results.concat(data.results || []);
        hasMore = data.has_more;
        startCursor = data.next_cursor;
      }

      return { results };
    };

    // Buscar contas
    const contasData = await queryAllNotion(NOTION_CONTAS_DB_ID);
    const contas = (contasData.results || [])
      .map(item => {
        const p = item.properties;
        return {
          id: item.id,
          nome: p['Nome']?.title?.map(t => t.plain_text).join('') || 'Sem Nome',
          saldoBRL: 0,
          saldoJPY: 0,
          saldoUSD: 0,
          movimentacoes: []
        };
      })
      .filter(c => !c.nome.toLowerCase().includes('wise da mocreia') && !c.nome.toLowerCase().includes('wise da mocréia'));

    const NOTION_COLABORADORES_DB_ID = process.env.NOTION_COLABORADORES_DB_ID || '2a0b6e48f954816082afde2815056602';

    const [entradasData, saidasData, clisRes, colaboradoresData, appConfig] = await Promise.all([
      queryAllNotion(NOTION_ENTRADAS_DB_ID),
      queryAllNotion(NOTION_SAIDAS_DB_ID),
      supabase.from('clientes_locais').select('data'),
      queryAllNotion(NOTION_COLABORADORES_DB_ID),
      supabase.from('config').select('data').eq('id', 'app_config').single()
    ]);

    // Construir mapas de ID -> Nome para Clientes (local Supabase) e Colaboradores (Notion)
    const clientesMap = {};
    if (clisRes.data) {
      clisRes.data.forEach(row => {
        const c = row.data;
        if (c && c.id) {
          clientesMap[c.id] = c.nome || 'Sem Nome';
        }
      });
    }

    const colaboradoresMap = {};
    (colaboradoresData.results || []).forEach(item => {
      const p = item.properties;
      const nameProp = p.Name || p.Nome;
      const nome = nameProp?.title?.[0]?.plain_text || 'Sem Nome';
      colaboradoresMap[item.id] = nome;
    });

    let rateBRL = 0.031670;
    let rateUSD = 0.006280;
    if (appConfig && appConfig.data) {
      rateBRL = parseFloat(appConfig.data.cambio_jpy_brl) || rateBRL;
      rateUSD = parseFloat(appConfig.data.cambio_jpy_usd) || rateUSD;
    }

    const rates = { brl: rateBRL, usd: rateUSD };

    const extrairInfoVal = (descricao, valorJPY, moedaOriginal) => {
      const match = descricao && descricao.match(/\[Original:\s*([BRL|USD|JPY$¥]+)\s*([\d.,\s]+)/i);
      if (match) {
        const coinText = match[1].toUpperCase();
        let parsedMoeda = 'JPY';
        if (coinText.includes('R$') || coinText.includes('BRL')) parsedMoeda = 'BRL';
        else if (coinText.includes('$') || coinText.includes('USD')) parsedMoeda = 'USD';

        let valStr = match[2].trim();
        if (parsedMoeda === 'BRL') {
          // BRL: milhar é ponto (remover), decimal é vírgula (virar ponto)
          valStr = valStr.replace(/[.\s]/g, '').replace(',', '.');
        } else {
          // JPY / USD: milhar é vírgula (remover), decimal é ponto (manter)
          valStr = valStr.replace(/[\,\s]/g, '');
        }

        const parsedVal = parseFloat(valStr);
        if (!isNaN(parsedVal)) {
          return { valor: parsedVal, moeda: parsedMoeda };
        }
      }

      if (moedaOriginal === 'BRL') return { valor: valorJPY * rates.brl, moeda: 'BRL' };
      if (moedaOriginal === 'USD') return { valor: valorJPY * rates.usd, moeda: 'USD' };
      return { valor: valorJPY, moeda: 'JPY' };
    };

    // Entradas
    (entradasData.results || []).forEach(item => {
      const p = item.properties;
      const valorJPY = p['Valor (JPY)']?.number || 0;
      const moedaOriginal = p['Moeda Original']?.select?.name || 'JPY';
      const descricao = p['Descrição da Entrada']?.title?.map(t => t.plain_text).join('') || 'Entrada sem nome';
      const data = p['Data do pagamento']?.date?.start || '';
      const contasRel = p['💳 Contas']?.relation || [];

      // Mapear Cliente
      const clienteRel = p['Cliente (Relação)']?.relation || [];
      const clienteId = clienteRel[0]?.id;
      const clienteNome = clienteId ? (clientesMap[clienteId] || 'Desconhecido') : '';

      const info = extrairInfoVal(descricao, valorJPY, moedaOriginal);

      contasRel.forEach(cRel => {
        const conta = contas.find(c => c.id === cRel.id);
        if (conta) {
          if (info.moeda === 'BRL') conta.saldoBRL += info.valor;
          else if (info.moeda === 'USD') conta.saldoUSD += info.valor;
          else conta.saldoJPY += info.valor;

          conta.movimentacoes.push({
            id: item.id,
            tipo: 'entrada',
            data,
            descricao,
            valorOriginal: info.valor,
            moedaOriginal: info.moeda,
            valorJPY,
            clienteNome,
            colaboradorNome: ''
          });
        }
      });
    });

    // Saídas
    (saidasData.results || []).forEach(item => {
      const p = item.properties;
      const valorJPY = p['Valor (JPY)']?.number || 0;
      const descricao = p['Descrição']?.title?.map(t => t.plain_text).join('') || 'Saída sem nome';
      const data = p['Data de pagamento']?.date?.start || '';
      const contasRel = p['💳 Contas']?.relation || [];

      // Mapear Cliente e Colaborador
      const clienteRel = p['🎀 Clientes']?.relation || [];
      const clienteId = clienteRel[0]?.id;
      const clienteNome = clienteId ? (clientesMap[clienteId] || 'Desconhecido') : '';

      const colabRel = p['🫂 Colaboradores']?.relation || [];
      const colabId = colabRel[0]?.id;
      const colaboradorNome = colabId ? (colaboradoresMap[colabId] || 'Desconhecido') : '';

      const info = extrairInfoVal(descricao, valorJPY, 'JPY');

      contasRel.forEach(cRel => {
        const conta = contas.find(c => c.id === cRel.id);
        if (conta) {
          if (info.moeda === 'BRL') conta.saldoBRL -= info.valor;
          else if (info.moeda === 'USD') conta.saldoUSD -= info.valor;
          else conta.saldoJPY -= info.valor;

          conta.movimentacoes.push({
            id: item.id,
            tipo: 'saida',
            data,
            descricao,
            valorOriginal: info.valor,
            moedaOriginal: info.moeda,
            valorJPY,
            clienteNome,
            colaboradorNome
          });
        }
      });
    });

    // Ordenar movimentações de cada conta por data descrescente
    contas.forEach(c => {
      c.movimentacoes.sort((a, b) => (b.data || '').localeCompare(a.data || ''));
    });

    res.json(contas);
  } catch (error) {
    console.error('Erro ao calcular saldos das contas:', error);
    res.status(500).json({ error: error.message });
  }
});

// Cache e funções auxiliares para URLs amigáveis de Clientes
let slugToIdCache = {};
let lastCacheUpdate = 0;
const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 horas (o cache também é reconstruído sob demanda em caso de miss)

function gerarSlug(text) {
  if (!text) return '';
  return text.toString().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-')
    .trim();
}

// ── Segurança da Área do Cliente ────────────────────────────────────────────
// O link público passa a exigir um token derivado do ID do cliente (HMAC),
// para que o nome do cliente sozinho não dê acesso a voos, hotel e valores.
const crypto = require('crypto');

function portalSecret() {
  return process.env.PORTAL_LINK_SECRET || process.env.APP_PASS || '';
}

function gerarTokenPortal(clientId) {
  const secret = portalSecret();
  if (!secret) return '';
  const norm = String(clientId || '').replace(/-/g, '').toLowerCase();
  return crypto.createHmac('sha256', secret).update(norm).digest('hex').slice(0, 12);
}

function tokenPortalValido(clientId, t) {
  const secret = portalSecret();
  if (!secret) return true; // sem secret configurado (ex.: dev local sem APP_PASS), não exige token
  if (!t) return false;
  const esperado = gerarTokenPortal(clientId);
  try {
    return crypto.timingSafeEqual(Buffer.from(String(t)), Buffer.from(esperado));
  } catch (e) {
    return false;
  }
}

// Permite que o painel admin (autenticado via Basic Auth) continue usando as APIs
// sem precisar do token do portal.
function requestAutenticadaAdmin(req) {
  if (!process.env.APP_PASS) return true;
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  try {
    const decoded = Buffer.from(h.slice(6), 'base64').toString();
    const idx = decoded.indexOf(':');
    const u = decoded.slice(0, idx);
    const p = decoded.slice(idx + 1);
    return u === (process.env.APP_USER || 'admin') && p === process.env.APP_PASS;
  } catch (e) {
    return false;
  }
}

// Reconstrói o mapa slug → id consultando a base de Clientes do Notion
async function reconstruirCacheSlugs() {
  const NOTION_CLIENTS_DB_ID = process.env.NOTION_CLIENTS_DB_ID;
  if (!NOTION_TOKEN || !NOTION_CLIENTS_DB_ID) {
    throw new Error('Configuração do Notion incompleta no arquivo .env.');
  }
  let results = [];
  let hasMore = true;
  let startCursor = undefined;
  while (hasMore) {
    const body = {};
    if (startCursor) body.start_cursor = startCursor;
    const response = await fetch(`https://api.notion.com/v1/databases/${NOTION_CLIENTS_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Erro ao consultar base ${NOTION_CLIENTS_DB_ID} do Notion: ${errText}`);
    }
    const data = await response.json();
    results = results.concat(data.results || []);
    hasMore = data.has_more;
    startCursor = data.next_cursor;
  }
  const newCache = {};
  results.forEach(item => {
    const p = item.properties;
    const nomeProp = p['Nome do Cliente'] || p['Name'] || p['Nome'];
    const nome = nomeProp?.title?.map(t => t.plain_text).join('') || '';
    if (nome) {
      newCache[gerarSlug(nome)] = item.id;
    }
  });
  slugToIdCache = newCache;
  lastCacheUpdate = Date.now();
  return newCache;
}

async function getClientDataHelper(clientId) {
  const NOTION_CLIENTS_DB_ID = process.env.NOTION_CLIENTS_DB_ID;
  const NOTION_ENTRADAS_DB_ID = process.env.NOTION_ENTRADAS_DB_ID;

  if (!NOTION_TOKEN || !NOTION_CLIENTS_DB_ID || !NOTION_ENTRADAS_DB_ID) {
    throw new Error('Configuração do Notion incompleta no arquivo .env.');
  }

  let clientInfo = null;

  // 1. Tentar buscar dados do cliente no Notion
  try {
    const notionClientRes = await fetch(`https://api.notion.com/v1/pages/${clientId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28'
      }
    });

    if (notionClientRes.ok) {
      const clientPage = await notionClientRes.json();
      const p = clientPage.properties;

      const getTitle = (prop) => prop?.title?.map(t => t.plain_text).join('') || '';
      const getRichText = (prop) => prop?.rich_text?.map(t => t.plain_text).join('') || '';
      const getNumber = (prop) => prop?.number || 0;
      const getSelect = (prop) => prop?.select?.name || '';
      const getDateStart = (prop) => prop?.date?.start || '';
      const getDateEnd = (prop) => prop?.date?.end || '';
      const getFormulaNumber = (prop) => prop?.formula?.number || 0;
      const getFormulaString = (prop) => prop?.formula?.string || '';
      const getRollupNumber = (prop) => prop?.rollup?.number || 0;

      clientInfo = {
        id: clientPage.id,
        nome: getTitle(p['Nome do Cliente'] || p['Name'] || p['Nome']),
        status: getSelect(p['Status do Cliente'] || p['Status']),
        adultos: getNumber(p['Qtd Adultos']),
        criancas: getNumber(p['Qtd Crianças']),
        vooChegada: getRichText(p['Voo de Chegada']),
        vooPartida: getRichText(p['Voo de Partida']),
        dataInicio: getDateStart(p['Período da Viagem']),
        dataFim: getDateEnd(p['Período da Viagem']),
        hotel: getRichText(p['Hotel']),
        viajantes: getRichText(p['Nome dos Viajantes'] || p['Viajantes']),
        briefing: getRichText(p['Briefing'] || p['Preferências'] || p['Observações'] || p['Descrição']),
        valorTotal: getNumber(p['Valor Total']),
        totalPago: getRollupNumber(p['Total Pago']),
        saldoPagar: getFormulaNumber(p['Saldo a Pagar']),
        statusPagamento: getFormulaString(p['Status de pagamento'])
      };
    }
  } catch (err) {
    console.error('Erro ao buscar cliente no Notion (getClientDataHelper):', err.message);
  }

  // Fallback para o banco local se o Notion falhar ou não encontrar o cliente
  if (!clientInfo) {
    try {
      const { data: localClientRow } = await supabase.from('clientes_locais').select('data').eq('id', clientId).maybeSingle();
      if (localClientRow && localClientRow.data) {
        const lc = localClientRow.data;
        clientInfo = {
          id: lc.id,
          nome: lc.nome || lc.clienteNome || 'Cliente Local',
          status: lc.status || 'Roteiro em Edição',
          adultos: Number(lc.adultos) || 2,
          criancas: Number(lc.criancas) || 0,
          vooChegada: lc.vooChegada || '',
          vooPartida: lc.vooPartida || '',
          dataInicio: lc.dataInicio || '',
          dataFim: lc.dataFim || '',
          hotel: lc.hotel || '',
          viajantes: lc.viajantes || '',
          briefing: lc.briefing || '',
          valorTotal: Number(lc.valorTotal) || 0,
          totalPago: Number(lc.totalPago) || 0,
          saldoPagar: Number(lc.saldoPagar) || 0,
          statusPagamento: lc.statusPagamento || 'Pendente'
        };
      }
    } catch (localErr) {
      console.error('Erro ao buscar cliente local no Supabase (getClientDataHelper):', localErr.message);
    }
  }

  if (!clientInfo) {
    throw new Error('Cliente não encontrado no Notion ou no banco de dados local.');
  }

  // 2. Buscar Entradas (pagamentos confirmados) do cliente no Notion
  const entradasRes = await fetch(`https://api.notion.com/v1/databases/${NOTION_ENTRADAS_DB_ID}/query`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${NOTION_TOKEN}`,
      'Notion-Version': '2022-06-28',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      filter: {
        property: 'Cliente (Relação)',
        relation: {
          contains: clientId
        }
      }
    })
  });

  let payments = [];
  if (entradasRes.ok) {
    const entradasData = await entradasRes.json();
    payments = (entradasData.results || []).map(item => {
      const ep = item.properties;
      return {
        id: item.id,
        descricao: ep['Descrição da Entrada']?.title?.map(t => t.plain_text).join('') || 'Entrada',
        valor: ep['Valor (JPY)']?.number || 0,
        data: ep['Data do pagamento']?.date?.start || '',
        moeda: ep['Moeda Original']?.select?.name || 'JPY'
      };
    }).sort((a, b) => (a.data || '').localeCompare(b.data || ''));
  }

  // 3. Buscar cotação local (orcamento) no Supabase
  const { data: orcamentos } = await supabase.from('orcamentos').select('data');
  let quote = null;
  if (orcamentos && orcamentos.length > 0) {
    const matched = orcamentos.find(o => {
      if (!o.data) return false;
      if (o.data.notionClienteId === clientId) return true;
      if (clientInfo.nome) {
        const clientNameNormalized = clientInfo.nome.toLowerCase().trim().replace('família ', '').replace('familia ', '');
        if (o.data.cliente?.nome) {
          const orcClientName = o.data.cliente.nome.toLowerCase().trim().replace('família ', '').replace('familia ', '');
          if (clientNameNormalized === orcClientName || clientNameNormalized.includes(orcClientName) || orcClientName.includes(clientNameNormalized)) {
            return true;
          }
        }
      }
      return false;
    });
    if (matched && matched.data) {
      const o = matched.data;
      const sanitizeTours = (tours) => (tours || []).map(t => ({
        id: t.id,
        data: t.data,
        valor: Number(t.valor) || 0,
        descontoAtivo: !!t.descontoAtivo,
        desconto: Number(t.desconto) || 0,
        duracao: t.duracao || '',
        descricao: t.descricao || '',
        pontos: t.pontos || '',
        observacao: t.observacao || ''
      }));
      const sanitizeTransportes = (trans) => (trans || []).map(t => ({
        id: t.id,
        data: t.data,
        descricao: t.descricao || '',
        preco: Number(t.preco) || 0,
        precoInfantil: Number(t.precoInfantil) || 0,
        adultos: Number(t.adultos) || 0,
        criancas: Number(t.criancas) || 0,
        taxaAtiva: !!t.taxaAtiva,
        taxaTipo: t.taxaTipo || 'pessoa',
        taxaValor: Number(t.taxaValor) || 0,
        compradoHeian: t.compradoHeian !== false,
        observacao: t.observacao || ''
      }));
      const sanitizeExperiencias = (exps) => (exps || []).map(e => ({
        id: e.id,
        data: e.data,
        nome: e.nome || '',
        pessoas: Number(e.pessoas) || 1,
        preco: Number(e.preco) || 0,
        precoTipo: e.precoTipo || 'pessoa',
        taxaAtiva: !!e.taxaAtiva,
        taxaTipo: e.taxaTipo || 'pessoa',
        taxaValor: Number(e.taxaValor) || 0,
        compradoHeian: e.compradoHeian !== false,
        observacao: e.observacao || '',
        descricao: e.descricao || ''
      }));
      const sanitizeItens = (items) => (items || []).map(i => ({
        data: i.data,
        nome: i.nome,
        valor: Number(i.valor) || 0
      }));

      quote = {
        tours: sanitizeTours(o.tours),
        transportes: sanitizeTransportes(o.transportes),
        experiencias: sanitizeExperiencias(o.experiencias),
        itensAdicionais: sanitizeItens(o.itensAdicionais),
        consultoria: {
          ativa: o.consultoria?.ativa || false,
          valor: Number(o.consultoria?.valor) || 0,
          descricao: o.consultoria?.descricao || ''
        }
      };
    }
  }

  // 4. Buscar roteiro local no Supabase
  const { data: roteiros } = await supabase.from('roteiros').select('*');
  let itinerary = null;
  if (roteiros && roteiros.length > 0) {
    const matched = roteiros.find(r => {
      if (!r.data) return false;
      if (r.data.notionClienteId === clientId || r.data.cliente?.notionClienteId === clientId) return true;
      if (clientInfo.nome) {
        const clientNameNormalized = clientInfo.nome.toLowerCase().trim().replace('família ', '').replace('familia ', '');
        if (r.data.cliente?.nome) {
          const rotClientName = r.data.cliente.nome.toLowerCase().trim().replace('família ', '').replace('familia ', '');
          if (clientNameNormalized === rotClientName || clientNameNormalized.includes(rotClientName) || rotClientName.includes(clientNameNormalized)) {
            return true;
          }
        }
        // Usa o nome de exibição (data.nome); a chave física agora é um ID imutável
        const nomeExibicao = r.data.nome || (String(r.nome).startsWith('rot_') ? '' : r.nome);
        if (nomeExibicao) {
          const rotNameClean = nomeExibicao.toLowerCase().trim().replace('roteiro - ', '').replace('roteiro ', '').replace('família ', '').replace('familia ', '');
          if (clientNameNormalized === rotNameClean || clientNameNormalized.includes(rotNameClean) || rotNameClean.includes(clientNameNormalized)) {
            return true;
          }
        }
      }
      return false;
    });
    if (matched && matched.data) {
      const r = matched.data;
      const sanitizedDays = (r.dias || []).map(d => {
        const sanitizedElements = (d.elementos || []).map(el => {
          const { valorCusto, comissao, ...cleanEl } = el;
          return cleanEl;
        });
        return {
          data: d.data,
          cidade: d.cidade,
          tourGuiado: d.tourGuiado,
          elementos: sanitizedElements
        };
      });
      itinerary = {
        nome: r.nome,
        dias: sanitizedDays
      };
    }
  }

  // 5. Buscar Ficha Local (Supabase clientes_locais)
  const { data: localData } = await supabase.from('clientes_locais').select('data').eq('id', clientId).single();
  const clientLocalInfo = localData && localData.data ? localData.data : { estadias: [], viajantes: [] };

  // 6. Buscar lista de Hotéis ricos cadastrados no Supabase
  let hoteis = [];
  try {
    const { data: cfgHoteis } = await supabase.from('config').select('data').eq('id', 'hoteis').single();
    if (cfgHoteis && cfgHoteis.data) {
      hoteis = cfgHoteis.data;
    }
  } catch (e) {
    console.error('Erro ao buscar hotéis no Supabase:', e.message);
  }

  return {
    clientInfo,
    payments,
    quote,
    itinerary,
    clientLocalInfo,
    hoteis
  };
}

app.get('/cliente/:slug', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cliente.html'));
});

app.get('/api/public/client-data/:clientId', async (req, res) => {
  try {
    const { clientId } = req.params;
    if (!requestAutenticadaAdmin(req) && !tokenPortalValido(clientId, req.query.t)) {
      return res.status(403).json({ success: false, error: 'Link inválido ou expirado. Solicite um novo link à Heian Tour.' });
    }
    const data = await getClientDataHelper(clientId);
    res.json({
      success: true,
      ...data
    });
  } catch (error) {
    console.error('Erro na API pública da Área do Cliente:', error);
    res.status(500).json({ success: false, error: 'Erro ao buscar dados do cliente', details: error.message });
  }
});

// Endpoint autenticado (admin) com os mesmos dados — usado pelo montador de roteiros,
// que antes dependia da rota pública.
app.get('/api/clientes/:id/dados', async (req, res) => {
  try {
    const data = await getClientDataHelper(req.params.id);
    res.json({ success: true, ...data });
  } catch (error) {
    console.error('Erro na API interna de dados do cliente:', error);
    res.status(500).json({ success: false, error: 'Erro ao buscar dados do cliente', details: error.message });
  }
});

// Endpoint autenticado (admin): gera o link do portal do cliente com token
app.get('/api/clientes/:id/portal-link', async (req, res) => {
  try {
    const clientId = req.params.id;
    const token = gerarTokenPortal(clientId);
    let slug = '';
    // Tenta descobrir o slug pelo cache (reconstrói se necessário)
    const idNorm = String(clientId).replace(/-/g, '').toLowerCase();
    const achar = () => Object.keys(slugToIdCache).find(s => String(slugToIdCache[s]).replace(/-/g, '').toLowerCase() === idNorm);
    slug = achar();
    if (!slug) {
      try { await reconstruirCacheSlugs(); slug = achar(); } catch (e) { /* segue com fallback */ }
    }
    const pathPart = slug ? `/cliente/${slug}` : `/cliente/${clientId}`;
    const url = `${req.protocol}://${req.get('host')}${pathPart}${token ? `?t=${token}` : ''}`;
    res.json({ success: true, url, token, slug: slug || null });
  } catch (error) {
    console.error('Erro ao gerar link do portal:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/public/client-data/slug/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const now = Date.now();

    let clientId = slugToIdCache[slug];

    if (!clientId || (now - lastCacheUpdate) > CACHE_TTL) {
      try {
        await reconstruirCacheSlugs();
      } catch (e) {
        return res.status(400).json({ success: false, error: e.message });
      }
      clientId = slugToIdCache[slug];
    }

    if (!clientId) {
      // Se não for encontrado na tabela de slugs, tenta carregar diretamente como ID (uuid)
      if (!requestAutenticadaAdmin(req) && !tokenPortalValido(slug, req.query.t)) {
        return res.status(403).json({ success: false, error: 'Link inválido ou expirado. Solicite um novo link à Heian Tour.' });
      }
      try {
        const data = await getClientDataHelper(slug);
        if (data && data.clientInfo) {
          return res.json({
            success: true,
            ...data
          });
        }
      } catch (err) {
        // Fallback falhou, segue para o 404
      }
      return res.status(404).json({ success: false, error: 'Cliente não encontrado com o slug fornecido.' });
    }

    if (!requestAutenticadaAdmin(req) && !tokenPortalValido(clientId, req.query.t)) {
      return res.status(403).json({ success: false, error: 'Link inválido ou expirado. Solicite um novo link à Heian Tour.' });
    }

    const data = await getClientDataHelper(clientId);
    res.json({
      success: true,
      ...data
    });
  } catch (error) {
    console.error('Erro na API pública da Área do Cliente por slug:', error);
    res.status(500).json({ success: false, error: 'Erro ao buscar dados do cliente por slug', details: error.message });
  }
});

app.get('/api/dashboard/notion-data/:clientId', async (req, res) => {
  try {
    const { clientId } = req.params;
    const NOTION_TASKS_DB_ID = process.env.NOTION_TASKS_DB_ID;
    const NOTION_SAIDAS_DB_ID = process.env.NOTION_SAIDAS_DB_ID;
    const NOTION_ENTRADAS_DB_ID = process.env.NOTION_ENTRADAS_DB_ID;

    if (!NOTION_TOKEN || !NOTION_TASKS_DB_ID || !NOTION_SAIDAS_DB_ID || !NOTION_ENTRADAS_DB_ID) {
      return res.status(400).json({ error: 'Configuração do Notion incompleta no arquivo .env.' });
    }

    const queryNotionDB = async (dbId, filterProp) => {
      const response = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${NOTION_TOKEN}`,
          'Notion-Version': '2022-06-28',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          filter: {
            property: filterProp,
            relation: {
              contains: clientId
            }
          }
        })
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Erro ao consultar base ${dbId}: ${errText}`);
      }
      return await response.json();
    };

    const [entradasData, saidasData, tasksData, calCfg] = await Promise.all([
      queryNotionDB(NOTION_ENTRADAS_DB_ID, 'Cliente (Relação)'),
      queryNotionDB(NOTION_SAIDAS_DB_ID, '🎀 Clientes'),
      queryNotionDB(NOTION_TASKS_DB_ID, '🎀 Clientes'),
      supabase.from('config').select('data').eq('id', 'calendario_eventos').single()
    ]);

    // Parse de Entradas
    let totalRecebido = 0;
    const entradas = (entradasData.results || []).map(item => {
      const p = item.properties;
      const valor = p['Valor (JPY)']?.number || 0;
      totalRecebido += valor;
      return {
        id: item.id,
        descricao: p['Descrição da Entrada']?.title?.map(t => t.plain_text).join('') || 'Entrada sem nome',
        valor,
        data: p['Data do pagamento']?.date?.start || '',
        tipo: p['Tipo de pagamento']?.select?.name || ''
      };
    });

    // Parse de Saídas
    let totalDespesas = 0;
    const saidas = (saidasData.results || []).map(item => {
      const p = item.properties;
      const valor = p['Valor (JPY)']?.number || 0;
      totalDespesas += valor;
      return {
        id: item.id,
        descricao: p['Descrição']?.title?.map(t => t.plain_text).join('') || 'Saída sem nome',
        valor,
        data: p['Data de pagamento']?.date?.start || '',
        categoria: p['Categoria']?.select?.name || '',
        tipoServico: p['Tipo de serviço']?.select?.name || ''
      };
    });

    // Parse de Tasks
    let totalLucroProjetado = 0;
    let totalTaxas = 0;
    const tasks = (tasksData.results || []).map(item => {
      const p = item.properties;
      const lucro = p['Lucro']?.formula?.number || 0;
      const taxa = p['Taxa serviço']?.number || 0;
      totalLucroProjetado += lucro;
      totalTaxas += taxa;
      return {
        id: item.id,
        nome: p['Task name']?.title?.map(t => t.plain_text).join('') || 'Task sem nome',
        status: p['Status']?.status?.name || '',
        lucro,
        taxa,
        totalCliente: p['Total Cliente']?.formula?.number || 0,
        dataServico: p['Data do Serviço']?.date?.start || ''
      };
    });

    // Processar Diárias dos Guias do Calendário Local
    let eventos = [];
    if (calCfg && calCfg.data) {
      const listaEventos = Array.isArray(calCfg.data.data) ? calCfg.data.data : (Array.isArray(calCfg.data) ? calCfg.data : []);
      eventos = listaEventos.filter(ev => ev.clienteId === clientId || (ev.clientes && ev.clientes.includes(clientId)));
    }

    let custoGuiasPago = 0;
    let custoGuiasPendente = 0;
    const guias = [];

    eventos.forEach(ev => {
      if (ev.assignee && ev.assignee.length > 0) {
        ev.assignee.forEach(colab => {
          const valor = ev.valorDiariaColab && ev.valorDiariaColab[colab.id] !== undefined
            ? Number(ev.valorDiariaColab[colab.id]) || 0
            : 0;
          const pago = ev.pagoColab && ev.pagoColab[colab.id] !== undefined
            ? !!ev.pagoColab[colab.id]
            : false;

          // Regra: Apenas listamos se for do tipo 'Roteiro' (Tour Guiado) OU se for qualquer outro tipo de serviço com diária > 0.
          // Isso oculta itens como Shinkansen/Universal Studios com diária zerada.
          const isRoteiro = ev.tipoServico && ev.tipoServico.toLowerCase() === 'roteiro';
          if (!isRoteiro && valor <= 0) {
            return;
          }

          if (pago) {
            custoGuiasPago += valor;
          } else {
            custoGuiasPendente += valor;
          }

          guias.push({
            id: ev.id,
            dataServico: ev.dataServico,
            titulo: ev.titulo,
            colabId: colab.id,
            colabName: colab.name,
            valor,
            pago
          });
        });
      }
    });

    res.json({
      success: true,
      summary: {
        totalRecebido,
        totalDespesas,
        lucroReal: totalRecebido - totalDespesas - custoGuiasPago,
        totalTaxas,
        totalLucroProjetado,
        custoGuiasPago,
        custoGuiasPendente,
        custoGuiasTotal: custoGuiasPago + custoGuiasPendente,
        caixaAtual: totalRecebido - totalDespesas - custoGuiasPago
      },
      details: {
        entradas,
        saidas,
        tasks,
        guias
      }
    });

  } catch (error) {
    console.error('Erro na API de consolidação do Dashboard do Notion:', error);
    res.status(500).json({ error: 'Erro ao consolidar dados do Notion', details: error.message });
  }
});


// ── Inicia servidor ─────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║       HEIAN TOUR — Gerador de Orçamentos     ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  Acesse: http://localhost:${PORT}              ║`);
  console.log('║  Para fechar: Ctrl + C                   ║');
  console.log('╚══════════════════════════════════════════╝\n');

  // Abre automaticamente no browser (Windows e Mac)
  const { exec } = require('child_process');
  const url = `http://localhost:${PORT}`;
  const cmd = process.platform === 'darwin' ? `open ${url}` : `start ${url}`;
  exec(cmd);

  // Inicializa o agendador de lembretes e notificações de e-mails
  console.log('[Email Init] Inicializando agendador de notificações automáticas por e-mail...');
  setTimeout(() => {
    processarNotificacoesEmail().catch(err => console.error('[Email Init] Erro na varredura inicial de e-mails:', err));
  }, 5000);

  // Executa a cada 10 minutos (10 * 60 * 1000 ms)
  setInterval(() => {
    processarNotificacoesEmail().catch(err => console.error('[Email Job] Erro no job recorrente de e-mails:', err));
  }, 10 * 60 * 1000);

  // Aquecimento do cache slug → id da Área do Cliente (evita ~10s de espera no primeiro acesso)
  setTimeout(() => {
    reconstruirCacheSlugs().then(() => {
      console.log('[Portal] Cache de slugs da Área do Cliente aquecido.');
    }).catch(err => console.error('[Portal] Falha ao aquecer cache de slugs:', err.message));
  }, 3000);

  // Migração única roteiros → ID imutável (idempotente; roda em segundo plano)
  setTimeout(() => {
    migrarRoteirosParaId().catch(err => console.error('[Migração Roteiros→ID] Falha:', err.message));
  }, 1500);
});
